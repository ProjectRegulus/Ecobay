# Manual Corporativo y Operativo — Ecobay Cleaning LLC

Sitio web del manual operativo de Ecobay (v3.0). Se publica con GitHub Pages y se integra
dentro de CleanCore para que el equipo lo consulte desde la misma plataforma que ya usa.

**Contenido:** 8 partes · 49 capítulos · 182 tablas · 27 checklists interactivas.

---

## 1. Publicar en GitHub Pages

1. Crear un repositorio nuevo en GitHub. Nombre sugerido: `ecobay-manual`.
2. Elegir la visibilidad:
   - **Privado** no funciona con Pages en cuentas gratuitas: el sitio no se publicaría.
   - **Público** funciona, pero cualquiera con la URL puede leer el manual.
   - Ver la sección 4 antes de decidir.
3. Subir estos archivos a la raíz del repositorio:
   - `index.html`
   - `manual-ecobay-v3.pdf`
4. En el repositorio: **Settings → Pages → Build and deployment**
   - Source: `Deploy from a branch`
   - Branch: `main`, carpeta `/ (root)` → **Save**
5. Esperar entre uno y dos minutos. La URL queda así:

   ```
   https://USUARIO.github.io/ecobay-manual/
   ```

Cada vez que se suba un `index.html` nuevo, el sitio se actualiza solo.

---

## 2. Integrar dentro de CleanCore

CleanCore está construido sobre GoHighLevel, así que aplican sus opciones de menú
personalizado. Hay tres formas, de más simple a más integrada.

### Opción A — Custom Menu Link (recomendada)

Deja el manual como una pestaña propia dentro del menú lateral de la plataforma.

1. En CleanCore: **Settings → Custom Menu Links → + Add Menu Link**
2. Configurar:
   - **Name:** `Manual Operativo`
   - **URL:** la URL de GitHub Pages
   - **Icon:** libro o documento
   - **Open mode:** `iframe` para que se vea dentro de la plataforma,
     o `new tab` si se prefiere en pestaña aparte
   - **Show on:** Agency o Sub-Account según a quién deba verlo
   - **User role:** todos, o solo administradores
3. Guardar. Aparece en el menú izquierdo de forma permanente.

> Si el iframe aparece en blanco, usar `new tab`. Algunas configuraciones de navegador
> bloquean contenido embebido de terceros.

### Opción B — Enlace desde el SOP Vault

Dentro del repositorio de procedimientos de CleanCore, crear una entrada
"Manual Corporativo y Operativo" cuyo contenido sea el enlace al sitio. Útil cuando se
quiere que el manual aparezca junto al resto de material de capacitación.

### Opción C — Enlace en workflows y onboarding

Incluir la URL en:

- El correo de bienvenida del onboarding de personal nuevo.
- El workflow de capacitación, apuntando al capítulo específico.
- La firma de correo del equipo administrativo.

Cada capítulo tiene su propio enlace directo. Por ejemplo, para enviar a alguien
directamente al proceso de contratación basta con copiar el enlace del capítulo
desde el menú lateral del sitio.

---

## 3. Funciones del sitio

| Función | Para qué sirve |
|---|---|
| Menú lateral por partes y capítulos | Navegación directa a cualquier proceso |
| Buscador (tecla `/`) | Filtra capítulos y resalta coincidencias en el texto |
| Checklists interactivas | Se marcan y quedan guardadas en el navegador de cada persona |
| Botón "Reiniciar casillas" | Deja la checklist lista para el siguiente uso |
| Enlaces por capítulo | Se puede compartir un proceso específico, no el manual entero |
| Modo oscuro | Lectura cómoda en turnos de noche o pantallas con brillo alto |
| Botón imprimir | Genera PDF con cada capítulo en página nueva |
| Descarga del PDF completo | Para consulta sin conexión |
| Diseño móvil | Consultable desde el teléfono en la propiedad |
| Barra de progreso | Indica qué tanto del capítulo se ha recorrido |

Las casillas marcadas se guardan **por dispositivo y por navegador**. Sirven como ayuda
personal de ejecución, no como registro auditable de la empresa: la evidencia formal de
que un proceso se completó vive en el sistema de gestión, según el Capítulo 81.

---

## 4. Decisión sobre privacidad

El manual lleva la leyenda "Documento interno · Prohibida su difusión a terceros" y el
Anexo C es un acuse de confidencialidad. Publicarlo en un repositorio público contradice
esa condición: quedaría accesible para cualquiera, incluida la competencia, y también
indexable por buscadores.

Opciones, en orden de conveniencia:

1. **Repositorio privado con GitHub Pages de pago.** Los planes con Pages privado
   restringen el acceso a personas autorizadas del repositorio.
2. **Repositorio público con URL no divulgada.** Funciona y es gratuito, pero no es
   seguridad real: si el enlace se filtra, el manual queda expuesto.
3. **Alojarlo dentro de CleanCore o del sitio de Ecobay** detrás de la autenticación
   que ya existe en la plataforma. Es la opción más coherente con la cláusula de
   confidencialidad.

Si se elige la opción 2, conviene al menos:

- Revisar que el manual no contenga datos de clientes, direcciones ni credenciales.
- Agregar un archivo `robots.txt` con el contenido siguiente para evitar la indexación:

  ```
  User-agent: *
  Disallow: /
  ```

Aun así, `robots.txt` solo pide a los buscadores que no indexen: no impide el acceso
directo de quien tenga la URL.

---

## 5. Actualizar el manual

El sitio se genera desde el mismo contenido que produce el PDF, de modo que ambos
formatos nunca se desincronizan.

```
python3 build_site.py     # regenera index.html
```

Después se sube el `index.html` nuevo al repositorio y GitHub Pages lo publica solo.

Toda modificación de contenido debe registrarse en el control de versiones del Anexo B
del manual. Ninguna práctica se convierte en política de Ecobay sin quedar documentada en
una versión aprobada.

---

## 6. Archivos del repositorio

| Archivo | Función |
|---|---|
| `index.html` | El sitio completo, autocontenido. Es lo único indispensable. |
| `manual-ecobay-v3.pdf` | Versión imprimible para descarga y firma del acuse. |
| `build_site.py` | Generador del sitio. |
| `build_manual_m.py` | Motor de render en HTML. |
| `master_front.py`, `master_body.py`, `master_annex.py` | Contenido del manual. |
| `logo.png` | Logotipo de Ecobay. |
| `README.md` | Este documento. |

Los archivos `.py` no son necesarios para que el sitio funcione: sirven para poder
regenerarlo cuando el manual cambie. Si se prefiere un repositorio mínimo, basta con
subir `index.html` y el PDF.
