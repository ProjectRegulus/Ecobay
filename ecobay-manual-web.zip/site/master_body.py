# -*- coding: utf-8 -*-
from build_manual_m import *  # noqa

PARTE("I", "Identidad, filosofía y modelo operativo",
      "Qué es Ecobay, cómo gana dinero, cómo se organiza y quién decide qué.",
      ["Capítulo 1. Propósito del manual",
       "Capítulo 2. Historia, identidad y filosofía de Ecobay",
       "Capítulo 3. Misión, visión, valores y principios operativos",
       "Capítulo 4. Modelo de negocio de Ecobay",
       "Capítulo 5. Estructura organizacional",
       "Capítulo 6. Roles, responsabilidades y autoridad",
       "Capítulo 7. Matriz de responsabilidades y delegación"])

# ---------- CAP 1 ----------
CAP("1", "Propósito del manual")
P("1.1 Objetivo", 'h1')
P("Documentar los procesos internos de Ecobay Cleaning LLC de manera que puedan ejecutarse siguiendo "
  "procedimientos claros, estandarizados y verificables, con independencia de qué persona ocupe cada posición y "
  "de qué plataforma tecnológica se utilice en un momento dado.")

P("1.2 Prueba de validación de todo el manual", 'h1')
BOX(None, [
    "<b>¿Podría una persona competente, que no conoce previamente Ecobay, ejecutar este proceso correctamente "
    "utilizando únicamente este manual, las herramientas de la empresa y los sistemas correspondientes?</b>",
    "Si la respuesta es no, el procedimiento necesita más detalle. Esta pregunta se aplica a cada SOP del "
    "documento y es el criterio de aceptación para aprobar una nueva versión."])

P("1.3 Las quince preguntas que todo proceso debe responder", 'h1')
P("Un capítulo de este manual solo se considera terminado cuando el proceso descrito responde las quince "
  "preguntas siguientes. Los capítulos que aún no las responden llevan la etiqueta correspondiente.")
TBL([
    ["#", "Pregunta", "Dónde se responde en un capítulo"],
    ["1", "¿Qué se hace?", "Descripción del proceso"],
    ["2", "¿Por qué se hace?", "Objetivo del proceso"],
    ["3", "¿Quién lo hace?", "Responsable principal en la ficha SOP"],
    ["4", "¿Cuándo se hace?", "Frecuencia o disparador"],
    ["5", "¿Qué información necesita la persona?", "Inputs requeridos"],
    ["6", "¿Dónde se registra?", "Sistema de registro"],
    ["7", "¿Cómo se verifica?", "Control de calidad y checklist"],
    ["8", "¿Qué estándar debe cumplirse?", "Estándar esperado"],
    ["9", "¿Qué sucede si algo sale mal?", "Manejo de excepciones"],
    ["10", "¿Quién toma la decisión?", "Puntos de decisión y matriz de aprobación"],
    ["11", "¿Qué puede delegarse?", "Matriz de delegación (Capítulo 7)"],
    ["12", "¿Qué debe escalarse?", "Criterios de escalamiento"],
    ["13", "¿Qué evidencia queda registrada?", "Registro requerido"],
    ["14", "¿Cómo se entrena a otra persona?", "Entrenamiento requerido"],
    ["15", "¿Cómo se auditaría en una franquicia?", "Notas de escalabilidad"],
], [0.35 * inch, 3.0 * inch, 3.15 * inch], fs=8.5)

P("1.4 Principio fundamental: el conocimiento pertenece a la empresa", 'h1')
TAG("C", "diagnóstico levantado en entrevista")
P("Existe una concentración significativa de responsabilidades administrativas en una sola persona. Al preguntarse "
  "qué procesos dependen al cien por ciento de la administración, la respuesta fue: <i>«todo lo de la oficina»</i>.")
P("El problema no es que esa persona conozca los procesos —ese conocimiento es hoy uno de los activos más "
  "importantes de la empresa— sino que existe de manera informal, en la experiencia, la memoria y el criterio "
  "personal.")
BOX(None, ["De: <b>«Reina sabe cómo hacerlo.»</b>", "A: <b>«La empresa tiene un proceso documentado para hacerlo.»</b>"])

P("1.5 Formato estándar de un SOP en Ecobay", 'h1')
TAG("P")
P("Los procesos críticos se documentan con la siguiente estructura de veinte campos. Los procesos menores pueden "
  "omitir los campos que no apliquen, pero nunca los campos 3, 5, 8, 13 y 14.")
TBL([
    ["#", "Campo", "#", "Campo"],
    ["1", "Objetivo", "11", "Errores frecuentes"],
    ["2", "Alcance", "12", "Qué hacer cuando algo sale mal"],
    ["3", "Responsable principal", "13", "Cuándo escalar"],
    ["4", "Responsable secundario / backup", "14", "Registro requerido"],
    ["5", "Cuándo se ejecuta", "15", "Control de calidad"],
    ["6", "Información necesaria", "16", "KPI relacionado"],
    ["7", "Sistemas utilizados", "17", "Checklist"],
    ["8", "Paso a paso", "18", "Documentos relacionados"],
    ["9", "Puntos de decisión", "19", "Entrenamiento requerido"],
    ["10", "Estándar esperado", "20", "Notas de escalabilidad / franquicia"],
], [0.35 * inch, 2.9 * inch, 0.35 * inch, 2.9 * inch], fs=8.5)

P("1.6 Nomenclatura de posiciones, no de personas", 'h1')
TAG("R")
P("El manual nombra <b>posiciones</b>, no personas. Los nombres propios aparecen únicamente en las secciones de "
  "diagnóstico, donde describen el estado actual de la operación. Esta convención permite que el proceso "
  "sobreviva a cualquier cambio de personal.")
TBL([
    ["Posición usada en el manual", "Alcance", "Quién la ocupa hoy"],
    ["Owner / Dirección", "Decisiones estratégicas, aprobación de políticas y precios excepcionales.", "Dirección de Ecobay"],
    ["Administración", "Scheduling, clientes, leads, cobros, payroll y coordinación de oficina.", "Concentrada en una persona"],
    ["Operations / Coordinación", "Preparación, despacho, supervisión de campo y calidad.", "Compartida entre dirección y campo"],
    ["Team Lead", "Dirección del equipo en la propiedad e inspección final.", "Función implícita, sin formalizar"],
    ["Colaborador / Cleaner", "Ejecución del servicio conforme al Manual de Limpieza por Áreas.", "Equipos de 2 a 5 personas"],
], [1.6 * inch, 3.3 * inch, 1.6 * inch], fs=8.5)

# ---------- CAP 2 ----------
CAP("2", "Historia, identidad y filosofía de Ecobay")
P("2.1 Identidad de la empresa", 'h1')
TAG("C", "declarado en el Manual de Limpieza por Áreas")
P("Ecobay Cleaning LLC se caracteriza por realizar una limpieza <b>eco-friendly</b>: una limpieza más natural y "
  "saludable. Esta declaración no es un eslogan de marketing sino una restricción operativa con consecuencias "
  "concretas en la selección de productos, en la preparación del vehículo y en la conversación de venta.")
P("Consecuencias operativas verificables de la identidad eco-friendly:")
TBL([
    ["Ámbito", "Consecuencia operativa", "Dónde se desarrolla"],
    ["Producto", "Los productos ecológicos son la primera opción por defecto en todo servicio.", "Parte IX"],
    ["Excepción", "Los productos más fuertes se incorporan según la condición de la propiedad, no por costumbre.", "Parte IX"],
    ["Cliente", "La preferencia ecológica expresa del cliente es una instrucción vinculante que anula la excepción anterior.", "Capítulos 27 y 31"],
    ["Registro", "Esa preferencia debe constar en el sistema de gestión y revisarse antes de cargar el vehículo.", "Capítulos 13 y 67"],
    ["Venta", "La identidad eco-friendly es un argumento diferenciador legítimo en la cotización.", "Capítulo 23"],
], [1.1 * inch, 3.9 * inch, 1.5 * inch], fs=8.5)

P("2.2 Filosofía operativa: la casa verde", 'h1')
P("La denominación «La Casa Verde de Ecobay» del manual técnico expresa la doble promesa de la empresa: una casa "
  "limpia y un método que no compromete la salud de quienes la habitan ni de quienes la limpian. Todo estándar "
  "de este manual debe ser compatible con ambas mitades de esa promesa.")

P("2.3 Promesa de marca y estándar de comportamiento", 'h1')
TAG("C", "derivado de las políticas del Manual de Limpieza por Áreas")
P("Las políticas ya vigentes definen un estándar de comportamiento que forma parte de la identidad y que es "
  "obligatorio en toda propiedad:")
TBL([
    ["Estándar vigente", "Origen"],
    ["Uniforme de Ecobay, pantalón cómodo oscuro, calzado cerrado cómodo y cabello recogido.", "Manual de Limpieza por Áreas"],
    ["Sin accesorios que puedan caer o dañar superficies: aretes grandes, anillos, pulseras, collares ni reloj.", "Política 2 del manual técnico"],
    ["Sin uso de celular en horario laboral.", "Política 2 del manual técnico"],
    ["Pertenencias personales guardadas fuera del mobiliario del cliente, preferentemente en el vehículo.", "Política 3 del manual técnico"],
    ["En presencia del cliente: postura de colaborador, sin conversaciones ajenas al trabajo, sin gritos ni carcajadas.", "Recomendaciones del manual técnico"],
    ["Cada colaborador es responsable de su organizador y de reportar productos agotados.", "Política 1 del manual técnico"],
], [4.4 * inch, 2.1 * inch], fs=8.5)

# ---------- CAP 3 ----------
CAP("3", "Misión, visión, valores y principios operativos")
P("3.1 Valor confirmado: disciplina", 'h1')
TAG("R", "valor declarado por la dirección durante el levantamiento")
P("La disciplina es un valor fundamental declarado de Ecobay Cleaning LLC. Se define operativamente así:")
BOX(None, [
    "<b>La motivación ayuda a comenzar. La disciplina permite continuar y terminar.</b>",
    "No se trabaja únicamente cuando hay motivación. Se trabaja porque existe una responsabilidad que debe "
    "cumplirse."])
P("Traducción del valor a conductas observables y auditables:")
TBL([
    ["Conducta esperada", "Cómo se verifica"],
    ["Las rutinas administrativas se completan en su frecuencia definida, independientemente de la carga del día.", "Registro de rutinas (Capítulos 10 a 12)"],
    ["Ningún lead queda sin acción siguiente.", "Auditoría de pipeline (Capítulo 22)"],
    ["Los compromisos con el cliente se cumplen en la fecha y hora acordadas.", "Indicadores de puntualidad (Parte XV)"],
    ["Los registros se actualizan aunque nadie los esté revisando en ese momento.", "Auditoría de calidad de datos (Capítulo 13)"],
], [3.8 * inch, 2.7 * inch], fs=8.5)

P("3.2 Principios operativos derivados del sistema", 'h1')
TAG("R", "principios establecidos y en uso a lo largo de este manual")
TBL([
    ["#", "Principio", "Aplicación"],
    ["1", "El conocimiento pertenece a la empresa, no a la persona.", "Todo proceso repetitivo debe existir por escrito."],
    ["2", "Una costumbre no es una política.", "Ninguna práctica se vuelve obligatoria sin aprobación registrada."],
    ["3", "No todo lo urgente requiere nuestra participación.", "Sistema de prioridades (Capítulo 9)."],
    ["4", "Ninguna tarea repetitiva debe depender de la memoria.", "Registro, checklist o automatización."],
    ["5", "El proceso manda sobre la herramienta.", "El software soporta el proceso; no lo define."],
    ["6", "Toda oportunidad tiene un próximo paso.", "Pipeline sin estados muertos (Capítulo 22)."],
    ["7", "La urgencia no justifica bajar el estándar.", "Calidad y seguridad no se negocian por tiempo."],
    ["8", "Lo que no se registra no ocurrió.", "Evidencia obligatoria en procesos críticos."],
], [0.35 * inch, 2.9 * inch, 3.25 * inch], fs=8.5)

# ---------- CAP 4 ----------
CAP("4", "Modelo de negocio de Ecobay")
P("4.1 Qué vende Ecobay", 'h1')
TAG("C")
TBL([
    ["Servicio", "Naturaleza", "Frecuencia típica", "Personal"],
    ["Regular Cleaning residencial", "Recurrente", "Cada 8 a 15 días", "2"],
    ["Deep Cleaning", "Puntual o de entrada", "Según necesidad", "3-4 (hasta 5 con ventanas)"],
    ["Move-Out / Move-In", "Puntual", "Evento de mudanza", "Según alcance"],
    ["Post-Construction", "Puntual", "Fin de obra", "4-5, más en propiedades grandes"],
    ["Windows", "Complemento", "Según solicitud", "Persona adicional"],
    ["Carpet Cleaning", "Complemento", "Según solicitud", "Según alcance del trabajo"],
    ["Power Washing", "Complemento", "Según solicitud", "Según alcance del trabajo"],
], [1.6 * inch, 1.2 * inch, 1.5 * inch, 2.2 * inch], fs=8.5)

P("4.2 Los dos motores económicos", 'h1')
P("El modelo de Ecobay descansa sobre dos motores de naturaleza distinta, que exigen sistemas de gestión "
  "diferentes y que no deben confundirse en la operación ni en la medición.")
TBL([
    ["", "Motor recurrente", "Motor puntual"],
    ["Servicios", "Regular Cleaning", "Deep, Move-Out, Post-Construction"],
    ["Valor", "Ingreso predecible y ruta estable", "Ticket alto por evento"],
    ["Riesgo principal", "Cancelación o pérdida silenciosa del cliente", "Cartera vacía si se detiene el flujo de leads"],
    ["Prioridad de gestión", "Retención y calidad sostenida", "Velocidad de respuesta y cotización"],
    ["Sistema clave", "Customer success y control de calidad", "Lead management y pipeline"],
    ["Indicador central", "Clientes recurrentes activos y bajas", "Leads, tasa de cotización y tasa de cierre"],
], [1.3 * inch, 2.6 * inch, 2.6 * inch], fs=8.5)
BOX("Consecuencia estratégica", [
    "Un servicio puntual bien ejecutado es la puerta de entrada más barata al motor recurrente. La conversión de "
    "cliente puntual a cliente recurrente se documenta como proceso propio en el Capítulo 24 y no debe quedar "
    "librada a que alguien recuerde ofrecerlo."])

P("4.3 Cadena de valor de Ecobay", 'h1')
FLOW(["Generación de leads", "Calificación", "Cotización", "Booking", "Programación"])
FLOW(["Preparación", "Ejecución del servicio", "Inspección", "Cierre", "Seguimiento"])
FLOW(["Cobro", "Payroll", "Retención", "Referido o reactivación"])
P("Cada eslabón tiene en este manual un responsable, un registro, un estándar y un control. Un eslabón sin esos "
  "cuatro elementos es un punto de fuga: normalmente se manifiesta como un lead perdido, una casa mal preparada, "
  "una hora de payroll imposible de reconstruir o un cliente que se fue sin que nadie lo notara.")

P("4.4 Estructura de costos y determinantes del precio", 'h1')
P("Este manual no contiene precios ni márgenes. Lo que sí puede documentarse son las variables confirmadas que "
  "determinan el esfuerzo y, por lo tanto, el costo de un servicio:")
B([
    "Tipo de servicio y su frecuencia.",
    "Tamaño de la propiedad.",
    "Condición de la propiedad y nivel de suciedad.",
    "Propiedad ocupada o vacía.",
    "Servicios adicionales, en particular ventanas.",
    "Número de colaboradores requeridos y tiempo estimado.",
    "Tipo de superficies y necesidad de productos o equipo especializado.",
])
P("La conversión de estas variables en precio se desarrolla en el Capítulo 23.")

# ---------- CAP 5 ----------
CAP("5", "Estructura organizacional")
P("5.1 Estructura actual", 'h1')
TAG("C", "estado real levantado, no estructura deseada")
P("La operación funciona hoy con dos núcleos: un núcleo administrativo concentrado en una sola persona y un "
  "núcleo de campo apoyado en la otra parte de la dirección más los equipos de limpieza. No existen niveles "
  "intermedios formalizados.")
TBL([
    ["Nivel", "Funciones que absorbe hoy", "Riesgo"],
    ["Dirección / Owner", "Estrategia, precios, evaluación presencial, decisiones de contratación.", "Se mezcla con ejecución diaria."],
    ["Administración", "Scheduling, clientes, mensajes, correos, seguimiento, leads, cobros, invoices, payroll, preparación de equipo.", "Punto único de falla de la empresa."],
    ["Campo / Dirección operativa", "Traslado, ejecución, coordinación en sitio.", "Sin registro formal de lo ocurrido en la propiedad."],
    ["Equipos de limpieza", "Ejecución del servicio.", "Sin Team Lead formal ni inspección documentada."],
], [1.5 * inch, 3.4 * inch, 1.6 * inch], fs=8.5)

P("5.2 Estructura objetivo", 'h1')
TAG("P", "diseño de destino; su implantación depende del volumen y de la aprobación de la dirección")
FLOW(["Owner", "Administración", "Operations", "Team Lead", "Colaboradores"])
TBL([
    ["Posición", "Misión de la posición", "Cuándo se justifica crearla"],
    ["Owner / Dirección", "Definir estrategia, aprobar políticas y precios excepcionales, supervisar indicadores.", "Existe desde el primer día."],
    ["Administración", "Sostener el ciclo comercial y administrativo: leads, schedule, cliente, cobro, registro.", "Existe hoy."],
    ["Operations / Coordinación", "Garantizar que cada servicio salga preparado, se ejecute al estándar y se cierre con evidencia.", "Cuando existan rutas simultáneas de forma sostenida."],
    ["Team Lead", "Dirigir el equipo en la propiedad, distribuir el trabajo y ejecutar la inspección final.", "Cuando un equipo trabaje sin presencia de la dirección."],
    ["Colaborador", "Ejecutar el servicio conforme al estándar técnico y reportar incidencias.", "Existe hoy."],
    ["Customer Success", "Retención, feedback, reseñas, reactivación y recuperación de clientes.", "Cuando la cartera recurrente supere la capacidad de seguimiento de Administración."],
], [1.3 * inch, 3.3 * inch, 1.9 * inch], fs=8.5)

P("5.3 Regla de crecimiento estructural", 'h1')
TAG("P")
BOX(None, [
    "<b>Una posición nueva no se crea porque haya trabajo acumulado, sino cuando existe un conjunto de procesos "
    "documentados que puedan transferirse íntegros a esa posición.</b>",
    "Contratar antes de documentar traslada el caos, no la carga."])

P("5.4 Estructura preparada para múltiples ubicaciones", 'h1')
TAG("P", "arquitectura conceptual; la configuración técnica requiere validación")
FLOW(["Corporate", "Ubicación / Franquicia", "Operations", "Equipos", "Colaboradores"])
TBL([
    ["Corporate define y controla", "La ubicación decide localmente"],
    ["Estándares de marca y de servicio.", "Composición y horarios de sus equipos."],
    ["Procesos obligatorios y su secuencia.", "Rutas y logística de su mercado."],
    ["Campos e información mínima que debe registrarse.", "Proveedores locales de insumos, dentro del estándar."],
    ["Estructura de reporte e indicadores.", "Tácticas de reclutamiento local."],
    ["Estándares de experiencia del cliente y de reseñas.", "Ajustes de agenda y capacidad."],
    ["Estándares de capacitación y certificación.", "Selección final de su personal, con el proceso corporativo."],
], [3.25 * inch, 3.25 * inch], fs=8.5)

# ---------- CAP 6 ----------
CAP("6", "Roles, responsabilidades y autoridad")
P("6.1 Diferencia entre responsabilidad y autoridad", 'h1')
P("Responsabilidad es la obligación de que un proceso ocurra y produzca su resultado. Autoridad es la facultad de "
  "decidir sin pedir aprobación. Buena parte de la fricción operativa nace de dar responsabilidad sin autoridad: "
  "se pide a alguien que resuelva algo, pero cada decisión debe consultarse.")

P("6.2 Descripciones de posición", 'h1')
TAG("P", "descripciones construidas a partir de las funciones reales levantadas")

P("Administración", 'h2')
TBL([
    ["Campo", "Contenido"],
    ["Misión", "Sostener el ciclo comercial y administrativo completo: que ningún lead, cita, cliente, cobro ni pago quede sin gestión ni registro."],
    ["Procesos que posee", "Lead intake y seguimiento; construcción del schedule; comunicación con clientes; cuentas por cobrar e invoices; recopilación de horas y preparación de payroll; mantenimiento de registros."],
    ["Autoridad", "Programar y reprogramar servicios; responder y calificar leads; cotizar con precios establecidos; actualizar registros."],
    ["Requiere aprobación", "Precios fuera de tarifa; descuentos; compensaciones a clientes; contrataciones; cambios de política."],
    ["Indicadores", "Tiempo de respuesta a leads; leads sin acción siguiente; exactitud del schedule; cuentas por cobrar identificadas; payroll procesado sin incidencias."],
    ["Backup", "Designado por la dirección."],
], [1.5 * inch, 5.0 * inch], fs=8.5)

P("Operations / Coordinación", 'h2')
TBL([
    ["Campo", "Contenido"],
    ["Misión", "Que cada servicio salga preparado, se ejecute conforme al estándar y se cierre con evidencia."],
    ["Procesos que posee", "Preparación de vehículo y equipo; despacho; asignación de equipos; supervisión de calidad; gestión de incidencias en campo; inventario y mantenimiento."],
    ["Autoridad", "Ajustar la composición del equipo dentro de la matriz de staffing; decidir el kit según condiciones; ordenar una corrección inmediata."],
    ["Requiere aprobación", "Compras fuera de rutina; cambios de alcance con el cliente; compensaciones."],
    ["Indicadores", "Servicios completados sin incidencias; re-cleans; equipo faltante al salir; cumplimiento de checklist."],
    ["Backup", "Designado por la dirección."],
], [1.5 * inch, 5.0 * inch], fs=8.5)

P("Team Lead", 'h2')
TBL([
    ["Campo", "Contenido"],
    ["Misión", "Dirigir el equipo dentro de la propiedad y garantizar que el servicio se entregue completo y al estándar."],
    ["Procesos que posee", "Distribución del trabajo entre los miembros; control del tiempo en sitio; inspección final; reporte de incidencias, daños y faltantes."],
    ["Autoridad", "Asignar áreas y secuencia de trabajo; decidir el orden de limpieza según la propiedad; detener una tarea insegura."],
    ["Requiere aprobación", "Aceptar trabajo fuera del alcance contratado; extender significativamente el tiempo en sitio."],
    ["Indicadores", "Resultado de inspección final; quejas asociadas al servicio; cumplimiento de tiempo estimado."],
    ["Estado", "Función reconocida en el Manual de Limpieza por Áreas como coordinador de equipo."],
], [1.5 * inch, 5.0 * inch], fs=8.5)
P("El Manual de Limpieza por Áreas ya reconoce esta función al establecer que el orden de limpieza y las tareas "
  "por área dependen del coordinador de equipo, y que las incidencias se resuelven junto con él.")

P("Colaborador / Cleaner", 'h2')
TBL([
    ["Campo", "Contenido"],
    ["Misión", "Ejecutar el servicio asignado conforme al estándar técnico de Ecobay."],
    ["Procesos que posee", "Preparación de su organizador y delantal; ejecución por área; uso correcto de productos, paños y herramientas; reporte de faltantes y de imprevistos."],
    ["Autoridad", "Decidir el detalle de ejecución dentro del estándar; solicitar aclaración al Team Lead."],
    ["Requiere aprobación", "Cualquier tarea fuera del alcance contratado, como lavar platos; uso de productos no autorizados en una superficie."],
    ["Indicadores", "Calidad del área asignada; incidencias; cuidado del equipo."],
    ["Obligaciones vigentes", "Políticas 1, 2 y 3 del Manual de Limpieza por Áreas."],
], [1.5 * inch, 5.0 * inch], fs=8.5)

P("6.3 Regla de alcance del servicio", 'h1')
TAG("R", "derivada del Manual de Limpieza por Áreas")
P("Las tareas a realizar en cada área pueden variar según el contrato acordado con el cliente y son indicadas "
  "previamente por el coordinador de equipo. Ninguna persona en la propiedad amplía el alcance por iniciativa "
  "propia: lavar platos, por ejemplo, no forma parte de un servicio de limpieza regular y debe consultarse.")

# ---------- CAP 7 ----------
CAP("7", "Matriz de responsabilidades y delegación")
P("7.1 Convención RACI", 'h1')
TBL([
    ["Letra", "Significado", "Regla"],
    ["R", "Responsable de ejecutar", "Puede haber varios."],
    ["A", "Aprueba y responde por el resultado", "Uno y solo uno por proceso."],
    ["C", "Consultado antes de decidir", "Aporta información o criterio."],
    ["I", "Informado del resultado", "No participa en la decisión."],
], [0.5 * inch, 2.3 * inch, 3.7 * inch], fs=8.5)

P("7.2 Matriz RACI de procesos principales", 'h1')
TAG("P")
TBL([
    ["Proceso", "Owner", "Admin.", "Operations", "Team Lead"],
    ["Atención y calificación de leads", "I", "A/R", "I", "—"],
    ["Cotización con precio establecido", "I", "A/R", "C", "—"],
    ["Cotización con evaluación presencial", "A/R", "C", "C", "—"],
    ["Construcción del schedule", "I", "A/R", "C", "I"],
    ["Asignación de equipos", "I", "A", "R", "C"],
    ["Preparación de vehículo y equipo", "I", "C", "A/R", "C"],
    ["Ejecución del servicio", "I", "I", "A", "R"],
    ["Inspección final", "I", "I", "A", "R"],
    ["Gestión de quejas y re-clean", "C", "A/R", "R", "C"],
    ["Cuentas por cobrar e invoices", "A", "R", "I", "—"],
    ["Recopilación de horas", "A", "R", "C", "C"],
    ["Procesamiento de payroll", "A", "R", "I", "—"],
    ["Reclutamiento y preselección", "A", "R", "C", "—"],
    ["Decisión final de contratación", "A/R", "C", "C", "—"],
    ["Capacitación e integración", "A", "C", "R", "R"],
    ["Cambios de política del manual", "A/R", "C", "C", "C"],
], [2.55 * inch, 0.75 * inch, 0.9 * inch, 1.15 * inch, 1.15 * inch], fs=8)

P("7.3 Matriz de aprobación", 'h1')
TBL([
    ["Decisión", "Quién puede decidir", "Requiere aprobación de"],
    ["Programar o reprogramar un servicio", "Administración", "—"],
    ["Cotizar con precio establecido", "Administración", "—"],
    ["Cotizar fuera de tarifa o con descuento", "—", "Owner"],
    ["Aceptar un trabajo fuera del área de cobertura", "—", "Owner"],
    ["Ampliar el alcance en la propiedad", "—", "Administración u Operations"],
    ["Autorizar un re-clean sin costo", "Administración", "Owner si implica compensación económica"],
    ["Compra de equipo o insumos fuera de rutina", "—", "Owner"],
    ["Contratar a un colaborador", "—", "Owner"],
    ["Ajustar horas de payroll fuera del registro", "—", "Owner"],
    ["Modificar una política de este manual", "—", "Owner, con registro de versión"],
], [2.4 * inch, 1.9 * inch, 2.2 * inch], fs=8.5)

P("7.4 Matriz de escalamiento", 'h1')
TAG("P")
TBL([
    ["Situación", "Primer nivel", "Escala a", "Plazo objetivo"],
    ["Cliente reporta área mal limpiada", "Administración", "Operations para corrección", "Mismo día"],
    ["Daño a propiedad del cliente", "Team Lead", "Operations y Owner", "Inmediato"],
    ["Accidente o lesión de un colaborador", "Team Lead", "Owner", "Inmediato"],
    ["Colaborador no se presenta", "Operations", "Administración para reprogramar", "Antes de la salida"],
    ["Equipo o producto crítico faltante", "Operations", "Owner si impide el servicio", "Antes de la salida"],
    ["Cliente solicita algo fuera de alcance", "Team Lead", "Administración", "Durante el servicio"],
    ["Prospecto de alto valor o comercial", "Administración", "Owner", "Antes de cotizar"],
    ["Reclamo con feedback negativo público", "Administración", "Owner", "Antes de responder"],
    ["Inconsistencia en horas de payroll", "Administración", "Owner", "Antes de procesar"],
], [2.05 * inch, 1.5 * inch, 1.7 * inch, 1.25 * inch], fs=8)

P("7.5 Criterio de delegación", 'h1')
P("Antes de asumir personalmente una tarea, la persona responsable aplica esta secuencia:")
NUM([
    "¿La tarea es importante? Si no lo es, se elimina o se reduce.",
    "¿Es urgente? Determina el momento, no el ejecutante.",
    "¿Requiere criterio que solo esta posición posee? Si no, es delegable.",
    "¿Existe un procedimiento escrito que permita a otra persona ejecutarla? Si no existe, escribirlo es la tarea real.",
    "¿Es repetitiva y predecible? Entonces es candidata a automatización.",
    "¿Qué evidencia demostrará que se ejecutó correctamente?",
])

P("7.6 Continuidad empresarial por proceso", 'h1')
P("La pregunta de control de esta sección es: <b>si la persona de administración no está disponible durante siete "
  "días, ¿qué se detiene?</b> Cada respuesta afirmativa constituye un riesgo que debe cerrarse mediante "
  "documentación, delegación o automatización.")
TBL([
    ["Proceso crítico", "¿Se detiene hoy?", "Cierre del riesgo"],
    ["Atención de leads nuevos", "Sí", "SOP de intake + respuesta inicial automatizada + backup designado"],
    ["Respuesta a llamadas y mensajes", "Sí", "Desvío definido + seguimiento de llamada perdida"],
    ["Construcción del schedule", "Sí", "Schedule construido con antelación + acceso de respaldo"],
    ["Cambios de último minuto", "Sí", "Autoridad delegada a Operations dentro de reglas"],
    ["Preparación de vehículo", "Parcialmente", "Checklist de preparación por servicio"],
    ["Ejecución del servicio", "No", "Equipos operan con estándar técnico vigente"],
    ["Identificación de pagos recibidos", "Sí", "Acceso de respaldo + registro de método por cliente"],
    ["Emisión de invoices", "Sí", "Backup con acceso al sistema de gestión"],
    ["Recopilación de horas", "Sí", "Registro diario por el Team Lead en lugar de reconstrucción posterior"],
    ["Procesamiento de payroll", "Sí", "Backup autorizado + hoja de control al día"],
], [2.2 * inch, 1.1 * inch, 3.2 * inch], fs=8)
BOX("Regla de continuidad", [
    "Todo proceso crítico debe tener responsable principal, responsable de respaldo, sistema de registro, "
    "frecuencia y criterio de escalamiento. Un proceso sin respaldo designado es una dependencia personal "
    "disfrazada de rutina."])

# ==================================================================
# PARTE II
# ==================================================================
PARTE("II", "Administración y sistema empresarial",
      "Cómo se administra el tiempo, la información y los procesos de la empresa.",
      ["Capítulo 8. Sistema de administración",
       "Capítulo 9. Gestión del tiempo y prioridades",
       "Capítulo 10. Rutinas administrativas diarias",
       "Capítulo 11. Rutinas administrativas semanales",
       "Capítulo 12. Rutinas administrativas mensuales",
       "Capítulo 13. Gestión de información empresarial",
       "Capítulo 14. Documentación y control de procesos"])

# ---------- CAP 8 ----------
CAP("8", "Sistema de administración")
P("8.1 Diagnóstico del sistema actual", 'h1')
TAG("C")
P("La administración concentra hoy scheduling, comunicación con clientes, mensajes, correos, seguimiento, "
  "payroll, finanzas, facturación, revisión de pagos y coordinación operativa. El trabajo se organiza según la "
  "disponibilidad de tiempo y las necesidades que surgen, sin bloques formales asignados a cada función.")
TBL([
    ["Proceso", "Responsable actual", "Dependencia"],
    ["Programación de citas y schedule", "Administración", "100%"],
    ["Comunicación con clientes, mensajes y correos", "Administración", "100%"],
    ["Seguimiento de leads y clientes", "Administración", "100%"],
    ["Atención de nuevas solicitudes", "Administración", "100%"],
    ["Preparación administrativa de nuevos trabajos", "Administración", "100%"],
    ["Preparación del vehículo y equipos", "Administración", "Alta"],
    ["Administración de pagos y facturación", "Administración", "Alta"],
    ["Payroll y determinación de horas", "Administración", "Alta"],
    ["Organización de equipos de trabajo", "Administración", "Alta"],
], [3.4 * inch, 1.9 * inch, 1.2 * inch], fs=8.5)

P("8.2 Problema estructural: administración reactiva", 'h1')
TAG("C")
FLOW(["Operación", "Clientes", "Schedule", "Payroll", "Finanzas", "Mensajes", "Operación"])
P("El modelo obliga a alternar continuamente entre funciones distintas, lo que genera una alta cantidad de "
  "cambios de contexto y provoca que tareas administrativas se acumulen. La consecuencia no es solo pérdida de "
  "tiempo: es que las tareas importantes pero no urgentes —precisamente las que construyen el sistema— se "
  "posponen de manera indefinida.")

P("8.3 Arquitectura del sistema administrativo", 'h1')
TAG("P")
P("El sistema administrativo de Ecobay se estructura en cinco capas. Cada proceso de este manual pertenece a una "
  "de ellas y hereda su frecuencia y su control.")
TBL([
    ["Capa", "Contenido", "Frecuencia", "Capítulo"],
    ["Rutina diaria", "Lo que mantiene la operación viva: leads, schedule del día, incidencias.", "Cada día operativo", "10"],
    ["Rutina semanal", "Lo que ordena la semana: schedule, cobros, horas, pendientes.", "Semanal", "11"],
    ["Rutina mensual", "Lo que corrige el sistema: indicadores, auditoría, inventario, revisión.", "Mensual", "12"],
    ["Gestión de información", "Dónde vive cada dato y quién responde por su calidad.", "Permanente", "13"],
    ["Control de procesos", "Cómo se documenta, aprueba y actualiza el propio sistema.", "Por versión", "14"],
], [1.3 * inch, 2.9 * inch, 1.2 * inch, 1.1 * inch], fs=8.5)

P("8.4 Principio de bloques administrativos", 'h1')
TAG("P", "sustituye la administración reactiva; el horario concreto requiere aprobación")
TBL([
    ["Bloque", "Contenido", "Momento identificado hoy"],
    ["Planificación", "Organización del schedule de la semana siguiente.", "Fin de semana"],
    ["Comercial", "Leads nuevos, respuestas, cotizaciones y seguimientos.", "Bloque diario"],
    ["Comunicación", "Mensajes y correos de clientes activos.", "Bloque diario"],
    ["Financiero", "Pagos recibidos, invoices y cuentas por cobrar.", "Bloque semanal"],
    ["Payroll", "Registro y consolidación de horas.", "Según ciclo de pago"],
    ["Operaciones", "Preparación, coordinación y asignación.", "Antes de la salida"],
    ["Revisión", "Pendientes, excepciones y problemas del día.", "Cierre de jornada"],
], [1.2 * inch, 3.5 * inch, 1.8 * inch], fs=8.5)

P("8.5 Agrupación de tareas similares", 'h1')
TAG("R")
P("Cambiar continuamente entre tareas reduce la capacidad de completar trabajo importante. Revisar un correo, "
  "contestar un mensaje, modificar una cita, revisar un pago y volver al correo inicial puede producir varias "
  "horas de actividad sin completar realmente una tarea. Por eso las tareas similares se agrupan:")
TBL([
    ["Agrupación", "Tareas"],
    ["Administración financiera", "Revisar pagos, invoices y payroll."],
    ["Ventas", "Revisar leads, cotizaciones y seguimientos."],
    ["Programación", "Revisar calendario y cambios de servicios."],
    ["Sistemas", "Actualizar procedimientos, registros y documentación."],
], [2.2 * inch, 4.3 * inch], fs=8.5)

P("8.6 Ficha del sistema administrativo", 'h1')
SOP("Administración general", [
    ["Objetivo", "Sostener el ciclo comercial y administrativo completo sin dependencia de la memoria individual."],
    ["Responsable principal", "Administración."],
    ["Responsable de respaldo", "Designado por la dirección."],
    ["Frecuencia", "Diaria, semanal y mensual según la capa correspondiente."],
    ["Inputs", "Leads entrantes, solicitudes de clientes, servicios ejecutados, pagos recibidos, incidencias de campo."],
    ["Outputs", "Schedule actualizado, leads con acción siguiente, invoices emitidos, horas consolidadas, registros al día."],
    ["Sistemas", "Sistema de gestión de servicios, sistema CRM y de comunicación, sistema de payroll, registros auxiliares."],
    ["Control", "Cumplimiento de rutinas y auditoría de calidad de datos (Capítulo 13)."],
    ["Escalamiento", "Según matriz del Capítulo 7.4."],
    ["Indicadores", "Rutinas completadas, leads sin acción, exactitud del schedule, incidencias de payroll."],
])

# ---------- CAP 9 ----------
CAP("9", "Gestión del tiempo y prioridades")
P("9.1 Objetivo", 'h1')
P("Establecer un sistema para distinguir entre lo importante y lo urgente, asignar correctamente el tiempo y "
  "evitar que todas las tareas sean tratadas como prioridades.")
BOX(None, [
    "<b>El objetivo no es estar ocupado todo el día. El objetivo es utilizar el tiempo en las actividades que "
    "realmente generan resultados para la empresa.</b>"])

P("9.2 Disciplina antes que motivación", 'h1')
TAG("R")
P("La administración del tiempo no depende de tener ganas de trabajar. Existen actividades poco atractivas, "
  "repetitivas o aburridas que siguen siendo necesarias. La disciplina consiste en ejecutarlas igual.")

P("9.3 Matriz de prioridades", 'h1')
TAG("R", "marco adoptado por Ecobay")
CPB(2.6)
TBL([
    ["Categoría", "Característica", "Acción", "Pregunta de control"],
    ["I", "Importante + Urgente", "HACER", "¿Tiene consecuencia hoy?"],
    ["II", "Importante + No urgente", "PROGRAMAR", "¿Cuándo queda agendado?"],
    ["III", "Urgente + No importante", "DELEGAR", "¿Tengo que hacerlo yo?"],
    ["IV", "No urgente + No importante", "ELIMINAR / AUTOMATIZAR", "¿Necesita hacerse siquiera?"],
], [0.8 * inch, 1.9 * inch, 1.8 * inch, 2.0 * inch], fs=8.5)

P("9.4 Cuadrante I — Hacer", 'h1')
B([
    "Situación urgente con un cliente.",
    "Problema que afecta un servicio programado del día.",
    "Situación que puede provocar la pérdida de un cliente.",
    "Asunto financiero o de payroll con fecha límite inmediata.",
    "Accidente, daño o incidente de seguridad.",
])
BOX("Señal de alerta", [
    "Una empresa que vive permanentemente en el Cuadrante I tiene un problema de organización, no de esfuerzo. "
    "Cuando una categoría de urgencia se repite, deja de ser una emergencia y pasa a ser un defecto de proceso que "
    "debe corregirse en el cuadrante II."])

P("9.5 Cuadrante II — Programar", 'h1')
P("Es el cuadrante que construye la empresa: documentar procesos, ordenar la administración, mejorar los "
  "registros, preparar una contratación futura, dar seguimiento a una oportunidad que aún no requiere atención "
  "inmediata y crear sistemas que reduzcan trabajo repetitivo.")
P("<b>Ejemplo confirmado.</b> Un prospecto solicita post-construction para dentro de un mes. Es importante, no "
  "urgente. En lugar de desplazar las tareas del día, se registra y se programa:")
FLOW(["Registrar", "Definir próximo paso", "Agendar", "Atender en la fecha"])
BOX(None, ["<b>«Tengo que hacer esto después» debe convertirse siempre en «esto está programado para tal fecha».</b>"])

P("9.6 Cuadrante III — Delegar", 'h1')
P("<b>Ejemplo confirmado.</b> Un cliente reporta que un área quedó mal limpiada. Es urgente, pero si la solución "
  "consiste en que la colaboradora regrese a corregir, no exige que la dirección ejecute personalmente el proceso.")
FLOW(["Cliente reporta", "Administración coordina", "Colaboradora corrige", "Se confirma resolución"])
BOX("Regla operativa", [
    "La urgencia no significa automáticamente que la tarea deba ser ejecutada personalmente por la dirección o "
    "por la administración."])

P("9.7 Cuadrante IV — Eliminar, automatizar o reducir", 'h1')
P("Ante una tarea repetitiva se evalúa si puede eliminarse, automatizarse, convertirse en procedimiento simple, "
  "delegarse o realizarse con menor frecuencia.")
P("<b>Ejemplo confirmado.</b> La revisión manual de cada aplicación de trabajo consume horas y muchos candidatos "
  "no cumplen requisitos básicos. En lugar de revisar cada solicitud desde cero se establece una preselección por "
  "criterios objetivos, con revisión humana posterior. El objetivo no es que una herramienta decida, sino que una "
  "persona no invierta horas filtrando lo que un criterio puede filtrar.")

P("9.8 Regla de decisión rápida", 'h1')
TAG("R")
TBL([
    ["Si la tarea es…", "Acción", "Registro que deja"],
    ["Importante y urgente", "Hacer", "Resultado y, si aplica, causa raíz"],
    ["Importante pero no urgente", "Programar", "Fecha comprometida"],
    ["Urgente sin requerir mi participación", "Delegar", "A quién y con qué plazo"],
    ["Ni importante ni urgente", "Eliminar, automatizar o reducir", "Decisión tomada"],
], [2.2 * inch, 2.3 * inch, 2.0 * inch], fs=8.5)

P("9.9 De la memoria al sistema", 'h1')
TAG("R")
P("Si una tarea debe recordarse constantemente, debe analizarse si puede registrarse en el sistema de gestión, "
  "agendarse, incorporarse a una checklist, convertirse en procedimiento, delegarse o automatizarse. Cada vez que "
  "aparezca la frase «eso yo ya sé cómo hacerlo», la siguiente pregunta del sistema es:")
story.append(Paragraph("«¿Dónde está documentado?»", S['quote']))
P("Si la respuesta es «en mi cabeza», el proceso todavía debe convertirse en SOP, checklist, tabla, política o "
  "automatización.")
BOX(None, [
    "<b>No todo lo que llega merece atención inmediata. No todo lo urgente requiere nuestra participación. No todo "
    "lo importante debe hacerse ahora. Y ninguna tarea repetitiva debería depender indefinidamente de la memoria "
    "de una sola persona.</b>"])

# ---------- CAP 10 ----------
CAP("10", "Rutinas administrativas diarias")
P("10.1 Propósito de la rutina diaria", 'h1')
P("La rutina diaria protege la operación del día en curso y evita que un lead, un cambio de horario o una "
  "incidencia se pierda. No sustituye el trabajo de fondo; lo hace posible al impedir que las urgencias se "
  "acumulen.")
TAG("P", "estructura propuesta a partir de las tareas confirmadas")

P("10.2 Apertura administrativa", 'h1')
CHK([
    "Revisar los servicios programados para el día.",
    "Revisar cambios registrados desde el cierre anterior.",
    "Verificar los equipos asignados a cada servicio.",
    "Revisar notas y condiciones especiales de cada propiedad.",
    "Identificar servicios especiales o de alcance ampliado.",
    "Confirmar la información de clientes nuevos del día.",
    "Revisar leads nuevos y llamadas o mensajes sin responder.",
    "Revisar oportunidades pendientes de acción siguiente.",
    "Confirmar que cada equipo tiene la información necesaria para salir.",
])

P("10.3 Durante la jornada", 'h1')
TBL([
    ["Evento", "Acción inmediata", "Registro"],
    ["Lead nuevo", "Responder y definir el próximo paso.", "Estado del lead y acción siguiente."],
    ["Llamada perdida", "Devolver la llamada lo antes posible.", "Resultado del contacto."],
    ["Cliente solicita cambio de horario", "Verificar disponibilidad y confirmar.", "Actualización del schedule."],
    ["Incidencia en la propiedad", "Coordinar la solución con Operations.", "Reporte de incidencia."],
    ["Queja de cliente", "Contener, coordinar corrección y confirmar cierre.", "Registro de queja y resolución."],
    ["Pago recibido", "Identificar cliente y servicio.", "Actualización del invoice."],
    ["Faltante de equipo o producto", "Resolver antes de la siguiente salida.", "Reporte de faltante."],
], [1.6 * inch, 2.7 * inch, 2.2 * inch], fs=8.5)

P("10.4 Cierre administrativo", 'h1')
CHK([
    "Confirmar los trabajos realizados.",
    "Actualizar cambios, reprogramaciones y cancelaciones.",
    "Verificar que las asignaciones de equipo quedaron correctas.",
    "Actualizar los invoices que correspondan.",
    "Registrar la información relevante de la jornada.",
    "Registrar horas trabajadas del día.",
    "Revisar qué tareas quedaron pendientes y programarlas.",
    "Revisar si alguna tarea importante se está posponiendo de forma repetida.",
    "Preparar los pendientes del día siguiente.",
])
BOX("Regla de cierre", [
    "Si una tarea importante continúa posponiéndose, debe programarse específicamente en lugar de mantenerse "
    "indefinidamente en una lista general."])

P("10.5 Excepciones de la rutina diaria", 'h1')
TBL([
    ["Situación", "Qué se hace"],
    ["Día sin servicios programados", "Se ejecuta igualmente el bloque comercial y el de revisión."],
    ["Ausencia del responsable de administración", "El respaldo designado ejecuta apertura y cierre como mínimo."],
    ["Volumen excepcional de leads", "Se prioriza la respuesta inicial; la calificación puede diferirse dentro del mismo día."],
    ["Emergencia operativa", "La rutina se interrumpe y se retoma en el cierre; la incidencia se documenta."],
], [2.3 * inch, 4.2 * inch], fs=8.5)

# ---------- CAP 11 ----------
CAP("11", "Rutinas administrativas semanales")
P("11.1 Propósito", 'h1')
P("La rutina semanal ordena la semana siguiente y consolida lo ocurrido en la que termina. Es el punto donde la "
  "empresa deja de reaccionar y empieza a planificar.")

P("11.2 Bloque de planificación", 'h1')
TAG("C", "la organización principal del calendario se realiza durante los fines de semana")
CHK([
    "Revisar todos los servicios de la semana siguiente.",
    "Confirmar cliente, dirección, tipo de servicio, fecha y hora de cada uno.",
    "Asignar equipos según la matriz de staffing.",
    "Identificar servicios que requieren equipo o productos especiales.",
    "Identificar propiedades con condiciones o preferencias particulares.",
    "Verificar la disponibilidad del personal para toda la semana.",
    "Detectar huecos de capacidad y sobrecargas.",
    "Confirmar los servicios con los clientes cuando corresponda.",
])

P("11.3 Bloque comercial semanal", 'h1')
CHK([
    "Revisar todos los leads abiertos y su estado.",
    "Identificar leads sin acción siguiente definida.",
    "Revisar cotizaciones enviadas sin respuesta y ejecutar el seguimiento.",
    "Cerrar como perdidos los leads que agotaron su secuencia de seguimiento.",
    "Revisar oportunidades de conversión a servicio recurrente.",
])

P("11.4 Bloque financiero semanal", 'h1')
CHK([
    "Revisar los pagos recibidos durante la semana.",
    "Relacionar cada pago con su cliente y servicio.",
    "Emitir o actualizar los invoices correspondientes.",
    "Identificar cuentas pendientes de cobro.",
    "Revisar inconsistencias entre servicios ejecutados y facturación.",
])

P("11.5 Bloque de horas y personal", 'h1')
CHK([
    "Consolidar las horas registradas por servicio y por colaborador.",
    "Verificar que todos los colaboradores que trabajaron estén incluidos.",
    "Verificar que no existan registros de quienes no trabajaron.",
    "Revisar duplicaciones y totales.",
    "Documentar cualquier inconsistencia antes de procesar pagos.",
])

P("11.6 Bloque de revisión semanal", 'h1')
TBL([
    ["Pregunta de revisión", "Acción si la respuesta revela un problema"],
    ["¿Qué servicios se ejecutaron y cuáles no?", "Documentar causa de cada excepción."],
    ["¿Hubo quejas o re-cleans?", "Analizar causa raíz y registrar acción correctiva."],
    ["¿Qué leads se perdieron y por qué?", "Registrar motivo de pérdida para análisis mensual."],
    ["¿Qué tareas importantes se pospusieron?", "Agendar con fecha concreta."],
    ["¿Qué situación urgente se repitió?", "Convertir en proceso preventivo."],
], [2.7 * inch, 3.8 * inch], fs=8.5)

# ---------- CAP 12 ----------
CAP("12", "Rutinas administrativas mensuales")
P("12.1 Propósito", 'h1')
P("La rutina mensual corrige el sistema. Mientras la diaria protege la operación y la semanal la ordena, la "
  "mensual detecta desviaciones estructurales y decide cambios.")
TAG("P")

P("12.2 Revisión de indicadores", 'h1')
P("Se revisan los indicadores definidos en la Parte XV, agrupados por área: comercial, clientes, operaciones, "
  "personal y financiero. Cada indicador que se desvía debe producir una decisión documentada, no solamente una "
  "observación.")

P("12.3 Auditoría mensual de datos y procesos", 'h1')
CHK([
    "Leads sin estado definido.",
    "Oportunidades sin acción siguiente.",
    "Cotizaciones sin seguimiento.",
    "Contactos duplicados.",
    "Clientes con información obligatoria incompleta.",
    "Conversaciones sin responder.",
    "Llamadas perdidas sin devolución registrada.",
    "Clientes sin seguimiento posterior al servicio.",
    "Clientes inactivos sin clasificar.",
    "Servicios ejecutados sin invoice.",
    "Horas registradas sin respaldo.",
    "Documentos del manual vencidos o sin revisión.",
])

P("12.4 Revisión de cartera de clientes", 'h1')
TBL([
    ["Segmento", "Qué se revisa", "Acción"],
    ["Clientes recurrentes activos", "Continuidad, incidencias y satisfacción.", "Retención."],
    ["Clientes puntuales recientes", "Posibilidad de conversión a recurrente.", "Oferta de recurrencia (Capítulo 24)."],
    ["Clientes sin servicio reciente", "Tiempo transcurrido y motivo.", "Clasificación para reactivación (Capítulo 25)."],
    ["Clientes perdidos", "Motivo documentado de la pérdida.", "Análisis de causa."],
], [1.7 * inch, 2.5 * inch, 2.3 * inch], fs=8.5)

P("12.5 Revisión operativa y de equipos", 'h1')
CHK([
    "Estado y mantenimiento de equipos y vehículos.",
    "Inventario de productos y consumibles.",
    "Equipo perdido o dañado reportado durante el mes.",
    "Faltantes recurrentes que indiquen un problema de reposición.",
    "Necesidades de personal para el mes siguiente.",
])

P("12.6 Revisión del propio manual", 'h1')
TBL([
    ["Pregunta", "Consecuencia"],
    ["¿Qué proceso se ejecutó de forma distinta a lo documentado?", "O se corrige la práctica o se corrige el manual."],
    ["¿Qué estándar propuesto se puso en práctica este mes?", "Se confirma o se ajusta en la siguiente versión."],
    ["¿Qué estándar propuesto fue aprobado?", "Cambia de etiqueta y pasa a ser obligatorio."],
    ["¿Qué proceso nuevo apareció sin documentar?", "Se levanta y se incorpora."],
], [3.2 * inch, 3.3 * inch], fs=8.5)

# ---------- CAP 13 ----------
CAP("13", "Gestión de información empresarial")
P("13.1 Principio", 'h1')
TAG("R")
BOX(None, [
    "<b>Ninguna información operativa relevante debe existir únicamente en teléfonos personales, mensajes "
    "privados, papeles sueltos, conversaciones aisladas o en la memoria de una persona.</b>"])
P("La contrapartida de este principio es igualmente importante: ningún sistema único almacena todo. Por eso la "
  "empresa mantiene una matriz que define, para cada tipo de información, cuál es la fuente de verdad.")

P("13.2 Matriz de fuente de verdad", 'h1')
TAG("P", "estructura de gobierno de datos; los sistemas concretos se detallan en la Parte X")
TBL([
    ["Información", "Fuente de verdad", "Responsable", "Frecuencia de actualización"],
    ["Relación y datos del cliente", "Sistema CRM", "Administración", "Al crear y al cambiar"],
    ["Comunicaciones con leads y clientes", "Sistema CRM / comunicación", "Administración", "Continua"],
    ["Pipeline comercial y estado de leads", "Sistema CRM", "Administración", "En cada interacción"],
    ["Servicios programados y ejecutados", "Sistema de gestión de servicios", "Administración", "Diaria"],
    ["Equipo asignado a cada servicio", "Sistema de gestión de servicios", "Administración / Operations", "Antes de la ejecución"],
    ["Notas y preferencias de la propiedad", "Sistema de gestión de servicios", "Administración", "Al conocerlas"],
    ["Invoices y estado de cobro", "Sistema de gestión de servicios", "Administración", "Semanal"],
    ["Transacciones bancarias", "Sistema bancario", "Administración", "Según banco"],
    ["Horas trabajadas", "Registro de horas", "Administración / Team Lead", "Diaria"],
    ["Pagos al personal", "Sistema de payroll", "Administración", "Por ciclo"],
    ["Expedientes de personal", "Archivo de personal", "Administración", "Al contratar y al cambiar"],
    ["Procedimientos y estándares", "Este manual y su sistema documental", "Owner", "Por versión"],
], [1.85 * inch, 1.75 * inch, 1.5 * inch, 1.4 * inch], fs=8)

P("13.3 Estándar de calidad de datos", 'h1')
TAG("R")
FLOW(["Correcta", "Completa", "Actualizada", "Consistente"])
TBL([
    ["Atributo", "Qué significa", "Cómo se verifica"],
    ["Correcta", "El dato refleja la realidad de la operación.", "Contraste con lo ejecutado."],
    ["Completa", "Todos los campos obligatorios están presentes.", "Auditoría de campos vacíos."],
    ["Actualizada", "El cambio quedó registrado en el momento en que ocurrió.", "Revisión de cierre diario."],
    ["Consistente", "El mismo concepto se nombra siempre igual.", "Nomenclatura oficial."],
], [1.2 * inch, 2.9 * inch, 2.4 * inch], fs=8.5)

P("13.4 Nomenclatura oficial", 'h1')
P("El objetivo de esta sección es impedir que el mismo concepto se registre de múltiples formas, lo que hace "
  "imposible medir. No es un detalle estético: si un servicio aparece como «Deep», «Deep Clean», «Deep Cleaning» y "
  "«Deepclean», ningún indicador de servicio será fiable, y una futura franquicia multiplicará el problema.")
TBL([
    ["Campo", "Valores propuestos"],
    ["Tipo de servicio", "Regular Cleaning · Deep Cleaning · Move-In · Move-Out · Post-Construction · Windows · Carpet Cleaning · Power Washing"],
    ["Origen del lead", "Website · Google LSA · Llamada directa · Referido · Cliente existente · Redes sociales · Otro"],
    ["Estado del cliente", "Prospecto · Activo recurrente · Activo puntual · Inactivo · Perdido"],
    ["Estado de recurrencia", "No recurrente · Cada 8 días · Cada 15 días · Mensual · Otro"],
    ["Motivo de pérdida", "Precio · Tiempo de respuesta · Fuera de cobertura · Servicio no ofrecido · Sin respuesta · Eligió otro proveedor · Otro"],
    ["Motivo de cancelación", "Cliente reprogramó · Cliente canceló definitivamente · Problema de acceso · Motivo económico · Insatisfacción · Otro"],
    ["Motivo de queja", "Área incompleta · Calidad insuficiente · Retraso · Daño · Trato · Alcance mal entendido · Otro"],
], [1.5 * inch, 5.0 * inch], fs=8)

P("13.5 Accesos y confidencialidad", 'h1')
TAG("P")
P("El acceso a los sistemas se asigna por posición y se limita a lo necesario para ejecutar los procesos de esa "
  "posición. No todos los usuarios requieren acceso administrativo completo.")
TBL([
    ["Nivel", "Posición", "Alcance de acceso"],
    ["1", "Colaborador", "Información de sus servicios asignados y materiales de capacitación."],
    ["2", "Team Lead", "Servicios de su equipo, notas de propiedad, registro de horas e incidencias."],
    ["3", "Administración", "Clientes, leads, schedule, comunicaciones, invoices y registros de horas."],
    ["4", "Operations", "Servicios, equipos, inventario, calidad e incidencias."],
    ["5", "Owner", "Acceso completo, incluida configuración e información financiera."],
], [0.5 * inch, 1.5 * inch, 4.5 * inch], fs=8.5)
BOX("Regla de accesos", [
    "Los accesos se asignan mediante cuentas individuales. No se comparten contraseñas entre personas: sin cuenta "
    "individual no hay trazabilidad de quién hizo qué, y no es posible retirar el acceso cuando alguien deja la "
    "empresa."])

# ---------- CAP 14 ----------
CAP("14", "Documentación y control de procesos")
P("14.1 Ciclo de vida de un proceso documentado", 'h1')
FLOW(["Levantar", "Documentar", "Aprobar", "Entrenar", "Ejecutar", "Auditar", "Mejorar"])
TBL([
    ["Etapa", "Qué ocurre", "Responsable", "Evidencia"],
    ["Levantar", "Se documenta cómo se hace hoy, sin corregirlo todavía.", "Administración / consultor", "Notas del levantamiento"],
    ["Documentar", "Se convierte en SOP con los campos obligatorios.", "Administración", "Borrador del SOP"],
    ["Aprobar", "La dirección valida, ajusta o rechaza.", "Owner", "Registro de versión"],
    ["Entrenar", "Se capacita a quien debe ejecutarlo.", "Operations", "Registro de capacitación"],
    ["Ejecutar", "Se aplica de manera consistente.", "Posición responsable", "Registros del proceso"],
    ["Auditar", "Se verifica cumplimiento y resultado.", "Owner / Operations", "Informe de auditoría"],
    ["Mejorar", "Se corrige el proceso o la práctica.", "Owner", "Nueva versión"],
], [0.95 * inch, 2.5 * inch, 1.5 * inch, 1.55 * inch], fs=8)

P("14.2 Metadatos obligatorios de todo documento", 'h1')
TAG("R")
TBL([
    ["Campo", "Propósito"],
    ["Nombre del documento", "Identificación inequívoca."],
    ["Versión", "Control de cambios."],
    ["Propietario del documento", "Quién responde por su exactitud."],
    ["Fecha de emisión", "Punto de partida de vigencia."],
    ["Última revisión", "Antigüedad real del contenido."],
    ["Próxima revisión", "Evita documentos obsoletos en circulación."],
    ["Estado", "Vigente, en revisión u obsoleto."],
    ["Capacitación requerida", "Quién debe ser entrenado antes de ejecutarlo."],
    ["Checklist relacionada", "Cómo se verifica su cumplimiento."],
], [2.2 * inch, 4.3 * inch], fs=8.5)

P("14.3 Regla de cambio", 'h1')
TAG("R")
BOX(None, [
    "<b>Ninguna práctica se convierte en política de Ecobay Cleaning LLC sin quedar documentada en una versión "
    "aprobada y registrada.</b>",
    "Correlato: si la práctica real difiere del manual, una de las dos está mal. La revisión mensual decide cuál "
    "y corrige la que corresponda."])

PARTE("III", "Leads, marketing y ventas",
      "Desde que un desconocido levanta la mano hasta que se convierte en cliente recurrente.",
      ["Capítulo 15. Origen de leads",
       "Capítulo 16. Lead Intake",
       "Capítulo 17. Lead Qualification",
       "Capítulo 18. Google Local Services Ads",
       "Capítulo 19. Website Leads",
       "Capítulo 20. Phone Leads",
       "Capítulo 21. SMS y Message Leads",
       "Capítulo 22. Seguimiento de leads",
       "Capítulo 23. Cotización",
       "Capítulo 24. Conversión de prospectos a clientes",
       "Capítulo 25. Reactivación de clientes",
       "Capítulo 26. Reviews, referrals y reputación"])

# ---------- CAP 15 ----------
CAP("15", "Origen de leads")
P("15.1 Objetivo de la Parte III", 'h1')
P("Garantizar que toda persona que manifiesta interés en contratar a Ecobay reciba una respuesta, sea calificada, "
  "reciba un precio adecuado al trabajo real y termine con un estado definido. Ningún lead puede quedar en un "
  "limbo indefinido.")
BOX(None, ["<b>Ningún lead sin respuesta. Ningún lead sin acción siguiente. Ningún lead sin estado final.</b>"])

P("15.2 Canales de origen", 'h1')
TAG("C", "canales confirmados durante el levantamiento; los demás requieren validación")
TBL([
    ["Canal", "Naturaleza del contacto", "Capítulo", "Estado"],
    ["Página web", "Formulario que llega por correo electrónico.", "19", "Confirmado"],
    ["Google Local Services Ads", "Llamada o mensaje desde el anuncio.", "18", "Confirmado"],
    ["Llamada directa", "Contacto telefónico al número del negocio.", "20", "Confirmado"],
    ["Mensaje de texto", "SMS o mensajería.", "21", "Confirmado"],
    ["Referido", "Recomendación de un cliente existente.", "26", "Activo"],
    ["Cliente existente", "Solicitud de servicio adicional.", "24", "Activo"],
    ["Redes sociales", "Mensaje o comentario.", "82-A", "Activo"],
], [1.5 * inch, 2.4 * inch, 0.8 * inch, 1.8 * inch], fs=8.5)

P("15.3 Registro obligatorio del origen", 'h1')
TAG("R")
P("Todo lead debe registrarse con su canal de origen usando la nomenclatura oficial del Capítulo 13.4. Sin ese "
  "dato es imposible saber qué canal genera clientes rentables y cuál solo genera trabajo administrativo, lo que "
  "convierte cualquier decisión de inversión en marketing en una apuesta.")
TBL([
    ["Pregunta que responde el origen", "Decisión que habilita"],
    ["¿De dónde vienen los leads que sí cierran?", "Dónde concentrar el esfuerzo comercial."],
    ["¿Qué canal genera leads fuera de cobertura o de servicio?", "Qué corregir en el mensaje o la segmentación."],
    ["¿Qué canal produce clientes recurrentes y no solo puntuales?", "Qué canal tiene mayor valor a largo plazo."],
    ["¿Qué canal exige mayor tiempo de respuesta?", "Cómo organizar el bloque comercial."],
], [3.3 * inch, 3.2 * inch], fs=8.5)

P("15.4 Indicadores del canal", 'h1')
TBL([
    ["Indicador", "Definición", "Fuente"],
    ["Leads por canal", "Número de leads recibidos en el período por origen.", "CRM"],
    ["Tiempo de respuesta", "Tiempo entre recepción y primer contacto efectivo.", "CRM"],
    ["Tasa de contacto", "Leads contactados sobre leads recibidos.", "CRM"],
    ["Tasa de cotización", "Leads cotizados sobre leads calificados.", "CRM"],
    ["Tasa de cierre", "Leads convertidos sobre leads cotizados.", "CRM"],
    ["Conversión a recurrente", "Clientes recurrentes sobre clientes nuevos del canal.", "CRM"],
], [1.6 * inch, 3.3 * inch, 1.6 * inch], fs=8.5)

# ---------- CAP 16 ----------
CAP("16", "Lead Intake")
SOP("Recepción y registro de leads", [
    ["Objetivo", "Capturar toda solicitud entrante con la información mínima necesaria y asignarle un estado y una acción siguiente."],
    ["Alcance", "Todos los canales del Capítulo 15."],
    ["Responsable principal", "Administración."],
    ["Responsable de respaldo", "Designado por la dirección."],
    ["Cuándo se ejecuta", "En el bloque comercial diario y ante cada notificación de lead nuevo."],
    ["Información necesaria", "Nombre, teléfono, correo, dirección o ZIP, servicio solicitado, datos de la propiedad, fecha deseada, origen del lead."],
    ["Sistemas", "Sistema CRM como fuente de verdad; sistema de gestión de servicios cuando el lead avanza a oportunidad."],
    ["Estándar esperado", "Ningún lead permanece sin registro ni sin acción siguiente al cierre de la jornada."],
    ["Registro requerido", "Ficha del lead con origen, estado y próxima acción."],
    ["KPI", "Tiempo de respuesta y leads sin acción siguiente."],
])

P("16.1 Información mínima de captura", 'h1')
TAG("C")
TBL([
    ["Campo", "¿Obligatorio?", "Por qué"],
    ["Nombre del cliente", "Sí", "Identificación y trato."],
    ["Teléfono", "Sí", "Canal de seguimiento más efectivo."],
    ["Correo electrónico", "Sí cuando exista", "Envío de cotización."],
    ["Dirección o ZIP code", "Sí", "Determina si está dentro de cobertura."],
    ["Servicio solicitado", "Sí", "Define staffing, equipo y precio."],
    ["Información de la propiedad", "Sí", "Tamaño, tipo, condición, ocupada o vacía."],
    ["Fecha o período requerido", "Sí", "Determina urgencia y programación."],
    ["Servicios adicionales", "Cuando aplique", "Ventanas u otros modifican el equipo."],
    ["Información especial del cliente", "Cuando exista", "Preferencias, acceso, mascotas, condiciones."],
    ["Origen del lead", "Sí", "Medición de canales."],
], [1.9 * inch, 1.2 * inch, 3.4 * inch], fs=8.5)

P("16.2 Flujo de intake", 'h1')
FLOW(["Lead recibido", "Revisar información", "Registrar", "Contactar", "Calificar"])
FLOW(["Cotizar o evaluar", "Programar", "Convertir en cliente"])
BOX("Regla", [
    "No debe asumirse que una persona que envió una solicitud ya es cliente. Primero se determina el estado de la "
    "oportunidad."])

P("16.3 Respuesta inicial", 'h1')
TAG("R")
P("Toda solicitud recibe una respuesta inicial que confirma la recepción y solicita la información faltante. La "
  "respuesta inicial nunca termina sin un próximo paso concreto para el prospecto.")
TBL([
    ["Elemento de la respuesta inicial", "Función"],
    ["Confirmación de recepción", "Elimina la incertidumbre del prospecto."],
    ["Identificación de Ecobay", "Establece con quién habla."],
    ["Solicitud de información faltante", "Permite calificar y cotizar."],
    ["Próximo paso concreto", "Evita que la conversación muera."],
    ["Referencia de tiempo", "Indica cuándo tendrá respuesta."],
], [3.0 * inch, 3.5 * inch], fs=8.5)

P("16.4 Automatización de la respuesta inicial", 'h1')
TAG("P", "requiere configuración y aprobación")
TBL([
    ["Disparador", "Acción automática", "Acción humana posterior"],
    ["Formulario web enviado", "Confirmación inmediata de recepción.", "Revisión y respuesta personalizada."],
    ["Llamada perdida", "Mensaje de texto automático de contacto.", "Devolución de la llamada."],
    ["Mensaje entrante", "Acuse de recepción si está fuera de horario.", "Respuesta y calificación."],
    ["Lead sin respuesta del prospecto", "Secuencia de seguimiento programada.", "Contacto directo antes del cierre."],
    ["Cotización enviada", "Recordatorio de seguimiento.", "Llamada de cierre."],
], [1.9 * inch, 2.4 * inch, 2.2 * inch], fs=8.5)
BOX("Regla de automatización", [
    "La automatización elimina trabajo repetitivo; no sustituye el criterio humano. Toda automatización debe "
    "definir qué ocurre ante una excepción y quién la recibe. Una automatización mal diseñada solamente automatiza "
    "el caos."])

P("16.5 Errores frecuentes en el intake", 'h1')
TBL([
    ["Error", "Consecuencia", "Prevención"],
    ["Responder sin registrar", "El lead existe solo en un teléfono o en la memoria.", "Registro antes o inmediatamente después del contacto."],
    ["Registrar sin origen", "Imposible medir el canal.", "Campo obligatorio."],
    ["Responder sin próximo paso", "El lead se enfría.", "Toda respuesta cierra con una acción."],
    ["Cotizar sin información suficiente", "Precio que no corresponde al trabajo.", "Criterio del Capítulo 23."],
    ["Asumir que el prospecto ya es cliente", "Se salta la calificación.", "Estado explícito del lead."],
], [1.9 * inch, 2.4 * inch, 2.2 * inch], fs=8.5)

# ---------- CAP 17 ----------
CAP("17", "Lead Qualification")
P("17.1 Objetivo", 'h1')
P("Determinar si la solicitud corresponde a un servicio que Ecobay presta, en un área que atiende, en condiciones "
  "que puede cumplir, y con qué método debe cotizarse. Calificar no es filtrar clientes: es evitar cotizar a "
  "ciegas y prometer lo que no puede entregarse.")

P("17.2 Preguntas de calificación", 'h1')
TAG("C", "guion levantado del procedimiento actual")
TBL([
    ["Pregunta", "Qué determina"],
    ["¿Qué tipo de limpieza necesita?", "Tipo de servicio y matriz de staffing."],
    ["¿Es residencial o comercial?", "Alcance y modelo de cotización."],
    ["¿Regular, deep, move-out, post-construction u otro?", "Kit, equipo y tiempo."],
    ["¿Cuál es la dirección o ZIP code?", "Cobertura geográfica."],
    ["¿Cuál es aproximadamente el tamaño de la propiedad?", "Personal y tiempo estimado."],
    ["¿Cuándo necesita el servicio?", "Urgencia y programación."],
    ["¿La casa está ocupada o vacía?", "Selección de productos y método."],
    ["¿Hay alguna condición especial?", "Riesgos, moho, sarro, acceso."],
    ["¿Necesita ventanas u otros servicios adicionales?", "Persona adicional y equipo."],
], [3.3 * inch, 3.2 * inch], fs=8.5)

P("17.3 Árbol de decisión de calificación", 'h1')
TAG("P")
TBL([
    ["Condición", "Resultado", "Acción"],
    ["Servicio fuera de la cartera de Ecobay", "No calificado", "Responder, informar y cerrar como servicio no ofrecido."],
    ["Dirección fuera del área de cobertura", "No calificado", "Responder, informar y cerrar como fuera de cobertura."],
    ["Servicio y área correctos, información completa", "Calificado", "Cotizar con precios establecidos."],
    ["Servicio y área correctos, información parcial", "Calificado con información pendiente", "Solicitar fotografías o video."],
    ["Trabajo complejo o condiciones inciertas", "Calificado con evaluación", "Programar evaluación presencial."],
    ["Oportunidad comercial o de alto valor", "Calificado con escalamiento", "Escalar a Owner antes de cotizar."],
    ["Fecha muy posterior", "Calificado, no urgente", "Registrar y programar el seguimiento."],
], [2.3 * inch, 1.7 * inch, 2.5 * inch], fs=8.5)
BOX("Regla confirmada", [
    "Un lead que no corresponde a Ecobay no se ignora. Se responde igualmente, se informa al prospecto y se cierra "
    "con un estado definido."])

P("17.4 Estructura de pipeline", 'h1')
TAG("P", "estructura recomendada; los nombres definitivos requieren aprobación")
TBL([
    ["Etapa", "Criterio de entrada", "Acción siguiente", "Criterio de salida"],
    ["Nuevo lead", "Solicitud recibida.", "Primer contacto.", "Contacto intentado."],
    ["Contacto intentado", "Se intentó contactar sin respuesta.", "Reintento según secuencia.", "Contacto logrado o cierre."],
    ["Contactado", "Conversación establecida.", "Calificar.", "Información suficiente."],
    ["Calificando", "En obtención de información.", "Completar datos.", "Calificado o descartado."],
    ["Requiere fotos o video", "Falta información visual.", "Solicitar material.", "Material recibido."],
    ["Requiere evaluación", "Trabajo complejo o incierto.", "Programar visita.", "Evaluación realizada."],
    ["Cotización lista", "Precio determinado.", "Enviar cotización.", "Cotización enviada."],
    ["Cotización enviada", "Prospecto tiene el precio.", "Seguimiento.", "Aceptada o rechazada."],
    ["En seguimiento", "Sin respuesta del prospecto.", "Secuencia de seguimiento.", "Respuesta o cierre."],
    ["Ganado", "Servicio aceptado.", "Programar.", "Servicio agendado."],
    ["Perdido", "Prospecto no contrata.", "Registrar motivo.", "Cerrado."],
    ["Nutrición futura", "No ahora, pero con potencial.", "Contacto programado.", "Reingreso al pipeline."],
], [1.35 * inch, 1.75 * inch, 1.7 * inch, 1.7 * inch], fs=8)

P("17.5 Regla de las etapas", 'h1')
TAG("R")
BOX(None, [
    "<b>Una oportunidad sin próximo paso definido es una oportunidad que fácilmente se pierde.</b>",
    "Toda etapa del pipeline, salvo Ganado y Perdido, debe tener una acción siguiente con fecha."])

P("17.6 Matriz humano vs. automatización", 'h1')
TAG("P")
TBL([
    ["Proceso", "Tratamiento"],
    ["Confirmación de recepción", "Automatizable"],
    ["Recordatorio de cita o servicio", "Automatizable"],
    ["Solicitud de información faltante", "Automatizable con revisión"],
    ["Calificación básica", "Automatización más revisión humana"],
    ["Cotización compleja o con evaluación", "Humano"],
    ["Oportunidad comercial o de alto valor", "Humano, con aprobación del Owner"],
    ["Queja o reclamo", "Humano"],
    ["Solicitud de reseña tras satisfacción confirmada", "Automatizable"],
    ["Campaña de reactivación", "Automatizable con escalamiento humano"],
], [3.9 * inch, 2.6 * inch], fs=8.5)

# ---------- CAP 18 ----------
CAP("18", "Google Local Services Ads")
P("18.1 Proceso empresarial", 'h1')
P("Google LSA es un canal de generación de leads que produce llamadas y mensajes. El proceso empresarial es el "
  "mismo que el de cualquier otro canal —responder, calificar, cotizar, cerrar— con dos particularidades: la "
  "velocidad de respuesta afecta el rendimiento del anuncio, y el lead debe trasladarse al sistema de gestión "
  "cuando avanza a oportunidad real.")
TAG("C")

P("18.2 Acceso", 'h1')
TAG("R")
P("El acceso se asigna a cada persona mediante su propia cuenta y con el nivel de permiso mínimo necesario para "
  "responder leads. No se comparten contraseñas generales.")
BOX("Nota de independencia tecnológica", [
    "La navegación concreta de la plataforma —secciones, menús y pantallas— pertenece a la guía de software de "
    "nivel 5 y no a este manual, porque Google está migrando cuentas de Local Services Ads hacia campañas de "
    "Performance Max, lo que cambia dónde aparecen los leads sin cambiar el proceso empresarial."])

P("18.3 Tipos de lead y tratamiento", 'h1')
TBL([
    ["Tipo", "Origen", "Tratamiento"],
    ["Phone lead", "El cliente llama desde el anuncio mediante número de forwarding.", "Capítulo 20."],
    ["Message lead", "El cliente envía un mensaje solicitando información.", "Capítulo 21."],
    ["Llamada perdida", "Llamada no atendida.", "Devolución obligatoria, sección 18.5."],
], [1.3 * inch, 3.0 * inch, 2.2 * inch], fs=8.5)

P("18.4 Regla de velocidad de respuesta", 'h1')
TAG("R")
BOX(None, [
    "<b>Un lead nuevo se trata como una oportunidad activa, no como un mensaje que puede esperar.</b>",
    "Una tasa elevada de llamadas o mensajes sin responder puede afectar el rendimiento del anuncio, además de "
    "perder la venta."])

P("18.5 Llamada perdida", 'h1')
TAG("C")
FLOW(["Llamada perdida", "Identificar cliente", "Devolver llamada", "Registrar resultado", "Seguimiento"])
P("Una llamada perdida no es un lead perdido. Puede recuperarse contactando al cliente por llamada, mensaje, "
  "correo o mensaje de voz. La devolución se realiza lo antes posible dentro del mismo día operativo.")

P("18.6 Estados y cierre", 'h1')
TAG("P")
TBL([
    ["Estados de proceso", "Estados de cierre"],
    ["Nuevo lead", "Ganado / agendado"],
    ["Contactado", "Perdido"],
    ["Esperando al cliente", "Fuera de cobertura o servicio no ofrecido"],
    ["Evaluación solicitada", "Servicio incorrecto"],
    ["Cotización enviada", "Duplicado"],
    ["Servicio agendado", "Sin respuesta"],
], [3.25 * inch, 3.25 * inch], fs=8.5)
BOX("Regla fundamental del canal", [
    "Nunca dejar un lead sin acción siguiente. Cada lead debe estar en uno de cuatro escenarios: responder, "
    "seguimiento, programar o cerrar. Lo que no debe existir es «lo vi y después se me olvidó»."])

P("18.7 Revisión diaria del canal", 'h1')
CHK([
    "Leads nuevos.",
    "Llamadas perdidas.",
    "Mensajes nuevos.",
    "Conversaciones pendientes de respuesta.",
    "Leads esperando respuesta del cliente.",
    "Leads que requieren seguimiento.",
    "Leads ya contratados pendientes de trasladar al sistema de gestión.",
    "Leads que deben cerrarse con motivo registrado.",
])

P("18.8 Traslado al sistema de gestión", 'h1')
TAG("R")
FLOW(["Lead del anuncio", "Recopilar información", "Registrar como oportunidad", "Cotizar", "Programar"])
P("No debe asumirse que un lead registrado en la plataforma publicitaria está correctamente registrado en el "
  "sistema de gestión de la operación. Son sistemas con funciones distintas y el traslado es un paso explícito "
  "del proceso.")

# ---------- CAP 19 ----------
CAP("19", "Website Leads")
P("19.1 Procedimiento actual", 'h1')
TAG("C", "procedimiento levantado, ejemplo de solicitud de post-construction")
TBL([
    ["Paso", "Acción", "Detalle confirmado"],
    ["1", "Detectar el lead", "La solicitud llega por correo electrónico y se revisa desde teléfono o computadora."],
    ["2", "Capturar la información", "Desde el teléfono se toma captura de pantalla; desde la computadora se usa el correo."],
    ["3", "Preparar la respuesta", "Se apoya la redacción en una herramienta, con la información del lead y la información existente de Ecobay, para mantener comunicación consistente y reducir tiempo."],
    ["4", "Incluir el siguiente paso", "Por ejemplo, ofrecer disponibilidad para visitar y evaluar la propiedad."],
    ["5", "Enviar la respuesta", "Se responde directamente al correo recibido."],
    ["6", "Esperar respuesta", "Se mantiene el lead en seguimiento."],
    ["7", "Seguimiento", "Si no responde, se contacta por mensaje de texto indicando que se recibió su solicitud, que se envió un correo y cómo comunicarse con la empresa."],
], [0.45 * inch, 1.5 * inch, 4.55 * inch], fs=8.5)

P("19.2 Estándar del canal", 'h1')
TAG("P")
TBL([
    ["Elemento", "Estándar propuesto"],
    ["Registro", "El lead se registra en el CRM antes de responder o inmediatamente después."],
    ["Consistencia", "La respuesta mantiene la información y el tono oficial de Ecobay."],
    ["Contenido", "Confirma recepción, solicita datos faltantes y propone próximo paso."],
    ["Trazabilidad", "La conversación queda centralizada, no dispersa en correos personales."],
    ["Seguimiento", "Si no hay respuesta, se activa la secuencia del Capítulo 22."],
], [1.5 * inch, 5.0 * inch], fs=8.5)

P("19.3 Riesgo específico del canal", 'h1')
P("Al llegar por correo, este lead depende de que alguien abra el correo. Si el volumen crece o la persona "
  "responsable no está disponible, el canal se detiene silenciosamente: no hay alarma, simplemente deja de haber "
  "clientes nuevos. Por eso el canal requiere confirmación automática de recepción, registro en el CRM y un "
  "responsable de respaldo designado.")

# ---------- CAP 20 ----------
CAP("20", "Phone Leads")
P("20.1 Estándar de atención telefónica", 'h1')
TAG("C")
P("La llamada se contesta identificando a la empresa y a la persona que atiende, y ofreciendo ayuda. Ejemplo "
  "confirmado de apertura:")
story.append(Paragraph("«Thank you for calling Ecobay Cleaning, this is ______. How can I help you?»", S['quote']))

P("20.2 Estructura de la llamada", 'h1')
TAG("P")
TBL([
    ["Momento", "Objetivo", "Contenido"],
    ["Apertura", "Identificar la empresa y generar confianza.", "Saludo, nombre de la empresa y de quien atiende."],
    ["Descubrimiento", "Entender la necesidad real.", "Preguntas de calificación del Capítulo 17.2."],
    ["Verificación", "Confirmar que Ecobay puede atenderlo.", "Servicio, cobertura y fecha."],
    ["Definición de método", "Decidir cómo se cotizará.", "Criterio del Capítulo 23.3."],
    ["Cierre de la llamada", "Dejar un compromiso concreto.", "Qué se enviará, quién lo hará y cuándo."],
    ["Registro", "Que la llamada exista fuera de la memoria.", "Ficha del lead actualizada."],
], [1.4 * inch, 2.3 * inch, 2.8 * inch], fs=8.5)

P("20.3 Errores frecuentes", 'h1')
TBL([
    ["Error", "Efecto"],
    ["Dar un precio sin conocer condición y tamaño de la propiedad", "Cotización que no corresponde al trabajo real."],
    ["Terminar la llamada sin próximo paso", "El prospecto queda esperando y se enfría."],
    ["No registrar la llamada", "El lead desaparece si la persona no la recuerda."],
    ["Prometer una fecha sin verificar el schedule", "Conflicto de programación y reprogramación forzada."],
    ["No preguntar por servicios adicionales", "Staffing y equipo mal dimensionados."],
], [3.0 * inch, 3.5 * inch], fs=8.5)

P("20.4 Llamadas fuera de horario", 'h1')

# ---------- CAP 21 ----------
CAP("21", "SMS y Message Leads")
P("21.1 Procedimiento", 'h1')
TAG("C")
NUM([
    "Abrir la bandeja de mensajes del canal correspondiente.",
    "Seleccionar el lead y revisar la información proporcionada.",
    "Identificar qué servicio solicita.",
    "Revisar nombre, ZIP code, teléfono y detalles del trabajo.",
    "Responder directamente desde la conversación.",
    "Obtener la información faltante.",
    "Determinar el siguiente paso.",
    "Registrar el resultado.",
])

P("21.2 Estructura de la primera respuesta", 'h1')
TAG("C", "ejemplo confirmado; la plantilla definitiva requiere aprobación")
P("La primera respuesta debe ser rápida, profesional, clara y orientada al siguiente paso.")
story.append(Paragraph(
    "«Hi! Thank you for contacting Ecobay Cleaning. We'd be happy to help. Could you please provide the address or "
    "ZIP code, the type of cleaning you're looking for, and your preferred date? Once we have that information, we "
    "can determine the best next step for your cleaning.»", S['quote']))

P("21.3 Reglas del canal escrito", 'h1')
TAG("P")
TBL([
    ["Regla", "Razón"],
    ["Una sola conversación por cliente, centralizada.", "Evita versiones distintas de la misma negociación."],
    ["No trasladar la conversación a mensajería personal.", "La empresa perdería el registro."],
    ["Toda respuesta contiene una pregunta o un próximo paso.", "Mantiene la conversación viva."],
    ["No enviar precios complejos por mensaje sin confirmar condiciones.", "Evita compromisos mal calculados."],
    ["Respetar la frecuencia de contacto de la secuencia de seguimiento.", "Evita percepción invasiva."],
], [3.3 * inch, 3.2 * inch], fs=8.5)

# ---------- CAP 22 ----------
CAP("22", "Seguimiento de leads")
P("22.1 Principio", 'h1')
P("El seguimiento es el proceso donde se pierde la mayor parte del valor comercial de una empresa pequeña: no "
  "porque el prospecto diga que no, sino porque nadie vuelve a contactarlo. El seguimiento no puede depender de "
  "que alguien recuerde hacerlo.")

P("22.2 Secuencia de seguimiento", 'h1')
TAG("P", "la cantidad e intervalo de contactos requieren aprobación")
TBL([
    ["Momento", "Canal", "Contenido", "Si no responde"],
    ["Contacto 1", "Canal de origen", "Respuesta inicial y solicitud de información.", "Pasa a contacto 2."],
    ["Contacto 2", "Canal alterno", "Aviso de que se envió información y cómo comunicarse.", "Pasa a contacto 3."],
    ["Contacto 3", "Llamada", "Contacto directo para resolver dudas.", "Pasa a contacto 4."],
    ["Contacto 4", "Mensaje", "Último intento con próximo paso claro.", "Cierre o nutrición."],
], [1.1 * inch, 1.2 * inch, 2.5 * inch, 1.7 * inch], fs=8.5)
TAG("C", "el paso confirmado hoy es el seguimiento por mensaje de texto cuando no hay respuesta al correo")

P("22.3 Cierre de un lead", 'h1')
TAG("R")
P("Un lead se cierra con un motivo registrado usando la nomenclatura oficial. Un lead cerrado sin motivo es un "
  "dato perdido: impide saber si Ecobay pierde por precio, por tiempo de respuesta, por cobertura o por servicio "
  "no ofrecido, que son cuatro problemas con cuatro soluciones distintas.")
TBL([
    ["Motivo de pérdida", "Qué revela", "Acción correctiva típica"],
    ["Precio", "Posicionamiento o alcance mal comunicado.", "Revisar argumentación de valor."],
    ["Tiempo de respuesta", "Falla del proceso, no del mercado.", "Revisar rutina y automatización."],
    ["Fuera de cobertura", "Segmentación del canal.", "Ajustar anuncio o mensaje."],
    ["Servicio no ofrecido", "Demanda no atendida.", "Evaluar ampliar cartera."],
    ["Sin respuesta", "Seguimiento insuficiente o lead de baja intención.", "Revisar secuencia."],
    ["Eligió otro proveedor", "Competencia.", "Revisar diferenciación."],
], [1.5 * inch, 2.6 * inch, 2.4 * inch], fs=8.5)

P("22.4 Nutrición de leads no cerrados", 'h1')
TAG("P")
P("Un prospecto que no contrata ahora no siempre es un prospecto perdido. Los leads con potencial —por ejemplo, "
  "quien solicitó un servicio para más adelante o quien pospuso la decisión— pasan a nutrición con un contacto "
  "programado, en lugar de desaparecer.")

P("22.5 Auditoría del pipeline", 'h1')
CHK([
    "Leads sin estado definido.",
    "Oportunidades sin acción siguiente.",
    "Cotizaciones enviadas sin seguimiento.",
    "Leads detenidos más allá del plazo previsto en una misma etapa.",
    "Leads cerrados sin motivo registrado.",
    "Contactos duplicados.",
    "Leads sin origen registrado.",
])

# ---------- CAP 23 ----------
CAP("23", "Cotización")
SOP("Determinación del precio y emisión de cotización", [
    ["Objetivo", "Entregar un precio que corresponda razonablemente al trabajo que Ecobay tendrá que realizar."],
    ["Alcance", "Todos los servicios y todos los canales."],
    ["Responsable principal", "Administración para precios establecidos; Owner para evaluación presencial y precios excepcionales."],
    ["Cuándo se ejecuta", "Una vez que el lead está calificado y se ha determinado el método de evaluación."],
    ["Información necesaria", "Tipo de servicio, tamaño, condición, ocupada o vacía, superficies, servicios adicionales, fecha, preferencias."],
    ["Sistemas", "Sistema de gestión de servicios como referencia de precios; CRM para el registro de la oportunidad."],
    ["Estándar esperado", "Ninguna cotización se emite sin información suficiente sobre el alcance real."],
    ["Registro requerido", "Método de evaluación utilizado, información en que se basó y precio enviado."],
    ["Escalamiento", "Precio fuera de tarifa, descuentos y oportunidades comerciales de alto valor."],
    ["KPI", "Tasa de cotización, tasa de cierre y desviación entre tiempo estimado y real."],
])

P("23.1 Los tres métodos de evaluación", 'h1')
TAG("C")

P("A. Consulta de precios establecidos", 'h2')
P("Cuando el servicio y las características de la propiedad permiten utilizar precios previamente establecidos, se "
  "consulta el sistema de gestión para determinar el precio. Esto mantiene consistencia y evita que cada "
  "cotización dependa de la memoria o del criterio personal de quien atiende.")

P("B. Solicitud de fotografías y videos", 'h2')
P("Cuando no es necesario visitar la propiedad, se solicita al prospecto material visual de las áreas que "
  "necesitan limpieza. El material permite evaluar:")
B([
    "Condición general de la propiedad.",
    "Nivel de suciedad.",
    "Cantidad de muebles u objetos.",
    "Estado de baños y cocina.",
    "Acumulación de grasa, polvo o residuos.",
    "Condiciones especiales.",
    "Alcance aproximado del trabajo.",
])
P("El material debe revisarse antes de determinar el precio cuando el estado de la propiedad pueda afectar "
  "significativamente el trabajo.")

P("C. Evaluación presencial", 'h2')
P("Cuando la información no es suficiente, el trabajo es complejo o conviene conocer personalmente las "
  "condiciones, la dirección realiza una visita de evaluación, que permite revisar:")
B([
    "Tamaño y distribución de la propiedad.",
    "Condición de las diferentes áreas.",
    "Tipo de superficies.",
    "Nivel de suciedad.",
    "Necesidad de personal adicional.",
    "Necesidad de equipo especializado.",
    "Ventanas u otros servicios adicionales.",
    "Cualquier condición que pueda afectar el tiempo o el costo del trabajo.",
])

P("23.2 Criterio de selección del método", 'h1')
TAG("R")
TBL([
    ["Situación", "Método", "Responsable"],
    ["Información suficiente y servicio conocido", "Precios establecidos en el sistema.", "Administración"],
    ["Información parcialmente suficiente", "Solicitar fotografías y/o videos.", "Administración"],
    ["Trabajo complejo, condiciones inciertas o necesidad de mayor precisión", "Evaluación presencial.", "Owner"],
], [2.9 * inch, 2.3 * inch, 1.3 * inch], fs=8.5)
P("Los métodos pueden combinarse. Por ejemplo, solicitar fotografías inicialmente y, tras revisarlas, determinar "
  "que es necesaria una visita.")

P("23.3 Regla de cotización", 'h1')
TAG("R")
BOX(None, [
    "<b>El objetivo no es entregar un precio rápidamente, sino entregar un precio que corresponda razonablemente "
    "al trabajo que Ecobay tendrá que realizar.</b>",
    "La herramienta debe facilitar la decisión, no reemplazar el criterio de la persona responsable."])

P("23.4 Variables que modifican el esfuerzo", 'h1')
TAG("C")
TBL([
    ["Variable", "Efecto sobre el servicio"],
    ["Tipo de servicio y frecuencia", "Determina el equipo base y el número de personas."],
    ["Tamaño de la propiedad", "Escala el tiempo y puede exigir personal adicional."],
    ["Condición de la propiedad", "Determina productos, herramientas y tiempo."],
    ["Ocupada o vacía", "Condiciona la selección de productos y el método."],
    ["Ventanas", "Incorpora una persona adicional al equipo."],
    ["Tipo de superficies", "Determina productos y precauciones específicas."],
    ["Moho, sarro o acumulación fuerte", "Exige productos y herramientas de mayor intensidad."],
    ["Preferencia por productos ecológicos", "Restringe la selección de producto en Deep Cleaning."],
], [2.5 * inch, 4.0 * inch], fs=8.5)

P("23.5 Contenido de la cotización", 'h1')
TAG("P")
TBL([
    ["Elemento", "Por qué es necesario"],
    ["Servicio contratado y su alcance", "Evita expectativas divergentes."],
    ["Qué incluye y qué no incluye", "Previene reclamos por alcance."],
    ["Tamaño o referencia de la propiedad", "Justifica el precio."],
    ["Servicios adicionales cotizados aparte", "Transparencia."],
    ["Condiciones y preferencias registradas", "Traslada la información al equipo."],
    ["Vigencia de la cotización", "Protege el precio ante cambios de condición."],
    ["Próximo paso para contratar", "Facilita el cierre."],
], [2.9 * inch, 3.6 * inch], fs=8.5)

P("23.6 Del precio al servicio", 'h1')
P("Una cotización aceptada activa dos procesos: la programación del servicio, con su asignación de equipo, y el "
  "traslado de toda la información de calificación —condición, preferencias, superficies, servicios adicionales— "
  "a las notas del servicio. Esa información es la que permite que la preparación del vehículo no dependa de la "
  "memoria de quien cotizó.")
FLOW(["Cotización aceptada", "Registrar condiciones", "Programar", "Asignar equipo", "Preparar"])

# ---------- CAP 24 ----------
CAP("24", "Conversión de prospectos a clientes")
P("24.1 Qué es un cliente en Ecobay", 'h1')
TAG("P")
TBL([
    ["Estado", "Definición", "Gestión que recibe"],
    ["Prospecto", "Solicitó información; no ha contratado.", "Pipeline comercial."],
    ["Cliente puntual", "Contrató un servicio sin recurrencia.", "Seguimiento post-servicio y oferta de recurrencia."],
    ["Cliente recurrente", "Servicio periódico establecido.", "Retención y control de calidad sostenido."],
    ["Cliente inactivo", "Sin servicio en el período definido.", "Campaña de reactivación."],
    ["Cliente perdido", "Baja explícita o pérdida confirmada.", "Análisis de causa."],
], [1.3 * inch, 2.6 * inch, 2.6 * inch], fs=8.5)

P("24.2 Sistema de conversión a recurrente", 'h1')
TAG("P")
FLOW(["Cliente puntual", "Servicio ejecutado", "Satisfacción confirmada", "Oferta de recurrencia", "Cliente recurrente"])
TBL([
    ["Etapa", "Qué debe ocurrir", "Responsable", "Registro"],
    ["Servicio ejecutado", "Inspección final y cierre correcto.", "Team Lead", "Resultado de inspección."],
    ["Verificación de satisfacción", "Contacto posterior al servicio.", "Administración", "Respuesta del cliente."],
    ["Satisfacción confirmada", "Sin incidencias abiertas.", "Administración", "Estado del cliente."],
    ["Oferta de recurrencia", "Propuesta de servicio periódico.", "Administración", "Respuesta y frecuencia elegida."],
    ["Alta como recurrente", "Programación periódica y preferencias registradas.", "Administración", "Servicio recurrente activo."],
], [1.4 * inch, 2.2 * inch, 1.4 * inch, 1.5 * inch], fs=8)
BOX("Regla de la oferta", [
    "La oferta de recurrencia se presenta solo después de confirmar satisfacción. Ofrecer recurrencia a un cliente "
    "con una incidencia abierta convierte una queja en una fuga. No se definen aquí precios ni descuentos: eso "
    "corresponde a la dirección."])

P("24.3 Alta del cliente", 'h1')
CHK([
    "Datos de contacto completos y verificados.",
    "Dirección y referencias de acceso.",
    "Tipo de servicio y frecuencia acordada.",
    "Alcance contratado, con inclusiones y exclusiones.",
    "Preferencias de producto, en particular la preferencia ecológica.",
    "Condiciones de la propiedad relevantes para la preparación.",
    "Método de pago acordado.",
    "Origen del lead registrado.",
    "Notas para el equipo que ejecutará el servicio.",
])

P("24.4 Traspaso de venta a operación", 'h1')
P("La conversión no termina cuando el cliente acepta: termina cuando toda la información recogida durante la "
  "venta está disponible para quien prepara el vehículo y para quien ejecuta el servicio. Un traspaso incompleto "
  "produce el patrón más caro de la operación: un cliente que contrató una cosa y un equipo que llegó preparado "
  "para otra.")

# ---------- CAP 25 ----------
CAP("25", "Reactivación de clientes")
P("25.1 La base de clientes como activo", 'h1')
TAG("C")
P("La base de contactos puede incluir clientes actuales, antiguos, de servicio único, quienes dejaron de utilizar "
  "el servicio y quienes no han vuelto a reservar. Esta base representa un activo comercial que actualmente puede "
  "no estar siendo aprovechado de manera sistemática.")

P("25.2 Lo que la reactivación no debe ser", 'h1')
FLOW(["Buscar cliente", "Copiar número", "Escribir mensaje", "Enviar", "Repetir 200 veces"])
P("Debe evolucionar hacia un proceso segmentado y automatizado, con intervención humana donde el criterio importa:")
FLOW(["Segmentar", "Crear campaña", "Automatizar", "Monitorear respuestas", "Convertir"])

P("25.3 Criterios de segmentación", 'h1')
TAG("P")
TBL([
    ["Criterio", "Por qué importa"],
    ["Tiempo desde el último servicio", "Determina el mensaje y la probabilidad de retorno."],
    ["Tipo de servicio realizado", "Un cliente de post-construction no se reactiva como uno recurrente."],
    ["Frecuencia histórica", "Distingue al cliente estable del ocasional."],
    ["Valor histórico", "Prioriza el esfuerzo comercial."],
    ["Satisfacción registrada", "Un cliente que se fue insatisfecho requiere recuperación, no promoción."],
    ["Motivo de pérdida cuando esté disponible", "Determina si la reactivación tiene sentido."],
], [2.4 * inch, 4.1 * inch], fs=8.5)

P("25.4 Flujo de campaña", 'h1')
FLOW(["Segmento", "Mensaje", "Automatización", "Seguimiento humano", "Ganado o cerrado"])
TBL([
    ["Paso", "Responsable", "Registro"],
    ["Definición del segmento", "Administración", "Criterio aplicado y tamaño del segmento."],
    ["Aprobación del mensaje y de la oferta", "Owner", "Contenido aprobado."],
    ["Envío", "Automatización", "Fecha y alcance."],
    ["Respuestas", "Administración", "Reingreso al pipeline comercial."],
    ["Cierre", "Administración", "Ganado o motivo de no retorno."],
], [2.3 * inch, 2.0 * inch, 2.2 * inch], fs=8.5)

P("25.5 Límites de contacto", 'h1')
TAG("R")
BOX(None, [
    "<b>La reactivación no puede convertirse en saturación.</b> Un cliente que recibe mensajes excesivos deja de "
    "ser un cliente reactivable y pasa a ser un contacto perdido."])

# ---------- CAP 26 ----------
CAP("26", "Reviews, referrals y reputación")
P("26.1 Principio", 'h1')
TAG("R")
BOX(None, [
    "<b>Primero se detecta el problema; después se pide la reseña.</b> Nunca se solicita una reseña pública sin "
    "haber verificado antes la satisfacción del cliente."])

P("26.2 Flujo de reputación", 'h1')
TAG("P")
FLOW(["Servicio completado", "Verificación de satisfacción", "Satisfecho", "Solicitud de reseña"])
P("Cuando el cliente indica una experiencia negativa, el flujo cambia por completo:")
FLOW(["Feedback negativo", "Sin solicitud de reseña", "Contacto humano", "Recuperación", "Resolución", "Cierre"])
TBL([
    ["Situación", "Acción", "Responsable", "Prohibido"],
    ["Cliente satisfecho", "Solicitud de reseña.", "Automatizable", "—"],
    ["Cliente con observación menor", "Contacto humano y corrección.", "Administración", "Pedir reseña antes de resolver."],
    ["Cliente insatisfecho", "Recuperación del servicio.", "Administración y Operations", "Solicitud automática de reseña pública."],
    ["Reseña pública negativa", "Respuesta aprobada por dirección.", "Owner", "Responder sin revisión."],
], [1.5 * inch, 2.1 * inch, 1.6 * inch, 1.3 * inch], fs=8)
BOX("Límite ético", [
    "No se diseñan tácticas para manipular reseñas, filtrar clientes insatisfechos del canal público ni incentivar "
    "reseñas a cambio de beneficios no declarados. El objetivo del sistema es detectar problemas antes de pedir "
    "una reseña, no ocultarlos."])

P("26.3 Referidos", 'h1')
TAG("P")
P("El referido es el lead de mayor tasa de cierre y menor costo. Requiere tres condiciones: un servicio bien "
  "ejecutado, un momento adecuado para pedirlo y un mecanismo simple para que el cliente lo haga.")
TBL([
    ["Elemento", "Definición"],
    ["Cuándo se solicita", "Después de satisfacción confirmada, no antes."],
    ["Quién lo solicita", "Administración o Customer Success."],
    ["Cómo se registra", "Origen «Referido» y cliente que refiere."],
    ["Reconocimiento al referente", "Definido por la dirección para cada campaña."],
    ["Seguimiento del referido", "Entra al pipeline comercial como cualquier lead."],
], [2.0 * inch, 4.5 * inch], fs=8.5)

P("26.4 Indicadores de reputación", 'h1')
TBL([
    ["Indicador", "Definición"],
    ["Solicitudes de reseña enviadas", "Sobre servicios completados con satisfacción confirmada."],
    ["Reseñas obtenidas", "Número de reseñas publicadas en el período."],
    ["Calificación promedio", "Media de las calificaciones recibidas."],
    ["Feedback negativo detectado", "Casos identificados antes de llegar a canal público."],
    ["Casos de recuperación cerrados", "Incidencias resueltas con confirmación del cliente."],
    ["Referidos generados", "Leads con origen «Referido»."],
], [2.3 * inch, 4.2 * inch], fs=8.5)

PARTE("III-B", "Ampliación comercial",
      "Venta consultiva entrante, desarrollo de cuentas comerciales y protección contractual del servicio.",
      ["Capítulo 23-A. Venta consultiva inbound",
       "Capítulo 23-B. Desarrollo comercial outbound",
       "Capítulo 23-C. Contratos y términos de servicio"])

# ---------- CAP 23-A ----------
CAP("23-A", "Venta consultiva inbound")
P("23-A.1 Filosofía", 'h1')
TAG("R")
BOX(None, [
    "<b>Las personas no compran limpieza. Compran tranquilidad, confianza, cumplimiento y la certeza de que su "
    "propiedad estará en buenas manos.</b>",
    "Por eso cada conversación debe sentirse como una asesoría profesional, no como un discurso de ventas."])
P("Una llamada entrante es la oportunidad comercial más valiosa de la empresa: el cliente ya dio el primer paso, "
  "lo que significa que existe un interés, una necesidad o un problema que quiere resolver. La venta comienza en "
  "el momento en que el teléfono suena.")

P("23-A.2 Objetivos de la llamada", 'h1')
B([
    "Comprender la necesidad real del cliente.",
    "Identificar el tipo de servicio requerido.",
    "Calificar la oportunidad.",
    "Generar confianza.",
    "Resolver las dudas iniciales.",
    "Programar una evaluación presencial cuando sea necesario.",
    "Preparar la información para elaborar la propuesta.",
    "Cerrar la venta cuando las condiciones lo permitan.",
])

P("23-A.3 Por qué llama realmente el cliente", 'h1')
P("Nadie llama buscando una empresa de limpieza. Llaman porque necesitan resolver una situación específica. "
  "Identificar cuál es esa situación determina todo el resto de la conversación.")
TBL([
    ["Situación detrás de la llamada", "Qué implica para la venta"],
    ["El proveedor actual no cumple", "La prioridad es consistencia y comunicación, no precio."],
    ["Nueva propiedad o nueva ubicación", "Hay fecha de inicio y urgencia real."],
    ["Edificio recién construido", "Es post-construcción, no limpieza regular."],
    ["Inspección próxima", "Existe una fecha límite que fija el ritmo."],
    ["Quejas de residentes o empleados", "El dolor es reputacional, no operativo."],
    ["Problemas de calidad", "Se venderá supervisión y control, no tarifa."],
    ["Falta de personal interno", "Se evalúa reemplazar personal propio."],
    ["Crecimiento de la empresa", "Oportunidad de cuenta multi-ubicación."],
    ["Tardanzas e inconsistencias", "Se venderá cumplimiento de horario."],
], [2.6 * inch, 3.9 * inch], fs=8.5)

P("23-A.4 Atención de la llamada", 'h1')
TAG("R")
TBL([
    ["Elemento", "Estándar", "Nivel"],
    ["Tiempo de respuesta", "Contestar antes del tercer timbre.", "Estándar"],
    ["Voz", "Clara, con energía y ritmo natural; sonreír mientras se habla.", "Estándar"],
    ["Apertura", "Saludo, nombre de la empresa, nombre propio y ofrecimiento de ayuda.", "No negociable"],
    ["Primeros treinta segundos", "Transmitir profesionalismo, seguridad, disposición, confianza y organización.", "No negociable"],
    ["Primeros minutos", "Dedicados exclusivamente a entender.", "No negociable"],
], [1.5 * inch, 3.6 * inch, 1.4 * inch], fs=8.5)
story.append(Paragraph(
    "«Good morning, thank you for calling Ecobay Cleaning. My name is ______. How may I assist you today?»",
    S['quote']))
P("Tras la apertura, el cliente explica el motivo. No se interrumpe, no se asume y no se empieza hablando de "
  "precios. Cuando la respuesta es genérica —«estamos buscando una empresa para limpiar nuestra oficina»— se abre "
  "la conversación sin dirigirla:")
story.append(Paragraph("«I'd be happy to help. Could you tell me a little more about what you're looking for?»",
                       S['quote']))

P("23-A.5 Lo que nunca se hace en la apertura", 'h1')
TAG("R")
B([
    "Hablar más que el cliente.",
    "Enumerar todos los servicios de la empresa.",
    "Ofrecer descuentos de inmediato.",
    "Dar precios sin conocer el alcance del trabajo.",
    "Interrumpir mientras el cliente explica su situación.",
    "Asumir que todas las necesidades son iguales.",
    "Intentar cerrar antes de comprender el proyecto.",
])

P("23-A.6 Descubrimiento en tres etapas", 'h1')
TAG("R")
BOX(None, [
    "<b>La regla del 80/20:</b> el cliente debe hablar aproximadamente el 80% de la conversación y el "
    "representante el 20%. Si el representante habla de más, pierde la información que decide la venta."])
TBL([
    ["Etapa", "Objetivo", "Preguntas"],
    ["1. Operación", "Entender la instalación y cómo se mantiene hoy.", "«Can you tell me a little about your facility?» · «What type of property are you calling about today?» · «How is the building currently being maintained?»"],
    ["2. Necesidad", "Descubrir el motivo real de la llamada.", "«What made you start looking for a cleaning company?» · «What would you like to improve?» · «Is this for a new location or are you replacing your current provider?» · «What has your experience been with your current vendor?»"],
    ["3. Prioridades", "Saber qué pesa más en la decisión.", "«What is most important to you when choosing a cleaning company?»"],
], [1.1 * inch, 1.7 * inch, 3.7 * inch], fs=8)

P("23-A.7 Dolor e impacto", 'h1')
P("Toda compra busca resolver un problema. Mientras mayor sea el impacto, mayor la urgencia. Identificado el "
  "problema, no se cambia de tema: se profundiza en lo que ese problema le está costando al cliente.")
TBL([
    ["Para descubrir el dolor", "Para descubrir el impacto"],
    ["«What has been the biggest challenge with your current cleaning service?»", "«How often does that happen?»"],
    ["«If you could change one thing about your current situation, what would it be?»", "«How has that affected your staff or tenants?»"],
    ["«How has that affected your operation?»", "«Has that created any additional issues?»"],
], [3.25 * inch, 3.25 * inch], fs=8.5)

P("23-A.8 Escucha activa y confirmación", 'h1')
P("Escuchar activamente significa atender mucho más que las palabras: el tono de voz, las pausas, la velocidad al "
  "hablar, la emoción detrás de cada respuesta y las palabras que el cliente repite varias veces, que suelen "
  "señalar su preocupación principal.")
P("Después de varios minutos se confirma lo entendido, lo que evita malentendidos y le da al cliente la "
  "oportunidad de corregir antes de avanzar:")
story.append(Paragraph(
    "«Just to make sure I understand correctly, you're looking for recurring office cleaning because your current "
    "provider has become inconsistent, communication has been difficult, and you're looking for a company that's "
    "more reliable. Is that correct?»", S['quote']))

P("23-A.9 Calificación de la oportunidad", 'h1')
TAG("R")
CHK([
    "¿La propiedad se encuentra dentro del área de servicio?",
    "¿El tipo de limpieza solicitado forma parte de nuestros servicios?",
    "¿Existe una necesidad inmediata o futura?",
    "¿Quién tomará la decisión final?",
    "¿Cuál es el tiempo estimado para iniciar el servicio?",
    "¿Será necesario realizar una evaluación presencial?",
    "¿Existe un presupuesto definido o todavía está evaluando opciones?",
])
P("<b>Señales positivas</b> de oportunidad real: el contrato actual está por finalizar; el proveedor actual no "
  "cumple; necesita iniciar pronto; está solicitando varias cotizaciones; quiere conocer el proceso para comenzar; "
  "pregunta por disponibilidad; pregunta por seguros, certificaciones o experiencia.")

P("23-A.10 Presentación de la solución", 'h1')
TAG("R")
BOX(None, ["<b>No se venden servicios. Se venden resultados.</b>"])
P("El cliente busca instalaciones limpias de forma consistente, un proveedor confiable, comunicación rápida, menos "
  "quejas, cumplimiento de horarios, personal capacitado, supervisión constante y tranquilidad.")
P("La presentación se construye alrededor de lo que el cliente dijo, nunca alrededor de un discurso preparado, y "
  "sigue la estructura <b>problema – solución – beneficio</b>:")
TBL([
    ["Componente", "Contenido", "Ejemplo aplicado"],
    ["Problema", "Se reconoce la necesidad expresada por el cliente.", "Su proveedor actual no cumple los horarios."],
    ["Solución", "Se explica cómo la empresa la resuelve.", "Cronogramas definidos, supervisión operativa y controles de calidad."],
    ["Beneficio", "Se describe el resultado que obtendrá.", "Servicio consistente y menos interrupciones en su operación."],
], [1.1 * inch, 2.4 * inch, 3.0 * inch], fs=8.5)
P("Ejemplo de personalización cuando el dolor declarado fue la comunicación:")
story.append(Paragraph(
    "«Earlier you mentioned that communication with your current provider has been inconsistent. One of the ways we "
    "address that is by assigning a dedicated point of contact, so you always know who to reach if something needs "
    "immediate attention.»", S['quote']))
P("No se presentan todos los servicios disponibles: solo los que aportan valor a esa situación. Una presentación "
  "breve y personalizada es más efectiva que una explicación extensa. La credibilidad —experiencia, personal "
  "capacitado, procesos documentados, controles de calidad, cobertura de seguros, licencias— refuerza la solución, "
  "no se convierte en el centro de la conversación.")

P("23-A.11 Manejo de objeciones", 'h1')
TAG("R")
P("Una objeción no significa que el cliente no quiera comprar; en la mayoría de los casos significa que necesita "
  "más información. Nunca se responde de forma defensiva: se escucha completamente, se agradece, se responde con "
  "tranquilidad y se confirma que la inquietud quedó resuelta.")
TBL([
    ["Técnica", "Cómo funciona", "Ejemplo"],
    ["Feel – Felt – Found", "Reconocer cómo se siente, mencionar que otros se sintieron igual, compartir lo que descubrieron.", "«I completely understand how you feel. Several of our clients initially felt the same way when comparing proposals. What they found was that choosing a provider based on reliability, communication and consistent quality helped them avoid many of the issues they had experienced before.»"],
    ["Labeling", "Verbalizar la preocupación percibida.", "«It sounds like consistency is extremely important to your team.»"],
    ["Mirroring", "Repetir la palabra clave para invitar a profundizar.", "Cliente: «We've had several issues with communication.» → «Communication?»"],
    ["Preguntar antes de responder", "Entender la objeción antes de rebatirla.", "«Could you tell me a little more about that?» · «What specifically concerns you?» · «Can you help me understand what you're comparing?»"],
], [1.3 * inch, 2.0 * inch, 3.2 * inch], fs=8)
P("Si el cliente pregunta el precio muy pronto, no se entrega una cifra sin conocer el alcance:")
story.append(Paragraph(
    "«I'd be happy to provide pricing. Before I do, I'd like to ask a few questions so I can make sure we're "
    "recommending the right service for your facility.»", S['quote']))
P("Después de responder cualquier objeción se verifica: «Does that answer your question?», «Does that make "
  "sense?», «Is there anything else you'd like me to clarify?». Nunca se asume que la objeción desapareció.")

P("23-A.12 Cierre", 'h1')
TAG("R")
P("Cerrar no significa presionar: significa ayudar al cliente a decidir con información suficiente. Nunca se "
  "pregunta «¿quiere contratarnos?»; se guía hacia el siguiente paso lógico.")
TBL([
    ["Tipo de cierre", "Cuándo se usa", "Formulación"],
    ["Hacia evaluación presencial", "El proyecto requiere inspección.", "«Would next Tuesday morning or Wednesday afternoon work better for the walkthrough?»"],
    ["Hacia propuesta", "Ya se tiene toda la información.", "«I'll prepare a detailed proposal based on everything we've discussed today. Once it's ready, we can review it together.»"],
    ["Servicio simple", "El alcance es claro y no requiere visita.", "«Based on the information you've provided, we can certainly help with that. Let's go over the service details so we can get everything scheduled.»"],
    ["Por alternativas", "Siempre que se pueda ofrecer opciones en lugar de sí o no.", "«Would you prefer morning or evening service?» · «Is Tuesday or Thursday better?»"],
], [1.5 * inch, 2.0 * inch, 3.0 * inch], fs=8)
BOX("Regla de urgencia", [
    "La urgencia debe basarse en hechos reales: disponibilidad limitada en la agenda, fecha de inicio solicitada "
    "por el cliente, apertura nueva, fin del contrato con el proveedor actual o fecha definida de post-construcción. "
    "<b>Nunca se genera presión artificial.</b>"])

P("23-A.13 Venta adicional", 'h1')
TAG("R")
P("El momento correcto es <b>después</b> de que el cliente aceptó el servicio principal o confirmó el siguiente "
  "paso, nunca antes. Si aún hay dudas sobre el servicio principal, la conversación se concentra en resolverlas.")
TBL([
    ["Servicio complementario", "Cuándo recomendarlo"],
    ["Limpieza de alfombras", "Propiedades con superficie alfombrada significativa."],
    ["Limpieza de ventanas", "Propiedades con gran cantidad de vidrio exterior."],
    ["Cuidado de pisos", "Instalaciones con pisos duros de alto tránsito."],
    ["Áreas comunes", "Propiedades multiusuario o administradas."],
    ["Pressure washing", "Exteriores, entradas y áreas de acceso."],
    ["Post-construcción", "Obra terminada o remodelación."],
    ["Limpiezas profundas programadas", "Instalaciones con acumulación estacional."],
    ["Desinfección de puntos de alto contacto", "Oficinas, consultorios y espacios compartidos."],
], [2.5 * inch, 4.0 * inch], fs=8.5)
P("No se pregunta «do you want to add another service?». Se explica el beneficio:")
story.append(Paragraph(
    "«Many of our clients also schedule quarterly carpet cleaning to help extend the life of their flooring and "
    "maintain a more professional appearance.»", S['quote']))

P("23-A.14 Cierre de la llamada y registro", 'h1')
TAG("R")
P("Antes de colgar, ambas partes deben tener claridad sobre qué ocurrirá: qué hará la empresa, qué hará el "
  "cliente, fechas comprometidas, horarios, persona de contacto y medio de comunicación. Nunca se finaliza una "
  "llamada dejando el siguiente paso indefinido.")
P("Inmediatamente después —antes de atender otra llamada— se registra en el CRM:")
TBL([
    ["Campos mínimos de registro", ""],
    ["Nombre del contacto · Empresa · Cargo", "Teléfono · Correo electrónico · Dirección del servicio"],
    ["Tipo de instalación · Servicios solicitados", "Principales necesidades identificadas"],
    ["Objeciones presentadas", "Próximo paso acordado · Fecha de seguimiento"],
    ["Estado de la oportunidad", "Notas adicionales"],
], [3.25 * inch, 3.25 * inch], fs=8.5)

P("23-A.15 Principios del representante", 'h1')
TAG("R")
NUM([
    "Escuchar antes de responder.",
    "Comprender antes de recomendar.",
    "Resolver antes de vender.",
    "Generar confianza antes de solicitar un compromiso.",
    "Cumplir siempre lo prometido.",
    "Registrar toda la información en el CRM.",
    "Dar seguimiento dentro del tiempo acordado.",
])
BOX(None, [
    "Una llamada exitosa no siempre termina en venta inmediata. Termina con un cliente que confía en la empresa, "
    "entiende el siguiente paso y percibe que está tratando con un equipo organizado."])

# ---------- CAP 23-B ----------
CAP("23-B", "Desarrollo comercial outbound")
P("23-B.1 Cuándo aplica este capítulo", 'h1')
TAG("P", "proceso diseñado para el crecimiento hacia cuentas comerciales recurrentes")
P("El canal outbound busca cuentas comerciales —property management, contratistas generales, oficinas, clínicas— "
  "que no llamaron a Ecobay. Es el canal que construye ingreso recurrente de mayor volumen y menor rotación, y el "
  "que hace viable una operación con varios equipos simultáneos.")

P("23-B.2 Los cuatro principios", 'h1')
TAG("R")
TBL([
    ["Principio", "Consecuencia operativa"],
    ["Escucha más de lo que hablas.", "Si hablas más del 40% de la llamada, estás perdiendo información que podría cerrar la venta."],
    ["La confianza se construye con acciones, no con promesas.", "No se genera diciendo «somos confiables». Se genera cumpliendo lo que se dice que se va a hacer."],
    ["Comprende antes de recomendar.", "Ninguna solución se presenta sin al menos dos o tres preguntas reales sobre cómo opera el prospecto."],
    ["Vendes confianza, no una lista de servicios.", "Nadie cambia de proveedor por una lista más larga. Cambian porque confiaron en alguien."],
], [2.5 * inch, 4.0 * inch], fs=8.5)

P("23-B.3 Preparación antes de marcar", 'h1')
TAG("R")
P("Una llamada se gana o se pierde antes de marcar. La investigación mínima cubre sitio web, LinkedIn y perfil de "
  "negocio; número de ubicaciones y tipo de instalaciones; servicios que ofrece y áreas donde opera; y el nombre "
  "del tomador de decisiones si está disponible.")
CHK([
    "Revisé el sitio web.",
    "Revisé LinkedIn.",
    "Busqué el portal de proveedores.",
    "Tengo, o intenté obtener, el nombre del tomador de decisiones.",
    "Abrí el CRM y leí el historial.",
    "Tengo mi razón legítima para llamar, en una frase.",
])
TBL([
    ["Buenas prácticas", "Errores comunes"],
    ["Anotar todo en el CRM mientras se investiga, no después.", "Llamar sin haber abierto el sitio web."],
    ["Una sola razón legítima para llamar vale más que diez datos sueltos.", "Memorizar datos en vez de tener una razón para llamar."],
], [3.25 * inch, 3.25 * inch], fs=8.5)

P("23-B.4 Portales de proveedores y precalificación", 'h1')
P("Muchas empresas publican su proceso de proveedores bajo nombres como Vendor Registration, Become a Vendor, "
  "Procurement, Vendor Compliance o Bids & RFPs. Localizarlo cambia por completo el objetivo de la llamada.")
TBL([
    ["Situación", "Qué hacer"],
    ["Existe portal de registro", "Completar todo lo posible antes de llamar: cuenta, certificado de seguro, W-9, licencia y referencias."],
    ["Ya se está precalificado en una plataforma de compliance", "No preguntar cómo aplicar. Preguntar cuál es el siguiente paso."],
    ["No hay portal ni información publicada", "La llamada existe para descubrir el proceso, no para vender."],
], [2.4 * inch, 4.1 * inch], fs=8.5)
BOX("Regla", [
    "Precalificado no es lo mismo que aprobado. Siempre se pregunta cuál es el siguiente paso. Y nunca se llama "
    "antes de completar lo que el portal ya permite hacer por cuenta propia."])

P("23-B.5 La apertura", 'h1')
TAG("R")
P("Los primeros quince segundos deciden el tono de toda la llamada. La apertura busca una sola cosa: una razón "
  "legítima para seguir hablando, no una venta.")
story.append(Paragraph(
    "«Good morning, this is ______ with Ecobay Cleaning. I was hoping you could help me with something — I couldn't "
    "find your vendor process on your website. Could you point me in the right direction?»", S['quote']))
BOX("Por qué funciona", [
    "El silencio después de la pregunta activa reciprocidad: el prospecto siente la necesidad de llenar el espacio "
    "y responder. <b>Guardar silencio después de la pregunta de apertura es parte del método</b>, no una pausa "
    "incómoda que haya que rellenar."])
TBL([
    ["Si sucede esto…", "Hacer esto"],
    ["Contesta la recepción", "«Who normally handles your commercial cleaning vendors?»"],
    ["Preguntan el motivo de la llamada", "«We were reviewing your website and couldn't find your vendor process, so I was hoping someone could point me in the right direction.»"],
], [1.9 * inch, 4.6 * inch], fs=8.5)
P("Errores que anulan la apertura: hablar de años en el mercado o de la lista de servicios en los primeros "
  "minutos, llenar el silencio y dar precios sin haber calificado nada.")

P("23-B.6 Posicionamiento por tipo de prospecto", 'h1')
TBL([
    ["Tipo de prospecto", "Ángulo de conversación", "Formulación"],
    ["Property management", "Consistencia entre múltiples propiedades.", "«Based on what you've shared, it sounds like consistency across multiple properties matters a lot for your team. That's actually where we spend most of our time.»"],
    ["Contratista general", "Flexibilidad con cronogramas y plazos ajustados.", "«Sounds like timing is critical on your projects. We're used to working around changing schedules and tight deadlines.»"],
    ["Oficinas y consultorios médicos", "Protocolos, consistencia y atención al detalle.", "Se enfatiza el control de calidad documentado y la capacitación del personal."],
], [1.4 * inch, 2.0 * inch, 3.1 * inch], fs=8)
BOX(None, [
    "<b>No se vende limpieza. Se vende la certeza de que esto no va a ser algo de lo que tengan que "
    "preocuparse.</b>"])

P("23-B.7 Señales de compra", 'h1')
P("El interés casi nunca suena a un «sí». Suena a preguntas. Cada pregunta del prospecto es una puerta: se "
  "responde y se devuelve una pregunta relacionada.")
TBL([
    ["Señal", "Qué hacer de inmediato"],
    ["«Are you insured?»", "Confirmar y preguntar si esos documentos forman parte de su proceso de aprobación."],
    ["«Can you handle multiple locations?»", "Confirmar y preguntar cuántas ubicaciones maneja hoy."],
    ["«Do you have references?»", "Ofrecer dos o tres referencias relevantes a su industria."],
    ["Pregunta por tiempos o disponibilidad", "Preguntar directamente cuál es la fecha límite real."],
    ["Pregunta el precio muy pronto", "No cotizar sin evaluación presencial; redirigir con cortesía."],
], [2.2 * inch, 4.3 * inch], fs=8.5)
P("Ejemplo de respuesta completa a la pregunta de seguros:")
story.append(Paragraph(
    "«Yes, absolutely — we carry General Liability and Workers' Comp. Out of curiosity, are those documents "
    "typically requested during your vendor approval process?»", S['quote']))

P("23-B.8 Señales de riesgo", 'h1')
TBL([
    ["Señal", "Cómo recuperar la conversación"],
    ["Respuestas muy cortas", "Hacer una pregunta directa y cerrar ofreciendo reagendar."],
    ["Nunca da nombres", "Pedir con cortesía el nombre del responsable de proveedores."],
    ["«Just send me an email» sin contexto", "Pedir contexto antes de colgar."],
    ["Solo se habla con recepción", "Preguntar directamente quién maneja proveedores de limpieza."],
], [2.4 * inch, 4.1 * inch], fs=8.5)
P("Error común: colgar apenas se recibe una respuesta corta, sin intentar una pregunta más.")

P("23-B.9 Objeciones", 'h1')
P("<b>«We already have a cleaning company».</b> Es la objeción más frecuente y la más útil, porque contiene la "
  "información de timing que el canal necesita.")
FLOW(["Reconocer", "Preguntar renovación", "Pedir permiso de recontacto", "Agendar recordatorio en CRM"])
story.append(Paragraph(
    "«That makes sense — most of the companies we work with had a provider before us too. Out of curiosity, when "
    "does your current agreement come up for renewal?» → «Would it be alright if I reached back out closer to that "
    "time?»", S['quote']))
P("<b>«Just send me an email».</b> Nunca se cuelga sin acordar el seguimiento:")
story.append(Paragraph(
    "«Absolutely, I'd be happy to. Just so I send the most relevant info, what would you like to see? And once "
    "you've had a chance to look it over, would Thursday or Friday work for a quick follow-up?»", S['quote']))

P("23-B.10 Cierre hacia la evaluación presencial", 'h1')
P("Si hay interés real, la conversación avanza hacia conocer las instalaciones, no hacia seguir vendiendo por "
  "teléfono.")
story.append(Paragraph(
    "«Based on everything we've discussed, I think the best next step would be for us to stop by, take a look at "
    "the property, and learn a bit more about your operation.»", S['quote']))
TBL([
    ["Situación", "Qué hacer"],
    ["Piden una propuesta directa", "Confirmar primero la evaluación: «we want to recommend the right scope instead of guessing»."],
    ["Piden documentación", "Confirmar exactamente qué necesitan antes de colgar."],
], [2.0 * inch, 4.5 * inch], fs=8.5)
CHK([
    "Sé quién decide.",
    "Sé cómo deciden nuevos proveedores.",
    "Sé si existe un portal de registro.",
    "Sé qué documentación piden.",
    "Hay un siguiente paso concreto acordado.",
    "Hay una fecha para volver a hablar.",
], "Antes de colgar")

P("23-B.11 Manejo de un no", 'h1')
story.append(Paragraph(
    "«I completely understand — thank you for taking a few minutes today. If your needs ever change, we'd love the "
    "chance to introduce ourselves.»", S['quote']))
BOX(None, [
    "<b>Un «no por ahora» no es un rechazo. Es una fecha futura que todavía no está agendada.</b>"])

P("23-B.12 Inteligencia en el CRM", 'h1')
TAG("R")
P("El CRM no es un formulario que se llena. Es la información que decide si la próxima llamada empieza de cero o "
  "empieza con ventaja. Se actualiza apenas se cuelga, no al final del día.")
TBL([
    ["Dato", "Por qué importa"],
    ["Fecha de renovación del contrato", "Es el único disparador real de timing."],
    ["Nombre del tomador de decisiones", "Sin esto, cada llamada vuelve a empezar de cero."],
    ["Objeción específica", "Dice exactamente qué resolver en el próximo contacto."],
    ["Proceso de compra: portal, RFP, referidos", "Define la estrategia de seguimiento."],
    ["Tono general de la llamada", "Indica si vale la pena insistir pronto o esperar."],
], [2.4 * inch, 4.1 * inch], fs=8.5)

P("23-B.13 Casos de error y corrección", 'h1')
TBL([
    ["Qué pasó", "Qué salió mal", "Cómo debía manejarse"],
    ["Se habló de la empresa cinco minutos antes de preguntar algo; el prospecto cortó.", "Presentó antes de descubrir.", "Abrir con la pregunta sobre el proceso de proveedores y dejar hablar."],
    ["El prospecto preguntó el precio en el minuto dos y se cotizó sin conocer el alcance.", "Dio un número sin información suficiente.", "«I'd love to give you an accurate number — can we set up a quick walkthrough first?»"],
    ["La recepción dijo «we're not interested» y se insistió con ella.", "Discutió con quien no toma la decisión.", "Agradecer y pedir el nombre del responsable de proveedores."],
    ["El prospecto pidió un correo y se colgó sin preguntar nada más.", "Perdió la oportunidad de calificar.", "Preguntar qué le gustaría ver antes de colgar."],
    ["Se logró una evaluación pero no se registró; dos semanas después nadie dio seguimiento.", "No documentó el compromiso.", "Registrar fecha, hora y compromiso inmediatamente después de colgar."],
], [2.2 * inch, 1.6 * inch, 2.7 * inch], fs=8)

P("23-B.14 Indicadores del canal", 'h1')
TAG("P", "el embudo de referencia debe validarse con la operación real de Ecobay antes de fijarse como meta")
TBL([
    ["Etapa del embudo", "Cantidad de referencia"],
    ["Llamadas realizadas", "80"],
    ["Conversaciones reales", "12"],
    ["Tomadores de decisión contactados", "5"],
    ["Evaluaciones presenciales agendadas", "2"],
    ["Propuestas enviadas", "1"],
    ["Clientes cerrados", "1"],
], [3.9 * inch, 2.6 * inch], fs=8.5)
BOX("Cómo se diagnostica con este embudo", [
    "Si las conversaciones reales están muy por debajo de 12 de cada 80 llamadas, el problema está en la apertura. "
    "Si hay conversaciones pero pocas evaluaciones agendadas, el problema está en el cierre. El embudo no es un "
    "reporte: es una herramienta de diagnóstico."])

P("23-B.15 Las diez reglas del representante outbound", 'h1')
TAG("R")
NUM([
    "Nunca vendas antes de descubrir.",
    "Nunca hables más del 40% de la llamada.",
    "Nunca termines una llamada sin un siguiente paso.",
    "Nunca envíes un correo sin acordar el seguimiento.",
    "Nunca discutas con un no.",
    "Nunca improvises información que no tienes.",
    "Nunca cotices sin conocer el alcance.",
    "Siempre deja notas en el CRM antes de la siguiente llamada.",
    "Siempre confirma quién decide.",
    "Siempre trata cada «no por ahora» como una oportunidad futura.",
])
FLOW(["Research", "Connect", "Discover", "Build trust", "Educate", "Next step"])
FLOW(["Follow-up", "Relationship", "Vendor", "Walkthrough", "Proposal", "Client"])

# ---------- CAP 23-C ----------
CAP("23-C", "Contratos y términos de servicio")
P("23-C.1 Función del contrato en la operación", 'h1')
P("Un contrato de limpieza comercial recurrente no existe para ganar un juicio: existe para que nadie tenga que "
  "llegar a uno. Define qué está incluido, cómo se pide un cambio, cómo se reporta un problema, cuándo se cobra "
  "una visita que no pudo ejecutarse y qué hace el equipo si encuentra una situación insegura. Cada una de esas "
  "definiciones es un proceso operativo, no una formalidad legal.")
BOX("Aviso", [
    "Este capítulo describe la <b>función operativa</b> de las cláusulas estándar de un contrato de limpieza "
    "comercial recurrente. No constituye asesoría legal. El documento contractual de Ecobay debe ser revisado por "
    "un abogado licenciado en la jurisdicción aplicable antes de utilizarse."])

P("23-C.2 Alcance del servicio", 'h1')
TAG("R", "principio operativo aplicable a todo servicio, residencial o comercial")
TBL([
    ["Principio contractual", "Traducción operativa", "Nivel"],
    ["El servicio es estrictamente el descrito en el acuerdo y su documentación de alcance.", "El equipo ejecuta lo contratado; nadie amplía el alcance por iniciativa propia.", "No negociable"],
    ["El trabajo adicional requiere aprobación previa y puede generar cargos comunicados antes de ejecutarlo.", "Toda solicitud fuera de alcance se escala a Administración antes de aceptarse.", "No negociable"],
    ["Una cortesía o excepción puntual no crea obligación permanente.", "Lo que se hizo una vez como favor no pasa a ser parte del servicio salvo acuerdo escrito.", "No negociable"],
], [2.3 * inch, 2.7 * inch, 1.5 * inch], fs=8)
BOX("Por qué esta cláusula protege la operación", [
    "El deslizamiento de alcance es la fuga silenciosa más común en limpieza comercial: cada mes se hace un poco "
    "más por el mismo precio hasta que la cuenta deja de ser rentable, y retirar lo que ya se venía haciendo genera "
    "un conflicto mayor que haberlo cobrado desde el inicio."])

P("23-C.3 Canal oficial de comunicación", 'h1')
TAG("R")
BOX(None, [
    "<b>Las solicitudes hechas verbalmente al personal en sitio no constituyen notificación, aprobación ni "
    "autorización</b>, y no obligan a la empresa salvo confirmación posterior por el canal oficial."])
P("Todas las solicitudes de servicio, quejas, cambios de horario, aprobaciones y consultas de facturación deben "
  "ingresar por el canal oficial identificado en el acuerdo. Esta cláusula es la que protege al colaborador: le da "
  "una respuesta profesional y no negociable cuando un cliente le pide algo directamente.")
FLOW(["Cliente pide algo al equipo en sitio", "Team Lead escala a Administración", "Administración responde por canal oficial"])

P("23-C.4 Responsabilidades del cliente", 'h1')
TBL([
    ["Obligación del cliente", "Riesgo que previene"],
    ["Acceso seguro, oportuno y sin obstrucciones a la propiedad en el horario acordado.", "Visitas perdidas y horas pagadas sin servicio ejecutado."],
    ["Servicios básicos funcionando, incluidos agua y electricidad.", "Imposibilidad de ejecutar el trabajo contratado."],
    ["Asegurar objetos de valor, efectivo e información confidencial antes del servicio.", "Reclamos por pérdida y exposición del personal a acusaciones."],
    ["Contener mascotas o animales que puedan interferir o representar riesgo.", "Lesiones y retrasos."],
    ["Notificar peligros conocidos, áreas restringidas o condiciones inseguras.", "Accidentes y daños prevenibles."],
], [3.2 * inch, 3.3 * inch], fs=8.5)

P("23-C.5 Calidad y oportunidad de corregir", 'h1')
TAG("R")
P("El cliente notifica cualquier deficiencia dentro del plazo definido y por el canal oficial. La empresa debe "
  "recibir una oportunidad razonable de inspeccionar, investigar y corregir antes de que el cliente retenga pago o "
  "termine el acuerdo. Cualquiera de las partes puede solicitar recorridos de verificación con aviso razonable.")
FLOW(["Cliente notifica", "Empresa inspecciona", "Corrección", "Confirmación de cierre"])
P("La empresa puede tomar fotografías antes o después del servicio, únicamente para documentación interna, "
  "aseguramiento de calidad, capacitación o resolución de reclamos de daño o servicio. Esa evidencia es la que "
  "convierte una discusión de percepciones en un hecho verificable.")

P("23-C.6 Cláusulas que protegen el cobro", 'h1')
TBL([
    ["Cláusula", "Contenido operativo"],
    ["Términos de pago", "El pago se rige por el calendario de facturación del acuerdo; los pagos tardíos pueden generar cargos según lo permita la ley."],
    ["Ajuste anual de precios", "La empresa puede ajustar precios con aviso previo por escrito ante aumentos de costos laborales, impuestos de nómina, primas de seguro, combustible, insumos, inflación o cambios de alcance."],
    ["Retrasos y bloqueos atribuibles al cliente", "Si el equipo no puede acceder o completar el servicio por causas del cliente —accesos cerrados, ausencia de contacto autorizado, alarmas, obra en curso, reuniones o eventos ocupando el espacio, otros contratistas en sitio— la visita puede facturarse según la política estándar y no se considera incumplimiento de la empresa."],
    ["Suspensión del servicio", "La empresa puede suspender el servicio por falta de pago, condiciones inseguras, obstrucción reiterada o incumplimiento material, con aviso razonable."],
    ["Terminación", "Cualquiera de las partes puede terminar por conveniencia con aviso previo escrito; la terminación no libera al cliente de pagar lo ya prestado."],
], [1.7 * inch, 4.8 * inch], fs=8.5)

P("23-C.7 Cláusulas que protegen al personal", 'h1')
TAG("R")
TBL([
    ["Cláusula", "Contenido operativo", "Quién la ejerce"],
    ["Seguridad del personal", "El equipo está autorizado a suspender el trabajo y retirarse de inmediato si razonablemente cree estar expuesto a violencia, amenazas, drogas ilegales, armas a la vista, acoso o cualquier entorno inseguro, sin que ello constituya incumplimiento.", "Cualquier colaborador"],
    ["Objetos de valor", "El personal no mueve ni manipula electrónicos costosos, obras de arte, cajas fuertes, armas, archivos confidenciales u otros objetos sensibles salvo que esté expresamente en el alcance.", "Cualquier colaborador"],
    ["Productos químicos", "La empresa usa sus propios productos aprobados; el cliente no puede exigir el uso de químicos o equipos no aprobados salvo acuerdo escrito previo.", "Team Lead"],
    ["No solicitación de personal", "El cliente no contrata ni solicita directamente al personal de la empresa involucrado en su cuenta, durante la vigencia y por el período pactado después.", "Owner"],
], [1.4 * inch, 3.7 * inch, 1.4 * inch], fs=8)
BOX("Regla operativa derivada", [
    "La cláusula de seguridad del personal no es un texto legal: es una <b>autorización explícita para que un "
    "colaborador se retire de una propiedad sin pedir permiso</b> cuando su integridad está en riesgo. Debe "
    "enseñarse en el onboarding, no dejarse enterrada en un contrato que el equipo nunca lee."])

P("23-C.8 Insumos, verificación y evidencia", 'h1')
TBL([
    ["Tema", "Definición estándar"],
    ["Insumos incluidos", "La empresa provee los insumos y equipos estándar necesarios para ejecutar el alcance."],
    ["Consumibles excluidos", "Papel higiénico, jabón de manos, bolsas de basura y toallas de papel para uso del cliente quedan fuera del alcance salvo inclusión expresa."],
    ["Servicios de emergencia y fuera de horario", "Limpieza de emergencia, respuesta a inundación o daño por agua, remediación de biopeligros, fines de semana y feriados no están incluidos y se cotizan por separado."],
    ["Verificación del servicio", "La ejecución puede documentarse con bitácoras, checklists digitales, reportes de supervisor, marcas de tiempo, registros de ubicación, fotografías u otros sistemas de calidad."],
    ["Llaves y códigos de acceso", "La empresa resguarda las credenciales entregadas y designa al personal responsable de su uso; el cliente notifica cualquier cambio de código."],
    ["Reporte de daños", "El cliente reporta cualquier daño alegado dentro del plazo definido por el canal oficial; el aviso tardío puede limitar la capacidad de investigar."],
], [1.9 * inch, 4.6 * inch], fs=8.5)

P("23-C.9 Cláusulas de riesgo y marco legal", 'h1')
TBL([
    ["Cláusula", "Función"],
    ["Limitación de responsabilidad", "Limita la responsabilidad a daños directos por negligencia probada y excluye daños indirectos, incidentales o lucro cesante, con un tope agregado referido a lo pagado en los meses previos."],
    ["Seguros", "La empresa mantiene cobertura de responsabilidad civil comercial y las coberturas apropiadas al servicio; los certificados pueden entregarse a solicitud escrita."],
    ["Estatus de contratista independiente", "El personal de la empresa no es empleado ni agente del cliente para ningún efecto, incluidos retenciones, beneficios, compensación laboral o responsabilidad laboral."],
    ["Fuerza mayor y clima", "La empresa no responde por retrasos derivados de causas fuera de su control razonable; el equipo puede cancelar una visita cuando nieve, hielo, inundación o escombros hagan inseguro el acceso."],
    ["Confidencialidad", "El personal mantiene la confidencialidad de la información que observe en la propiedad."],
    ["Cambios al servicio", "Cambios de frecuencia, alcance, metraje o especificaciones se documentan por escrito y pueden ajustar el precio; si la propiedad cambió materialmente, la empresa puede solicitar una nueva evaluación."],
    ["Ley aplicable, divisibilidad, acuerdo íntegro, firma electrónica, notificaciones, cumplimiento legal", "Marco jurídico del acuerdo."],
    ["Resolución de disputas", "Las partes intentan primero negociación de buena fe y pueden acordar mediación antes de litigar."],
], [2.1 * inch, 4.4 * inch], fs=8.5)

P("23-C.10 Cláusulas adicionales a evaluar con asesoría legal", 'h1')
TBL([
    ["Cláusula", "Propósito", "Recomendación de referencia"],
    ["Indemnización", "El cliente indemniza a la empresa frente a reclamos de terceros derivados de su negligencia.", "Generalmente recomendada"],
    ["Limitación de garantías", "Excluye garantías implícitas más allá de lo pactado.", "Generalmente recomendada"],
    ["Honorarios de abogado", "Permite a la parte vencedora recuperar honorarios razonables.", "Opcional"],
    ["Cesión del contrato", "Restringe la cesión del acuerdo a un sucesor.", "Generalmente recomendada"],
    ["Supervivencia", "Define qué cláusulas siguen vigentes tras la terminación.", "Generalmente recomendada"],
    ["Renuncia", "Aclara que no exigir una cláusula una vez no implica renunciar a ella.", "Generalmente recomendada"],
    ["Retención de registros", "Establece cuánto tiempo se conservan bitácoras y registros de calidad.", "Opcional"],
    ["Manejo de información confidencial", "Requisitos de datos para clientes en entornos sensibles.", "Situacional"],
    ["Cumplimiento de seguridad laboral", "Confirma el cumplimiento de estándares aplicables de seguridad.", "Generalmente recomendada"],
    ["Uso de subcontratistas", "Permite expresamente subcontratar sujeto a condiciones.", "Situacional"],
], [1.5 * inch, 3.3 * inch, 1.7 * inch], fs=8)

P("23-C.11 Del contrato a la operación", 'h1')
TAG("P")
P("Un contrato firmado que el equipo no conoce no protege a nadie. Cada cláusula operativa debe trasladarse al "
  "sistema en tres lugares.")
TBL([
    ["Cláusula", "Dónde vive en la operación"],
    ["Alcance del servicio", "Notas del servicio y checklist de inspección final."],
    ["Canal oficial de comunicación", "Onboarding del cliente y capacitación del equipo."],
    ["Plazo de reporte de deficiencias", "Proceso de quejas y su reloj de respuesta."],
    ["Cobro de visitas bloqueadas", "Procedimiento de facturación ante acceso fallido."],
    ["Seguridad del personal", "Capacitación obligatoria y protocolo de retiro de propiedad."],
    ["Objetos de valor", "Estándar de conducta en la propiedad."],
    ["Verificación documental", "Registros de inspección y fotografías de calidad."],
    ["Ajuste anual de precios", "Rutina anual de revisión de cuentas."],
], [2.5 * inch, 4.0 * inch], fs=8.5)

# ==================================================================


PARTE("X", "Tecnología y sistemas",
      "Qué sistema sostiene cada proceso, quién responde por sus datos y cómo sobrevive la operación a un cambio de plataforma.",
      ["Capítulo 73. Arquitectura tecnológica de Ecobay",
       "Capítulo 74. CRM y gestión de la relación con el cliente",
       "Capítulo 75. Jobber — sistema de gestión de servicios",
       "Capítulo 76. CleanCore — sistema nervioso digital de Ecobay",
       "Capítulo 77. Google Local Services Ads",
       "Capítulo 78. Sistema de payroll",
       "Capítulo 79. Correo, documentos y espacio de trabajo",
       "Capítulo 80. Hojas de cálculo y registros auxiliares",
       "Capítulo 81. Integridad de datos",
       "Capítulo 82. Accesos, permisos y seguridad de información",
       "Capítulo 82-A. Social media y presencia digital"])

# ---------- CAP 73 ----------
CAP("73", "Arquitectura tecnológica de Ecobay")
P("73.1 Principio de arquitectura", 'h1')
TAG("R")
P("Todo proceso soportado por tecnología se documenta separando cinco capas. La confusión entre ellas es la causa "
  "más común de manuales que quedan obsoletos y de empresas que quedan atrapadas en una plataforma.")
TBL([
    ["Capa", "Pregunta que responde", "Ejemplo aplicado a un lead nuevo"],
    ["1. Proceso empresarial", "¿Qué debe ocurrir?", "El lead debe recibirse, registrarse, contactarse, calificarse y seguirse."],
    ["2. Configuración del sistema", "¿Cómo se estructura la herramienta?", "El lead se captura y se coloca en el pipeline correspondiente; las comunicaciones se centralizan."],
    ["3. Automatización", "¿Qué ocurre sin intervención?", "Se envía la respuesta inicial y se crea la tarea de seguimiento."],
    ["4. Responsabilidad humana", "¿Qué exige criterio?", "Una persona revisa, califica y decide el método de cotización."],
    ["5. Indicador", "¿Cómo se sabe si funciona?", "Tiempo de respuesta, tasa de contacto, tasa de cotización y tasa de cierre."],
], [1.5 * inch, 1.8 * inch, 3.2 * inch], fs=8.5)
BOX(None, ["<b>De esta forma el software sirve al proceso, y no al revés.</b>"])

P("73.2 Mapa de sistemas de Ecobay", 'h1')
TAG("C", "sistemas identificados durante el levantamiento")
TBL([
    ["Sistema", "Función dentro de la operación", "Estado actual"],
    ["CleanCore", "CRM, comunicación, automatización, ventas, marketing, client success, reclutamiento y conocimiento.", "Disponible"],
    ["Jobber", "Gestión de clientes, oportunidades, programación, ejecución e invoices.", "En uso diario"],
    ["Google Local Services Ads", "Generación de leads por llamada y mensaje.", "En uso"],
    ["Ramp Payroll", "Procesamiento de pagos al personal.", "En uso"],
    ["Correo y documentos", "Comunicación formal y almacenamiento documental.", "En uso"],
    ["Hoja de cálculo de horas", "Registro y consolidación de horas para payroll.", "En uso"],
    ["Sistema bancario", "Verificación de pagos recibidos.", "En uso"],
    ["Redes sociales", "Presencia de marca y captación complementaria.", "Sin proceso formal"],
], [1.55 * inch, 3.35 * inch, 1.6 * inch], fs=8.5)

P("73.3 Matriz de fuente de verdad", 'h1')
TAG("P")
P("Cuando dos sistemas contienen el mismo dato, uno de ellos manda. Sin esta definición, cada persona consulta el "
  "sistema que tiene más a mano y la empresa opera con versiones distintas de la misma realidad.")
TBL([
    ["Información", "Fuente de verdad", "Sistema secundario", "Responsable", "Actualización"],
    ["Relación y datos del cliente", "CleanCore", "Sistema de gestión de servicios", "Administración", "Al crear y al cambiar"],
    ["Comunicación con leads y clientes", "CleanCore", "—", "Administración", "Continua"],
    ["Pipeline comercial", "CleanCore", "—", "Administración", "En cada interacción"],
    ["Marketing y campañas", "CleanCore", "—", "Administración", "Por campaña"],
    ["Reputación y reseñas", "CleanCore", "Plataformas públicas", "Administración", "Continua"],
    ["Reclutamiento de candidatos", "CleanCore", "—", "Administración", "En cada etapa"],
    ["Servicios programados y ejecutados", "Jobber", "CleanCore", "Administración", "Diaria"],
    ["Equipo asignado a cada servicio", "Jobber", "—", "Administración / Operations", "Antes de ejecutar"],
    ["Notas y preferencias de propiedad", "Jobber", "CleanCore", "Administración", "Al conocerlas"],
    ["Invoices y estado de cobro", "Jobber", "—", "Administración", "Semanal"],
    ["Transacciones bancarias", "Sistema bancario", "—", "Administración", "Según banco"],
    ["Horas trabajadas", "Registro de horas", "Jobber como referencia", "Administración / Team Lead", "Diaria"],
    ["Pagos al personal", "Sistema de payroll", "—", "Administración", "Por ciclo"],
    ["Procedimientos y estándares", "Manual y SOP Vault", "—", "Owner", "Por versión"],
], [1.5 * inch, 1.25 * inch, 1.25 * inch, 1.35 * inch, 1.15 * inch], fs=7.5)

P("73.4 Regla de portabilidad", 'h1')
TAG("R")
BOX(None, [
    "<b>La tecnología puede cambiar. El proceso y la responsabilidad deben permanecer.</b>",
    "Si Ecobay reemplaza cualquiera de sus plataformas, los procesos de este manual deben seguir siendo válidos. "
    "Solo se reescriben las guías de software."])
P("Toda decisión de adoptar o abandonar una plataforma se evalúa con estas preguntas:")
NUM([
    "¿Qué proceso empresarial soporta y quién responde hoy por él?",
    "¿Qué información quedaría almacenada exclusivamente en esa plataforma?",
    "¿Esa información puede exportarse en un formato utilizable?",
    "¿Qué automatizaciones dependerían de ella y qué ocurre si se detienen?",
    "¿Qué otros sistemas se conectan con ella y en qué dirección viaja el dato?",
    "¿Quién sería el responsable interno de la plataforma y de sus datos?",
    "¿Cuánto tiempo operaría la empresa manualmente si la plataforma cae?",
])

P("73.5 Integraciones entre sistemas", 'h1')
TAG("P")
P("Toda conexión entre dos sistemas se documenta antes de activarse. Una integración no documentada es un punto "
  "ciego: cuando falla, nadie sabe qué dejó de moverse ni desde cuándo.")
TBL([
    ["Campo de la ficha de integración", "Qué debe registrarse"],
    ["Sistemas conectados", "Origen y destino del dato."],
    ["Dato que se transfiere", "Qué información específica viaja."],
    ["Dirección", "Unidireccional o bidireccional."],
    ["Disparador", "Qué evento provoca la transferencia."],
    ["Frecuencia", "Instantánea, programada o manual."],
    ["Responsable", "Quién responde por que funcione."],
    ["Qué ocurre si falla", "Procedimiento manual de contingencia."],
    ["Cómo se detecta la falla", "Alerta, revisión periódica o control cruzado."],
    ["Quién revisa", "Posición y frecuencia de la revisión."],
], [2.4 * inch, 4.1 * inch], fs=8.5)

P("73.6 Continuidad ante caída de un sistema", 'h1')
TAG("P")
TBL([
    ["Sistema caído", "Qué se detiene", "Contingencia inmediata"],
    ["CleanCore", "Comunicación centralizada, pipeline y automatizaciones.", "Atención directa por teléfono y correo; registro manual con carga posterior."],
    ["Jobber", "Consulta del schedule y emisión de invoices.", "Copia del schedule de la semana disponible fuera del sistema; facturación diferida."],
    ["Google LSA", "Entrada de leads del anuncio.", "Reforzar otros canales; revisar notificaciones por correo."],
    ["Sistema de payroll", "Procesamiento de pagos.", "Horas ya consolidadas en el registro; procesamiento en cuanto se restablezca."],
    ["Correo", "Comunicación formal.", "Contacto telefónico y por mensajería del CRM."],
    ["Registro de horas", "Consolidación para payroll.", "Registro en papel por el Team Lead y carga posterior."],
], [1.3 * inch, 2.4 * inch, 2.8 * inch], fs=8.5)
BOX("Regla de contingencia", [
    "Ningún servicio programado se cancela por la caída de un sistema. La operación continúa con registro manual y "
    "la información se carga en cuanto el sistema se restablece."])

# ---------- CAP 74 ----------
CAP("74", "CRM y gestión de la relación con el cliente")
P("74.1 Qué es el CRM para Ecobay", 'h1')
P("El CRM no es una lista de contactos. Es el registro de la relación completa con cada persona que ha tenido "
  "contacto con la empresa: qué pidió, qué se le respondió, qué se le cotizó, qué contrató, cómo quedó, qué "
  "prefiere y qué debe ocurrir después. En Ecobay esa función la cumple CleanCore.")

P("74.2 Información mínima de un contacto", 'h1')
TAG("P")
TBL([
    ["Campo", "Obligatorio", "Uso operativo"],
    ["Nombre completo", "Sí", "Trato e identificación."],
    ["Teléfono", "Sí", "Canal principal de seguimiento."],
    ["Correo electrónico", "Cuando exista", "Cotizaciones y comunicación formal."],
    ["Dirección de servicio", "Sí, al contratar", "Cobertura, ruta y preparación."],
    ["Origen del lead", "Sí", "Medición de canales."],
    ["Estado del contacto", "Sí", "Determina la gestión que recibe."],
    ["Tipo de servicio de interés", "Sí", "Staffing, equipo y precio."],
    ["Estado de recurrencia", "Al contratar", "Retención y programación."],
    ["Preferencias de producto", "Cuando existan", "Preparación del vehículo."],
    ["Condiciones de la propiedad", "Cuando existan", "Selección de kit y método."],
    ["Información de acceso", "Cuando aplique", "Ejecución del servicio."],
    ["Motivo de pérdida o cancelación", "Al cerrar", "Análisis y reactivación."],
], [1.9 * inch, 1.1 * inch, 3.5 * inch], fs=8.5)

P("74.3 Ciclo de vida del contacto", 'h1')
FLOW(["Contacto", "Prospecto", "Cliente puntual", "Cliente recurrente", "Inactivo o perdido"])
TBL([
    ["Estado", "Qué gestión recibe", "Quién lo mantiene"],
    ["Contacto", "Ninguna gestión activa hasta manifestar interés.", "Administración"],
    ["Prospecto", "Pipeline comercial con acción siguiente.", "Administración"],
    ["Cliente puntual", "Seguimiento posterior y oferta de recurrencia.", "Administración"],
    ["Cliente recurrente", "Retención, calidad sostenida y comunicación periódica.", "Administración"],
    ["Inactivo", "Segmentación para campaña de reactivación.", "Administración"],
    ["Perdido", "Motivo registrado y análisis de causa.", "Administración"],
], [1.4 * inch, 3.3 * inch, 1.8 * inch], fs=8.5)

P("74.4 Regla de centralización", 'h1')
TAG("R")
BOX(None, [
    "<b>Ninguna conversación comercial u operativa con un cliente debe existir únicamente en un teléfono personal, "
    "en una aplicación de mensajería privada, en un papel o en la memoria de una persona.</b>",
    "Si la empresa no puede reconstruir qué se le prometió a un cliente sin preguntarle a una persona concreta, "
    "esa relación no pertenece a la empresa."])

# ---------- CAP 75 ----------
CAP("75", "Jobber — sistema de gestión de servicios")
P("75.1 Función dentro de la operación", 'h1')
TAG("C")
P("Jobber es el sistema donde vive la operación de servicios: qué se va a hacer, para quién, cuándo, con qué "
  "equipo y qué se facturó. Se utiliza actualmente para administrar clientes, registrar leads y oportunidades, "
  "programar appointments, organizar el schedule, identificar qué casas se limpiaron y qué equipo realizó cada "
  "trabajo, crear invoices, mantener la información de los servicios y consultar el historial.")
BOX("Regla principal", [
    "<b>El sistema de gestión debe reflejar la operación real de la empresa.</b> Si un servicio cambió, un cliente "
    "cambió, una cita cambió o un pago fue recibido, la información correspondiente debe actualizarse."])

P("75.2 Procesos generales soportados", 'h1')
TBL([
    ["Proceso", "Qué debe registrarse", "Responsable", "Frecuencia"],
    ["Alta de cliente u oportunidad", "Datos de contacto, dirección, servicio, propiedad, fecha requerida y origen.", "Administración", "Al recibirse"],
    ["Creación de oportunidad", "Qué necesita el prospecto, qué se conversó, qué falta y cuál es el próximo paso.", "Administración", "Al calificar"],
    ["Programación de servicio", "Cliente, dirección, tipo de servicio, fecha, hora, equipo, duración estimada y notas.", "Administración", "Semanal y ante cambios"],
    ["Asignación de equipo", "Número y nombre de colaboradores según la matriz de staffing.", "Administración / Operations", "Antes de ejecutar"],
    ["Notas de propiedad", "Preferencias, condiciones, acceso, superficies y servicios adicionales.", "Administración", "Al conocerlas"],
    ["Cambios de schedule", "Nueva fecha y hora, equipo verificado y confirmación al cliente.", "Administración", "Inmediata"],
    ["Registro del trabajo realizado", "Propiedades atendidas y quiénes participaron realmente.", "Administración / Team Lead", "Diaria"],
    ["Facturación", "Invoice emitido y estado de cobro.", "Administración", "Semanal"],
], [1.4 * inch, 2.7 * inch, 1.3 * inch, 1.1 * inch], fs=8)

P("75.3 Verificación antes de confirmar un servicio", 'h1')
CHK([
    "Cliente correcto.",
    "Dirección correcta.",
    "Tipo de servicio correcto.",
    "Fecha y hora.",
    "Equipo asignado conforme a la matriz de staffing.",
    "Duración estimada.",
    "Notas importantes de la propiedad.",
    "Solicitudes y preferencias especiales del cliente.",
])

P("75.4 Regla de cambios", 'h1')
TAG("R")
NUM([
    "Revisar disponibilidad.",
    "Confirmar nueva fecha y hora con el cliente.",
    "Actualizar el sistema.",
    "Verificar que el equipo asignado sigue siendo el correcto.",
    "Confirmar el cambio al cliente.",
])
BOX(None, [
    "<b>Si el cambio no está registrado en el sistema, operacionalmente el cambio no está terminado.</b> Esto "
    "evita que alguien trabaje con información vieja o que existan versiones distintas del calendario."])

P("75.5 Exactitud de la asignación de equipo", 'h1')
TAG("C")
FLOW(["Fecha", "Propiedad", "Equipo asignado", "Personas que trabajaron", "Tiempo estimado"])
P("Esta cadena es la que se utiliza para reconstruir las horas de payroll. Si el sistema indica tres personas y "
  "realmente fueron cuatro, la información utilizada después para pagar y para medir productividad será "
  "incorrecta. La exactitud de este campo no es un detalle administrativo: es la base del pago del personal.")

P("75.6 Límite del sistema: control de horas", 'h1')
TAG("C")
P("Actualmente el sistema no constituye una fuente confiable de control de horas. El registro de entrada y salida "
  "solo lo utiliza la dirección y con frecuencia se omite; los colaboradores no tienen obligación de registrar sus "
  "horas ahí, y no se desea utilizar el sistema durante la ejecución del servicio porque la prioridad en la "
  "propiedad es limpiar, no administrar.")
BOX("Regla", [
    "<b>No se deben utilizar automáticamente los registros del sistema de gestión como si fueran horas reales "
    "trabajadas.</b> El sistema indica qué casas se hicieron y quién estuvo asignado; las horas se consolidan en "
    "el registro de horas."])

P("75.7 Qué no debe depender de este sistema", 'h1')
P("El sistema de gestión coordina información; no define las reglas de la empresa. Siguen estando en este manual: "
  "cómo se asignan trabajadores, cómo se determina el tamaño del equipo, qué equipo llevar, cómo se manejan "
  "clientes especiales, cómo se calculan las horas de payroll, cómo se controla la calidad, cómo se gestionan "
  "quejas, cómo se manejan leads y cómo se hace seguimiento.")

P("75.8 Checklist diario del sistema de gestión", 'h1')
CHK([
    "Revisar los servicios del día.",
    "Revisar cambios registrados desde el cierre anterior.",
    "Verificar equipos asignados.",
    "Revisar notas especiales de cada propiedad.",
    "Identificar servicios con alcance especial.",
    "Confirmar información de clientes nuevos.",
    "Revisar oportunidades pendientes de acción.",
], "Apertura")
CHK([
    "Confirmar trabajos realizados.",
    "Actualizar cambios, reprogramaciones y cancelaciones.",
    "Verificar que las asignaciones quedaron correctas.",
    "Actualizar los invoices que correspondan.",
    "Registrar información relevante de la jornada.",
    "Revisar pendientes del día siguiente.",
], "Cierre")

P("75.9 Estándar de datos", 'h1')
FLOW(["Correcta", "Completa", "Actualizada", "Consistente"])
P("El estándar del Capítulo 81 aplica íntegramente a este sistema, con especial atención a la nomenclatura del "
  "tipo de servicio: un mismo servicio registrado con cuatro nombres distintos hace imposible medir la operación.")

P("75.10 Guía de software asociada", 'h1')
P("La navegación concreta —dónde se crea un cliente, cómo se edita una cita, cómo se emite un invoice— pertenece "
  "a una guía separada que puede actualizarse cuando la interfaz cambie sin tocar este manual.")

# ---------- CAP 76 ----------
CAP("76", "CleanCore — sistema nervioso digital de Ecobay")
P("76.1 Qué es CleanCore para Ecobay", 'h1')
TAG("R")
P("CleanCore no debe tratarse como un simple CRM. Es una plataforma de automatización y gestión comercial "
  "construida para empresas de limpieza, con una arquitectura comparable a la de las plataformas de automatización "
  "de marketing y ventas del mercado. Para Ecobay debe considerarse una de las plataformas centrales del sistema "
  "empresarial.")
TBL([
    ["CleanCore es simultáneamente", "Función en Ecobay"],
    ["CRM", "Registro completo de la relación con cada contacto."],
    ["Lead management", "Pipeline comercial con etapas, criterios y acción siguiente."],
    ["Communication hub", "Centralización de llamadas, mensajes, correo y chat."],
    ["Marketing automation", "Campañas segmentadas y comunicación programada."],
    ["Sales pipeline", "Oportunidades, cotizaciones y cierre."],
    ["Follow-up engine", "Secuencias de seguimiento que no dependen de la memoria."],
    ["Client success system", "Onboarding, satisfacción, retención y recuperación."],
    ["Recruiting system", "Pipeline de candidatos y comunicación de reclutamiento."],
    ["Automation engine", "Workflows con disparador, condiciones, acciones y excepciones."],
    ["Reporting layer", "Indicadores comerciales, de clientes y de reclutamiento."],
    ["SOP / knowledge system", "Repositorio de procedimientos y material de capacitación."],
    ["AI support layer", "Apoyo a la calificación y a la atención, bajo revisión humana."],
], [2.1 * inch, 4.4 * inch], fs=8.5)
BOX("Objetivo de este capítulo", [
    "Convertir CleanCore de <i>«un lugar donde guardamos clientes»</i> en <b>el sistema nervioso digital de "
    "Ecobay</b>, sin que la empresa dependa intelectualmente de él. El negocio lo definen los procesos; CleanCore "
    "los captura, organiza, comunica, automatiza, mide, alerta, documenta y ayuda a escalar."])

P("76.2 Estado actual y regla de validación", 'h1')
TAG("C")
P("Ecobay cuenta con acceso a CleanCore. La plataforma se ha abierto en muy pocas ocasiones y no existe certeza de "
  "si la información del sistema de gestión de servicios fue transferida. Por lo tanto:")
BOX("Punto de verificación previo a cualquier configuración", [
    "<b>No debe asumirse que la migración de información fue completada.</b> El primer paso de la implantación es "
    "auditar qué datos existen hoy en CleanCore, cuáles están duplicados y cuáles faltan."])
P("Los módulos descritos a continuación son capacidades de la plataforma. Este manual no afirma que estén "
  "configurados ni activos en la cuenta de Ecobay. Cada uno debe validarse antes de darse por operativo.")

P("76.3 Inventario de módulos y su uso previsto", 'h1')
TAG("P")
TBL([
    ["Módulo", "Uso previsto en Ecobay", "Prioridad"],
    ["CRM y gestión de contactos", "Registro único de clientes, prospectos y candidatos.", "Fase 1"],
    ["Campos personalizados", "Preferencias, condiciones de propiedad, recurrencia, origen.", "Fase 1"],
    ["Pipelines y oportunidades", "Pipeline comercial, de reactivación y de reclutamiento.", "Fase 1"],
    ["Conversaciones centralizadas", "Un solo hilo por contacto, con todos los canales.", "Fase 1"],
    ["SMS y correo", "Respuesta inicial, seguimiento y confirmaciones.", "Fase 1"],
    ["Telefonía y seguimiento de llamada perdida", "Captura de llamadas y mensaje automático ante llamada no atendida.", "Fase 1"],
    ["Formularios", "Captura estructurada de solicitudes y de aplicaciones de trabajo.", "Fase 1"],
    ["Workflows y automatizaciones", "Secuencias de seguimiento, recordatorios y campañas.", "Fase 2"],
    ["Calendarios", "Agendamiento de evaluaciones presenciales y entrevistas.", "Fase 2"],
    ["Encuestas", "Verificación de satisfacción posterior al servicio.", "Fase 2"],
    ["Gestión de reputación", "Solicitud de reseñas y detección de feedback negativo.", "Fase 2"],
    ["Email marketing", "Comunicación periódica y campañas de reactivación.", "Fase 2"],
    ["Reclutamiento", "Pipeline de candidatos y comunicación automatizada.", "Fase 2"],
    ["Reportes y dashboard", "Panel de administración con indicadores.", "Fase 3"],
    ["Chat widget y chat en vivo", "Captura de leads desde el sitio web.", "Fase 3"],
    ["Funnels y landing pages", "Páginas de captación por servicio o campaña.", "Fase 3"],
    ["Planificador de redes sociales", "Programación de contenido (Capítulo 82-A).", "Fase 3"],
    ["SOP Vault", "Repositorio de procedimientos y capacitación.", "Fase 3"],
    ["IA conversacional y de apoyo", "Preselección de candidatos y apoyo a la atención, con revisión humana.", "Fase 3"],
    ["Integraciones y webhooks", "Conexión con el sistema de gestión de servicios.", "Fase 3"],
], [1.85 * inch, 3.55 * inch, 1.1 * inch], fs=8)

P("76.4 CleanCore como fuente única de verdad", 'h1')
TAG("R")
P("Cuando CleanCore sea el sistema apropiado para almacenar una información, esa información no debe mantenerse "
  "únicamente en teléfonos personales, mensajes privados, papeles, conversaciones aisladas, la memoria de la "
  "administración ni hojas de cálculo innecesarias.")
P("La regla tiene un límite explícito: CleanCore no reemplaza a todos los sistemas. La matriz del Capítulo 73.3 "
  "define qué vive dónde. Payroll, banca, contabilidad y ejecución operativa permanecen en sus sistemas "
  "especializados.")

P("76.5 Pipeline comercial recomendado", 'h1')
TAG("P", "estructura recomendada; los nombres definitivos requieren aprobación de la dirección")
TBL([
    ["Etapa", "Criterio de entrada", "Información requerida", "Acción siguiente", "Criterio de salida"],
    ["Nuevo lead", "Solicitud recibida por cualquier canal.", "Nombre, contacto, servicio, origen.", "Primer contacto.", "Contacto intentado."],
    ["Contacto intentado", "Se intentó contactar sin respuesta.", "Registro del intento.", "Reintento según secuencia.", "Contacto logrado o cierre."],
    ["Contactado", "Conversación establecida.", "Necesidad expresada.", "Calificar.", "Información suficiente."],
    ["Calificando", "En obtención de información.", "Servicio, dirección, tamaño, condición, fecha.", "Completar datos.", "Calificado o descartado."],
    ["Requiere fotos o video", "Falta información visual.", "Áreas a evaluar.", "Solicitar material.", "Material recibido."],
    ["Requiere evaluación", "Trabajo complejo o incierto.", "Disponibilidad para visita.", "Agendar evaluación.", "Evaluación realizada."],
    ["Cotización lista", "Precio determinado.", "Alcance e inclusiones.", "Enviar cotización.", "Cotización enviada."],
    ["Cotización enviada", "El prospecto tiene el precio.", "Fecha de envío.", "Seguimiento.", "Aceptada o rechazada."],
    ["En seguimiento", "Sin respuesta del prospecto.", "Contactos realizados.", "Secuencia de seguimiento.", "Respuesta o cierre."],
    ["Ganado", "Servicio aceptado.", "Alcance, fecha y preferencias.", "Programar y traspasar a operación.", "Servicio agendado."],
    ["Perdido", "El prospecto no contrata.", "Motivo de pérdida.", "Registrar y analizar.", "Cerrado."],
    ["Nutrición futura", "No ahora, con potencial.", "Momento estimado de interés.", "Contacto programado.", "Reingreso al pipeline."],
], [1.15 * inch, 1.5 * inch, 1.5 * inch, 1.3 * inch, 1.05 * inch], fs=7.5)
BOX("Regla del pipeline", [
    "Toda etapa, salvo Ganado y Perdido, debe tener una acción siguiente con fecha y un responsable. "
    "<b>Una oportunidad sin próximo paso definido es una oportunidad que se pierde.</b>"])

P("76.6 Automatizaciones del ciclo comercial y de servicio", 'h1')
TAG("P")
TBL([
    ["Disparador", "Acción automática", "Responsabilidad humana posterior"],
    ["Nuevo lead recibido", "Acuse de recepción inmediato.", "Revisión, calificación y respuesta personalizada."],
    ["Llamada perdida", "Mensaje de texto de contacto.", "Devolución de la llamada."],
    ["Formulario enviado", "Confirmación de recepción.", "Calificación."],
    ["Solicitud de cotización", "Petición de la información faltante.", "Determinación del método de evaluación."],
    ["Sin respuesta del prospecto", "Secuencia de seguimiento programada.", "Contacto directo antes del cierre."],
    ["Cotización enviada", "Recordatorio de seguimiento.", "Llamada de cierre."],
    ["Servicio agendado", "Confirmación al cliente.", "Verificación del equipo asignado."],
    ["Previo al servicio", "Comunicación de preparación al cliente.", "Resolución de dudas de acceso."],
    ["Servicio completado", "Verificación de satisfacción.", "Atención de cualquier observación."],
    ["Satisfacción confirmada", "Solicitud de reseña.", "Solicitud de referido cuando corresponda."],
    ["Feedback negativo", "Ninguna solicitud pública; alerta interna.", "Contacto humano y recuperación del servicio."],
    ["Cliente recurrente", "Comunicación de retención periódica.", "Revisión de continuidad."],
    ["Cliente inactivo", "Campaña de reactivación segmentada.", "Seguimiento humano de respuestas."],
], [1.6 * inch, 2.5 * inch, 2.4 * inch], fs=8)

P("76.7 Matriz humano vs. automatización", 'h1')
TAG("R")
TBL([
    ["Proceso", "Tratamiento", "Por qué"],
    ["Confirmación de recepción", "Automatizar", "Repetitivo y predecible."],
    ["Recordatorio de servicio", "Automatizar", "Repetitivo y predecible."],
    ["Solicitud de reseña tras satisfacción", "Automatizar", "Condicionado a una verificación previa."],
    ["Calificación básica del lead", "Automatizar con revisión humana", "La regla es clara, la excepción no."],
    ["Preselección de candidatos", "Automatizar con revisión humana", "Filtra requisitos objetivos; no decide."],
    ["Reactivación", "Automatizar con escalamiento humano", "El envío es masivo; la respuesta es individual."],
    ["Cotización compleja o con evaluación", "Humano", "Requiere criterio sobre el alcance real."],
    ["Queja o reclamo", "Humano", "Requiere contención y decisión."],
    ["Oportunidad comercial de alto valor", "Humano, con aprobación del Owner", "Impacto económico y de marca."],
    ["Respuesta a reseña pública negativa", "Humano, con aprobación del Owner", "Exposición pública de la marca."],
], [2.5 * inch, 2.2 * inch, 1.8 * inch], fs=8)

P("76.8 Regla de automatización", 'h1')
TAG("R")
P("No se automatiza una tarea simplemente porque la plataforma lo permita. Antes de crear cualquier "
  "automatización deben responderse siete preguntas:")
NUM([
    "¿La tarea es repetitiva?",
    "¿Es predecible?",
    "¿Existe una regla clara que la gobierne?",
    "¿Puede automatizarse sin afectar la experiencia del cliente?",
    "¿Qué ocurre si la automatización falla?",
    "¿Cómo se detecta el error?",
    "¿Quién recibe la excepción?",
])
BOX(None, ["<b>Una automatización mal diseñada solamente automatiza el caos.</b>"])

P("76.9 Gobierno de automatizaciones", 'h1')
TAG("R")
P("Cada workflow activo debe estar documentado con la siguiente ficha. Un workflow sin ficha no puede auditarse, "
  "no puede transferirse a otra persona y no puede replicarse en una futura ubicación.")
TBL([
    ["Campo", "Contenido", "Ejemplo aplicado"],
    ["Nombre", "Identificación del workflow.", "Respuesta a lead nuevo"],
    ["Propósito", "Qué problema resuelve.", "Que ningún lead quede sin acuse de recibo."],
    ["Disparador", "Evento que lo activa.", "Lead nuevo recibido."],
    ["Condiciones", "Filtros que deben cumplirse.", "Dentro de horario; canal identificado."],
    ["Acciones", "Qué ejecuta.", "Envío de acuse y creación de tarea de seguimiento."],
    ["Responsable", "Quién responde por él.", "Administración."],
    ["Manejo de excepciones", "Qué ocurre si falla o si el caso es atípico.", "Lead de alto valor o complejo se deriva a revisión humana."],
    ["Escalamiento", "A quién se deriva la excepción.", "Owner."],
    ["Criterio de salida", "Cuándo deja de aplicar al contacto.", "Contacto respondido o lead cerrado."],
    ["Indicador", "Cómo se mide su efecto.", "Tiempo de respuesta y tasa de contacto."],
    ["Versión y última revisión", "Control de cambios.", "Registro de versión."],
    ["Estado", "Activo, en pruebas o inactivo.", "Activo."],
], [1.3 * inch, 2.5 * inch, 2.7 * inch], fs=8)
BOX(None, [
    "<b>Nunca se crea una automatización sin definir qué ocurre cuando el flujo encuentra una excepción y quién la "
    "recibe.</b>"])

P("76.10 Customer journey en CleanCore", 'h1')
TAG("P")
FLOW(["Lead", "Contacto", "Calificación", "Cotización", "Booking"])
FLOW(["Pre-servicio", "Servicio", "Post-servicio", "Feedback", "Reseña"])
FLOW(["Recurrente", "Retención", "Referido", "Reactivación"])
TBL([
    ["Etapa", "Qué debe ocurrir", "Qué se registra", "Qué se automatiza", "Indicador"],
    ["Lead", "Captura de la solicitud.", "Origen, servicio, contacto.", "Acuse de recepción.", "Leads por canal."],
    ["Contacto", "Primer contacto efectivo.", "Fecha y resultado.", "Recordatorio de contacto.", "Tiempo de respuesta."],
    ["Calificación", "Verificar servicio, cobertura y alcance.", "Datos de la propiedad.", "Solicitud de datos faltantes.", "Tasa de contacto."],
    ["Cotización", "Precio conforme al trabajo real.", "Método usado y precio.", "Recordatorio de seguimiento.", "Tasa de cotización."],
    ["Booking", "Aceptación y agendamiento.", "Alcance, fecha, preferencias.", "Confirmación al cliente.", "Tasa de cierre."],
    ["Pre-servicio", "Cliente preparado y equipo informado.", "Instrucciones de acceso.", "Recordatorio previo.", "Cancelaciones tardías."],
    ["Servicio", "Ejecución al estándar.", "Equipo real y tiempo.", "—", "Servicios completados."],
    ["Post-servicio", "Cierre y verificación.", "Resultado de inspección.", "Encuesta de satisfacción.", "Incidencias."],
    ["Feedback", "Detección temprana de problemas.", "Respuesta del cliente.", "Alerta ante feedback negativo.", "Feedback negativo detectado."],
    ["Reseña", "Solicitud solo si hay satisfacción.", "Reseña obtenida.", "Solicitud de reseña.", "Reseñas y calificación."],
    ["Recurrente", "Conversión a servicio periódico.", "Frecuencia acordada.", "Comunicación de retención.", "Conversión a recurrente."],
    ["Retención", "Continuidad y calidad sostenida.", "Servicios y quejas.", "Comunicación periódica.", "Bajas de recurrentes."],
    ["Referido", "Solicitud tras satisfacción.", "Cliente que refiere.", "Solicitud de referido.", "Referidos generados."],
    ["Reactivación", "Recuperación de inactivos.", "Segmento y respuesta.", "Campaña segmentada.", "Clientes reactivados."],
], [0.95 * inch, 1.6 * inch, 1.35 * inch, 1.4 * inch, 1.2 * inch], fs=7.5)

P("76.11 Client success", 'h1')
TAG("P")
P("Los siguientes flujos se clasifican por estado de implantación. Ninguno debe presentarse como política vigente "
  "hasta ser aprobado y configurado.")
TBL([
    ["Flujo", "Estado", "Contenido"],
    ["Onboarding de cliente nuevo", "Recomendado", "Confirmación, alcance del servicio, qué esperar y cómo comunicarse."],
    ["Comunicación previa al servicio", "Recomendado", "Recordatorio, acceso y preparación de la propiedad."],
    ["Recordatorio de servicio recurrente", "Recomendado", "Aviso previo a cada servicio programado."],
    ["Verificación de satisfacción", "Recomendado", "Contacto posterior al servicio para detectar problemas."],
    ["Solicitud de reseña", "Recomendado", "Solo tras satisfacción confirmada."],
    ["Solicitud de referido", "Recomendado", "Tras satisfacción confirmada."],
    ["Promoción de recurrencia", "Recomendado", "Oferta de servicio periódico a cliente puntual satisfecho."],
    ["Recuperación de servicio", "Recomendado", "Gestión humana de la incidencia hasta el cierre."],
    ["Seguimiento de queja", "Recomendado", "Confirmación de resolución con el cliente."],
    ["Retención de largo plazo", "Futuro", "Comunicación periódica de valor al cliente estable."],
    ["Reactivación de inactivos", "Futuro", "Campaña segmentada por criterio comercial."],
    ["Rescate ante cancelación", "Futuro", "Contacto antes de dar de baja definitiva."],
    ["Comunicación de fechas especiales", "Futuro", "Solo si la dirección lo considera apropiado."],
], [1.9 * inch, 1.0 * inch, 3.6 * inch], fs=8)

P("76.12 Sistema de ingreso recurrente", 'h1')
TAG("P")
FLOW(["Cliente puntual", "Servicio exitoso", "Satisfacción confirmada", "Oferta de recurrencia", "Cliente recurrente"])
TBL([
    ["Definición requerida", "Contenido", "Estado"],
    ["Cuándo se presenta la oferta", "Después de confirmar satisfacción, nunca con una incidencia abierta.", "Regla propuesta"],
    ["Quién la presenta", "Administración o Customer Success.", "Propuesto"],
    ["Qué se automatiza", "El contacto y el recordatorio; no la negociación.", "Propuesto"],
    ["Qué se registra", "Respuesta del cliente y frecuencia acordada.", "Propuesto"],
    ["Cómo se mide", "Conversión de puntual a recurrente por período y por canal de origen.", "Propuesto"],
    ["Límite de contacto", "Frecuencia máxima para no resultar invasivo.", "Regla propuesta"],
    ["Condiciones comerciales", "Precio, descuento o incentivo de la oferta.", "Decisión de dirección"],
], [1.8 * inch, 3.4 * inch, 1.3 * inch], fs=8.5)

P("76.13 Reactivación", 'h1')
TAG("P")
FLOW(["Segmento", "Mensaje", "Automatización", "Seguimiento humano", "Ganado o cerrado"])
TBL([
    ["Criterio de segmentación", "Uso"],
    ["Tiempo transcurrido desde el último servicio", "Determina el tono y la probabilidad de retorno."],
    ["Tipo de servicio realizado", "Un cliente de post-construction no se reactiva como uno recurrente."],
    ["Frecuencia histórica", "Distingue al cliente estable del ocasional."],
    ["Valor histórico", "Prioriza el esfuerzo comercial."],
    ["Satisfacción registrada", "Un cliente insatisfecho requiere recuperación, no promoción."],
    ["Motivo de pérdida cuando esté disponible", "Determina si la reactivación tiene sentido."],
], [2.6 * inch, 3.9 * inch], fs=8.5)

P("76.14 Reputación", 'h1')
TAG("R")
FLOW(["Servicio completado", "Verificación de satisfacción", "Satisfecho", "Solicitud de reseña"])
P("Cuando el cliente indica una experiencia negativa, el flujo cambia:")
FLOW(["Feedback negativo", "Sin solicitud pública", "Contacto humano", "Recuperación", "Resolución", "Cierre"])
BOX("Límite ético", [
    "El objetivo del sistema es <b>detectar el problema antes de pedir la reseña</b>, no ocultar clientes "
    "insatisfechos. No se diseñan tácticas para manipular reseñas ni para filtrar del canal público a quienes "
    "tuvieron una mala experiencia."])

P("76.15 Reclutamiento", 'h1')
TAG("P")
FLOW(["Aplicación", "Acuse automático", "Preselección", "Calificado", "Entrevista"])
FLOW(["Seleccionado", "Documentación", "Onboarding", "Capacitación", "Miembro activo"])
TBL([
    ["Etapa", "Qué se automatiza", "Qué exige criterio humano"],
    ["Aplicación recibida", "Acuse de recibo y captura estructurada.", "—"],
    ["Preselección", "Filtro por requisitos objetivos.", "Revisión de casos límite."],
    ["Calificado", "Invitación a agendar entrevista.", "Confirmación de la invitación."],
    ["Entrevista", "Recordatorio de la cita.", "Evaluación completa del candidato."],
    ["Decisión", "—", "Selección, mantener como candidato o descartar."],
    ["Seleccionado", "Comunicación de próximos pasos y documentación requerida.", "Condiciones finales."],
    ["Onboarding", "Envío de material inicial.", "Asignación de acompañamiento."],
    ["Capacitación", "Entrega de contenido y seguimiento.", "Evaluación y autorización para trabajar."],
], [1.3 * inch, 2.6 * inch, 2.6 * inch], fs=8)
P("Indicadores del proceso: aplicaciones recibidas, candidatos calificados, tasa de entrevista, tasa de "
  "contratación, tiempo hasta la contratación, fuente del candidato y retención tras el onboarding.")
BOX("Regla", [
    "La herramienta puede filtrar por criterios objetivos previamente definidos. <b>La decisión de contratación "
    "corresponde siempre a la empresa</b>, con revisión humana."])

P("76.16 SOP Vault y arquitectura de conocimiento", 'h1')
TAG("P")
FLOW(["Manual maestro", "Biblioteca de SOP", "Work instructions", "Capacitación", "Checklists", "Certificación"])
P("Cuando el repositorio esté configurado, puede alojar procedimientos, guías, videos, material de onboarding, "
  "estándares de limpieza, capacitación de seguridad, capacitación de servicio al cliente y guías de software.")
TBL([
    ["Metadato obligatorio de cada documento", "Propósito"],
    ["Versión", "Control de cambios."],
    ["Propietario", "Quién responde por su exactitud."],
    ["Fecha de emisión", "Inicio de vigencia."],
    ["Última revisión", "Antigüedad real del contenido."],
    ["Próxima revisión", "Evita documentos obsoletos en circulación."],
    ["Estado", "Vigente, en revisión u obsoleto."],
    ["Capacitación requerida", "Quién debe ser entrenado antes de ejecutarlo."],
    ["Checklist relacionada", "Cómo se verifica su cumplimiento."],
], [3.0 * inch, 3.5 * inch], fs=8.5)

P("76.17 Dashboard de administración", 'h1')
TAG("P")
P("El panel debe permitir que la administración abra el sistema y entienda el estado del negocio sin reconstruirlo "
  "manualmente. Solo se incluyen métricas que la plataforma pueda producir a partir de datos reales.")
TBL([
    ["Bloque", "Indicadores"],
    ["Leads", "Leads nuevos, tiempo de respuesta, oportunidades activas, cotizaciones, trabajos cerrados, leads perdidos."],
    ["Ventas", "Tasa de conversión, oportunidades en curso, conversiones a recurrente."],
    ["Clientes", "Clientes activos, clientes nuevos, inactivos, cancelaciones, reactivaciones."],
    ["Servicio", "Programados, completados, reprogramados, cancelados, quejas."],
    ["Reputación", "Reseñas, calificación promedio, feedback recibido, incidencias sin resolver."],
    ["Reclutamiento", "Aplicaciones, calificados, entrevistas, contrataciones, onboarding en curso."],
    ["Operaciones", "Asuntos abiertos, seguimientos pendientes, excepciones de automatización."],
    ["Financiero", "Únicamente métricas obtenibles de los sistemas correspondientes; no se generan estimaciones."],
], [1.3 * inch, 5.2 * inch], fs=8.5)
BOX("Regla del dashboard", [
    "<b>No se inventan métricas que el sistema no pueda producir.</b> Un indicador que requiere reconstrucción "
    "manual no pertenece al dashboard: pertenece a la revisión mensual."])

P("76.18 Gobierno de datos", 'h1')
TAG("R")
P("El objetivo de esta sección es impedir que el mismo concepto se registre de varias formas distintas. No es un "
  "asunto estético: si un servicio aparece como «Deep», «Deep Clean», «Deep Cleaning» y «Deepclean», ningún "
  "indicador será fiable, y una futura franquicia multiplicará el problema por el número de ubicaciones.")
TBL([
    ["Campo", "Valores propuestos"],
    ["Tipo de servicio", "Regular Cleaning · Deep Cleaning · Move-In · Move-Out · Post-Construction · Windows · Carpet Cleaning · Power Washing"],
    ["Origen del lead", "Website · Google LSA · Llamada directa · Referido · Cliente existente · Redes sociales · Otro"],
    ["Estado del contacto", "Contacto · Prospecto · Cliente puntual · Cliente recurrente · Inactivo · Perdido"],
    ["Estado de recurrencia", "No recurrente · Cada 8 días · Cada 15 días · Mensual · Otro"],
    ["Motivo de pérdida", "Precio · Tiempo de respuesta · Fuera de cobertura · Servicio no ofrecido · Sin respuesta · Eligió otro proveedor · Otro"],
    ["Motivo de cancelación", "Cliente reprogramó · Cliente canceló · Problema de acceso · Motivo económico · Insatisfacción · Otro"],
    ["Motivo de queja", "Área incompleta · Calidad insuficiente · Retraso · Daño · Trato · Alcance mal entendido · Otro"],
    ["Etapa de reclutamiento", "Aplicación · Preseleccionado · Calificado · Entrevista · Seleccionado · Onboarding · Activo · Descartado"],
], [1.5 * inch, 5.0 * inch], fs=8)
P("Normas de nomenclatura: un solo idioma por campo, sin abreviaturas improvisadas, sin variantes de mayúsculas y "
  "sin crear un valor nuevo cuando exista uno equivalente. Los valores definitivos deben ser aprobados por la "
  "dirección antes de configurarse.")

P("76.19 Auditoría periódica de CleanCore", 'h1')
TAG("P")
CHK([
    "Leads sin estado definido.",
    "Oportunidades sin acción siguiente.",
    "Leads sin seguimiento registrado.",
    "Clientes con información obligatoria incompleta.",
    "Contactos duplicados.",
    "Contactos en etapas de pipeline incorrectas.",
    "Workflows fallidos.",
    "Excepciones de automatización sin atender.",
    "Conversaciones sin responder.",
    "Llamadas perdidas sin devolución registrada.",
    "Cotizaciones sin seguimiento.",
    "Clientes sin seguimiento posterior al servicio.",
    "Solicitudes de reseña no enviadas tras satisfacción confirmada.",
    "Clientes inactivos sin clasificar.",
    "Candidatos detenidos en el pipeline de reclutamiento.",
    "Procedimientos vencidos en el repositorio.",
    "Etiquetas incorrectas o duplicadas.",
    "Campos obligatorios vacíos.",
])

P("76.20 Niveles de acceso y capacitación", 'h1')
TAG("P")
TBL([
    ["Nivel", "Perfil", "Alcance de acceso", "Capacitación requerida"],
    ["1", "Colaborador", "Material de capacitación y su información de servicio.", "Uso básico y confidencialidad."],
    ["2", "Team Lead", "Servicios de su equipo, notas de propiedad e incidencias.", "Registro de incidencias y horas."],
    ["3", "Administración", "Contactos, pipeline, conversaciones, campañas y calendarios.", "CRM, pipeline, automatizaciones y reportes."],
    ["4", "Ventas / Customer Success", "Pipeline comercial, cotizaciones y client success.", "Proceso comercial y reputación."],
    ["5", "Management", "Reportes, dashboard y configuración operativa.", "Indicadores y gobierno de automatizaciones."],
    ["6", "Corporate / Franquicia", "Estándares, plantillas y reporte consolidado.", "Arquitectura completa y auditoría."],
], [0.5 * inch, 1.35 * inch, 2.6 * inch, 2.05 * inch], fs=8)
BOX("Regla de accesos", [
    "El acceso se asigna por posición, con cuenta individual y con el permiso mínimo necesario. No todos requieren "
    "acceso administrativo completo, y sin cuenta individual no hay trazabilidad de quién hizo qué."])

P("76.21 Arquitectura para múltiples ubicaciones", 'h1')
TAG("P", "principio operacional; requiere validación técnica en CleanCore")
FLOW(["Corporate", "Ubicación 1", "Ubicación 2", "Ubicación 3"])
TBL([
    ["Cada ubicación mantiene", "Corporate establece"],
    ["Sus clientes y leads.", "Estándares de marca."],
    ["Sus pipelines y comunicaciones.", "Workflows obligatorios."],
    ["Su personal y su reclutamiento.", "Campos obligatorios de registro."],
    ["Sus calendarios y su programación.", "Etapas obligatorias del pipeline."],
    ["Sus campañas locales dentro del estándar.", "Estructura de reporte obligatoria."],
    ["Su reporte operativo.", "Estándares de experiencia del cliente y de reseñas."],
    ["Sus proveedores locales de insumos.", "Estándares de capacitación y de calidad."],
], [3.25 * inch, 3.25 * inch], fs=8.5)

P("76.22 Documentación asociada a CleanCore", 'h1')
TBL([
    ["Documento", "Contenido", "Nivel"],
    ["Manual corporativo", "Qué debe suceder: todo lead recibe respuesta y tiene próximo paso.", "1"],
    ["SOP de CleanCore", "Cómo configurarlo: pipeline de leads y workflow correspondiente.", "2"],
    ["Work instruction", "Cómo utilizarlo: crear, editar y activar un workflow.", "3"],
    ["Checklist", "Cómo verificar que el workflow funciona correctamente.", "4"],
    ["Guía en video", "Demostración de pantalla.", "5"],
], [1.6 * inch, 4.3 * inch, 0.6 * inch], fs=8.5)

P("76.23 Principio final", 'h1')
BOX(None, [
    "<b>El negocio lo definen los procesos. CleanCore captura, organiza, comunica, automatiza, mide, alerta, "
    "documenta y ayuda a escalar esos procesos.</b>",
    "Si mañana la plataforma cambia, el proceso debe sobrevivir. Si mañana Ecobay abre nuevas ubicaciones, el "
    "proceso debe poder replicarse. Si mañana la persona que hoy administra deja de hacerlo, otra debe poder "
    "ejecutar el sistema."])

# ---------- CAP 77 ----------
CAP("77", "Google Local Services Ads")
P("77.1 Función dentro de la operación", 'h1')
TAG("C")
P("Google Local Services Ads es un canal de adquisición que genera dos tipos de contacto: llamadas y mensajes. Su "
  "particularidad operativa es que la velocidad de respuesta no solo determina si la venta se cierra: una tasa "
  "elevada de llamadas o mensajes sin responder puede afectar el rendimiento y el posicionamiento del anuncio.")

P("77.2 Proceso general del canal", 'h1')
FLOW(["Lead del anuncio", "Respuesta", "Calificación", "Cotización o visita", "Seguimiento", "Booking", "Sistema de gestión"])
TBL([
    ["Paso", "Qué debe ocurrir", "Responsable", "Registro"],
    ["Revisión del canal", "Revisar leads nuevos, mensajes y llamadas perdidas.", "Administración", "Estado de cada lead."],
    ["Respuesta", "Contacto rápido, profesional y orientado al próximo paso.", "Administración", "Fecha y contenido."],
    ["Calificación", "Verificar servicio, cobertura, tamaño, condición y fecha.", "Administración", "Datos de la propiedad."],
    ["Determinación del método", "Precio establecido, fotos y video, o evaluación presencial.", "Administración", "Método elegido."],
    ["Seguimiento", "Secuencia de contactos hasta obtener respuesta o cerrar.", "Administración", "Contactos realizados."],
    ["Cierre", "Estado final con motivo registrado.", "Administración", "Ganado o motivo de pérdida."],
    ["Traslado", "Registro de la oportunidad en el sistema de gestión.", "Administración", "Cliente y servicio creados."],
], [1.5 * inch, 2.6 * inch, 1.2 * inch, 1.2 * inch], fs=8)

P("77.3 Atención de llamadas del anuncio", 'h1')
TAG("C")
P("La llamada llega mediante un número de reenvío que conecta al cliente con el número del negocio. La estructura "
  "de la llamada es:")
TBL([
    ["Momento", "Contenido"],
    ["Apertura", "Identificación de la empresa y de quien atiende, y ofrecimiento de ayuda."],
    ["Descubrimiento", "Tipo de limpieza, residencial o comercial, servicio específico, dirección o ZIP, tamaño aproximado, fecha requerida, ocupada o vacía, condiciones especiales y servicios adicionales."],
    ["Verificación", "Confirmar que el trabajo está dentro de los servicios y del área de cobertura."],
    ["Definición del método", "Decidir si se cotiza con precio establecido, con material visual o con visita."],
    ["Cierre", "Compromiso concreto: qué se enviará, quién lo hará y cuándo."],
    ["Registro", "Traslado de la información al sistema correspondiente."],
], [1.5 * inch, 5.0 * inch], fs=8.5)
BOX("Regla confirmada", [
    "Si el trabajo no corresponde a Ecobay, la llamada <b>no se ignora</b>: se responde, se informa al prospecto y "
    "se cierra el lead con el motivo correspondiente."])

P("77.4 Llamadas perdidas", 'h1')
TAG("R")
FLOW(["Llamada perdida", "Identificar cliente", "Devolver llamada", "Registrar resultado", "Seguimiento"])
P("Una llamada perdida no es un lead perdido. Puede recuperarse mediante llamada, mensaje, correo o mensaje de "
  "voz, y la devolución se realiza lo antes posible dentro del mismo día operativo. La automatización de un "
  "mensaje inmediato ante llamada perdida se describe en el Capítulo 76.6.")

P("77.5 Atención de mensajes", 'h1')
TAG("C")
NUM([
    "Revisar la bandeja de leads del canal.",
    "Seleccionar el lead y revisar la información proporcionada.",
    "Identificar qué servicio solicita.",
    "Revisar nombre, ZIP code, teléfono y detalles del trabajo.",
    "Responder desde la conversación del canal.",
    "Obtener la información faltante.",
    "Determinar el siguiente paso.",
    "Registrar el resultado.",
])
P("La primera respuesta debe ser rápida, profesional, clara y orientada al siguiente paso. Ejemplo confirmado:")
story.append(Paragraph(
    "«Hi! Thank you for contacting Ecobay Cleaning. We'd be happy to help. Could you please provide the address or "
    "ZIP code, the type of cleaning you're looking for, and your preferred date? Once we have that information, we "
    "can determine the best next step for your cleaning.»", S['quote']))

P("77.6 Estados del lead", 'h1')
TAG("P")
TBL([
    ["Estados de proceso", "Estados de cierre"],
    ["Nuevo lead", "Ganado / agendado"],
    ["Contactado", "Perdido"],
    ["Esperando al cliente", "Fuera de cobertura"],
    ["Evaluación solicitada", "Servicio no ofrecido"],
    ["Cotización enviada", "Duplicado"],
    ["Servicio agendado", "Sin respuesta"],
], [3.25 * inch, 3.25 * inch], fs=8.5)
P("Los nombres deben estandarizarse con la nomenclatura del Capítulo 76.18 para que el canal sea comparable con "
  "los demás.")

P("77.7 Revisión diaria del canal", 'h1')
CHK([
    "Leads nuevos.",
    "Llamadas perdidas.",
    "Mensajes nuevos.",
    "Conversaciones pendientes de respuesta.",
    "Leads esperando respuesta del cliente.",
    "Leads que requieren seguimiento.",
    "Leads contratados pendientes de trasladar al sistema de gestión.",
    "Leads que deben cerrarse con motivo registrado.",
])
BOX("Regla fundamental del canal", [
    "<b>Nunca dejar un lead sin acción siguiente.</b> Cada lead debe estar en uno de cuatro escenarios: responder, "
    "seguimiento, programar o cerrar. Lo que no debe existir es «lo vi y después se me olvidó»."])

P("77.8 Accesos y evolución de la plataforma", 'h1')
TAG("R")
P("El acceso se asigna a cada persona con su propia cuenta y con el nivel mínimo que permita responder leads. No "
  "se comparten contraseñas generales.")
BOX("Nota de independencia tecnológica", [
    "Google está migrando algunas cuentas de Local Services Ads hacia campañas con objetivos de pago por lead, lo "
    "que cambia dónde aparecen los leads dentro de la interfaz. El proceso empresarial de este capítulo no cambia "
    "por ello. La navegación concreta pertenece a la guía de software de nivel 5, que debe elaborarse con capturas "
    "de la cuenta real de Ecobay."])

P("77.9 Indicadores del canal", 'h1')
TBL([
    ["Indicador", "Definición"],
    ["Leads recibidos", "Llamadas y mensajes generados por el anuncio en el período."],
    ["Llamadas no atendidas", "Llamadas perdidas sobre llamadas recibidas."],
    ["Devoluciones realizadas", "Llamadas perdidas devueltas y registradas."],
    ["Tiempo de respuesta", "Tiempo entre la recepción y el primer contacto efectivo."],
    ["Tasa de calificación", "Leads calificados sobre leads recibidos."],
    ["Tasa de cierre", "Leads convertidos sobre leads cotizados."],
    ["Leads no atendibles", "Fuera de cobertura o servicio no ofrecido, sobre el total."],
], [2.1 * inch, 4.4 * inch], fs=8.5)

# ---------- CAP 78 ----------
CAP("78", "Sistema de payroll")
P("78.1 Función", 'h1')
TAG("C")
P("El sistema de payroll procesa los pagos al personal. Actualmente se utiliza Ramp Payroll. No es la fuente de "
  "verdad de las horas trabajadas: recibe información ya consolidada y revisada.")
FLOW(["Sistema de gestión: qué se hizo y quién participó",
      "Registro de horas: cuántas horas corresponden",
      "Sistema de payroll: cómo se paga"])

P("78.2 Regla de separación", 'h1')
TAG("R")
BOX(None, [
    "<b>Mientras no exista un sistema confiable de registro de entrada y salida, no debe asumirse que una hora "
    "registrada en el sistema de gestión de servicios representa las horas reales trabajadas.</b>"])

P("78.3 Qué debe verificarse antes de procesar", 'h1')
CHK([
    "Todos los colaboradores que trabajaron están incluidos.",
    "No existen registros de personas que no trabajaron.",
    "Las propiedades corresponden al día indicado.",
    "Las horas tienen sentido respecto al trabajo realizado.",
    "No existen duplicaciones.",
    "Los totales por colaborador son correctos.",
])
P("Cualquier inconsistencia se resuelve antes de procesar el pago. Un error en payroll afecta directamente al "
  "trabajador y genera un problema administrativo que cuesta más resolver que prevenir.")

P("78.4 Requisitos de un sistema futuro de registro de horas", 'h1')
TAG("P")
B([
    "Identificar al trabajador.",
    "Registrar fecha y propiedad.",
    "Registrar hora de entrada y hora de salida.",
    "Registrar pausas cuando corresponda.",
    "Calcular horas totales.",
    "Asociar el trabajo con el servicio realizado.",
    "Facilitar la revisión antes de procesar el pago.",
    "Ser accesible desde teléfono o computadora y rápido de actualizar.",
])

# ---------- CAP 79 ----------
CAP("79", "Correo, documentos y espacio de trabajo")
P("79.1 Función", 'h1')
P("El correo electrónico es el canal de comunicación formal con clientes, proveedores y candidatos, y el "
  "repositorio documental almacena los documentos que la empresa debe conservar.")

P("79.2 Reglas de uso", 'h1')
TAG("P")
TBL([
    ["Regla", "Razón"],
    ["El correo del negocio no se usa como archivo de la relación con el cliente.", "Esa información pertenece al CRM y debe poder consultarse sin acceso al buzón de una persona."],
    ["Las conversaciones comerciales se centralizan en el CRM.", "Evita que la relación viva en un buzón individual."],
    ["Los documentos de la empresa se almacenan en el repositorio compartido, no en dispositivos personales.", "Continuidad ante ausencia o salida de una persona."],
    ["Cada persona utiliza su propia cuenta.", "Trazabilidad y posibilidad de revocar acceso."],
    ["Los documentos siguen la estructura y nomenclatura definidas.", "Permite encontrarlos sin preguntar."],
], [3.0 * inch, 3.5 * inch], fs=8.5)

P("79.3 Estructura documental", 'h1')
TAG("P")
TBL([
    ["Carpeta", "Contenido", "Acceso"],
    ["Manual y SOP", "Manual corporativo, SOP, work instructions y checklists.", "Según nivel"],
    ["Clientes", "Contratos, cotizaciones formales y documentación de alcance.", "Administración"],
    ["Personal", "Expedientes, documentación y registros de capacitación.", "Administración y Owner"],
    ["Finanzas", "Registros de facturación, cobros y payroll.", "Administración y Owner"],
    ["Operaciones", "Registros de inspección, incidencias y mantenimiento.", "Operations"],
    ["Marketing", "Material de marca, contenido y campañas.", "Administración"],
], [1.3 * inch, 3.5 * inch, 1.7 * inch], fs=8.5)

# ---------- CAP 80 ----------
CAP("80", "Hojas de cálculo y registros auxiliares")
P("80.1 Función legítima de una hoja de cálculo", 'h1')
TAG("C")
P("Ecobay utiliza actualmente una hoja de cálculo para registrar fecha, colaborador, casas realizadas y horas "
  "correspondientes, y consolidar el total por colaborador para preparar el pago. Este archivo constituye el "
  "primer registro formal que sustituyó información que antes existía únicamente en la memoria, y por eso tiene "
  "valor real: no debe eliminarse hasta que exista un sustituto mejor y probado.")

P("80.2 Criterio de permanencia", 'h1')
TAG("P")
TBL([
    ["Una hoja de cálculo es aceptable cuando", "Debe sustituirse cuando"],
    ["Registra información que ningún sistema captura hoy.", "Duplica información que ya vive en un sistema."],
    ["Es más rápida de actualizar que la alternativa.", "Se ha convertido en la fuente de verdad de un proceso crítico sin control de acceso."],
    ["Tiene un responsable identificado.", "Nadie sabe cuál es la versión vigente."],
    ["Su estructura es estable y comprensible.", "Cada persona la modifica a su criterio."],
    ["Existe una copia accesible para el respaldo.", "Vive en el dispositivo de una sola persona."],
], [3.25 * inch, 3.25 * inch], fs=8.5)

P("80.3 Requisitos mínimos de todo registro auxiliar", 'h1')
CHK([
    "Tiene un responsable identificado.",
    "Tiene una ubicación única y compartida.",
    "Tiene una estructura de columnas estable.",
    "Usa la nomenclatura oficial de la empresa.",
    "Es accesible para el responsable de respaldo.",
    "Está incluido en la matriz de fuente de verdad.",
    "Tiene una frecuencia de actualización definida.",
])

# ---------- CAP 81 ----------
CAP("81", "Integridad de datos")
P("81.1 Estándar", 'h1')
TAG("R")
FLOW(["Correcta", "Completa", "Actualizada", "Consistente"])
TBL([
    ["Atributo", "Qué significa", "Falla típica", "Cómo se verifica"],
    ["Correcta", "El dato refleja la realidad de la operación.", "Equipo asignado distinto del que realmente trabajó.", "Contraste con lo ejecutado."],
    ["Completa", "Los campos obligatorios están presentes.", "Lead sin origen registrado.", "Auditoría de campos vacíos."],
    ["Actualizada", "El cambio se registró cuando ocurrió.", "Cambio de horario acordado por teléfono y no registrado.", "Revisión de cierre diario."],
    ["Consistente", "El mismo concepto se nombra siempre igual.", "Cuatro variantes del mismo tipo de servicio.", "Nomenclatura oficial."],
], [1.0 * inch, 1.9 * inch, 2.0 * inch, 1.6 * inch], fs=8)

P("81.2 Verificación de cierre de jornada", 'h1')
CHK([
    "¿Los servicios del día están correctos?",
    "¿Los equipos están correctamente asignados?",
    "¿Las casas realizadas aparecen correctamente?",
    "¿Las cancelaciones fueron actualizadas?",
    "¿Los cambios de horario están registrados?",
    "¿Las notas importantes están disponibles para quien prepara el equipo?",
    "¿Los invoices correspondientes están actualizados?",
    "¿Los leads del día tienen estado y acción siguiente?",
])

P("81.3 Responsabilidad sobre el dato", 'h1')
TAG("R")
BOX(None, [
    "<b>Cada campo obligatorio tiene un responsable.</b> Un dato sin dueño se degrada: nadie lo corrige porque "
    "nadie responde por él."])
P("Cuando un dato aparece incorrecto, el procedimiento es corregirlo, identificar en qué punto del proceso se "
  "originó el error y, si el error se repite, modificar el proceso en lugar de seguir corrigiendo el síntoma.")

# ---------- CAP 82 ----------
CAP("82", "Accesos, permisos y seguridad de información")
P("82.1 Principio de acceso mínimo", 'h1')
TAG("R")
P("El acceso se asigna por posición y se limita a lo necesario para ejecutar los procesos de esa posición. No "
  "todos los usuarios requieren acceso administrativo completo.")
TBL([
    ["Nivel", "Posición", "Alcance"],
    ["1", "Colaborador", "Información de sus servicios asignados y material de capacitación."],
    ["2", "Team Lead", "Servicios de su equipo, notas de propiedad, registro de horas e incidencias."],
    ["3", "Administración", "Clientes, leads, schedule, comunicaciones, invoices y registros de horas."],
    ["4", "Operations", "Servicios, equipos, inventario, calidad e incidencias."],
    ["5", "Owner", "Acceso completo, incluida configuración e información financiera."],
], [0.5 * inch, 1.5 * inch, 4.5 * inch], fs=8.5)

P("82.2 Reglas de cuentas", 'h1')
TAG("R")
B([
    "Cada persona accede con su propia cuenta. No se comparten contraseñas generales.",
    "El acceso se otorga al incorporarse y se revoca el mismo día de la salida.",
    "El acceso a información financiera y de personal se limita a Administración y Owner.",
    "Los cambios de nivel de acceso los aprueba el Owner.",
    "La información de clientes no se descarga ni se comparte fuera de los sistemas de la empresa.",
])

P("82.3 Alta y baja de accesos", 'h1')
CHK([
    "Cuenta creada con el nivel correspondiente a la posición.",
    "Capacitación de uso y de confidencialidad completada.",
    "Compromiso de confidencialidad firmado.",
    "Acceso a los documentos que la posición requiere.",
], "Al incorporarse")
CHK([
    "Acceso revocado en todos los sistemas.",
    "Devolución de equipo y de material de la empresa.",
    "Transferencia de la información y de los pendientes a otra persona.",
    "Verificación de que no queda información de clientes en dispositivos personales.",
], "Al finalizar la relación")

P("82.4 Confidencialidad", 'h1')
TAG("C", "obligación vigente conforme al acuse del manual")
P("El contenido de los manuales de Ecobay y la información de sus clientes son propiedad de la empresa y no deben "
  "difundirse a terceros, incluidos familiares y otras compañías. Esta obligación se extiende a la información de "
  "acceso a las propiedades, a los datos de contacto de los clientes y a cualquier información operativa interna.")

# ---------- CAP 82-A ----------
CAP("82-A", "Social media y presencia digital")
P("82-A.1 Estado actual", 'h1')
P("Ecobay no cuenta hoy con un proceso documentado de presencia en redes sociales: no están definidos qué canales "
  "se mantienen, quién publica, con qué frecuencia, qué se publica ni quién responde los mensajes que llegan por "
  "esa vía. El riesgo principal no es la falta de publicaciones, sino que un mensaje entrante quede sin respuesta "
  "porque no pertenece formalmente a nadie.")

P("82-A.2 Función de las redes sociales en el modelo", 'h1')
TAG("P")
TBL([
    ["Función", "Qué aporta", "Qué no debe esperarse"],
    ["Prueba social", "Evidencia visible de trabajo real y de estándar de calidad.", "Que sustituya la reputación construida con reseñas."],
    ["Captación complementaria", "Leads adicionales de bajo costo.", "Que reemplace los canales principales de adquisición."],
    ["Refuerzo de referidos", "Da al cliente satisfecho algo que compartir.", "Que genere referidos sin un servicio bien ejecutado."],
    ["Reclutamiento", "Canal de difusión de vacantes.", "Que sustituya el proceso de selección."],
    ["Identidad", "Comunica el posicionamiento eco-friendly.", "Que compense una identidad no definida internamente."],
], [1.4 * inch, 2.6 * inch, 2.5 * inch], fs=8)

P("82-A.3 Proceso general de gestión", 'h1')
TAG("P")
FLOW(["Planificar", "Producir", "Aprobar", "Programar", "Publicar", "Responder", "Medir"])
TBL([
    ["Paso", "Qué ocurre", "Responsable", "Frecuencia"],
    ["Planificar", "Definir los temas del período según el calendario de contenido.", "Administración", "Mensual"],
    ["Producir", "Capturar fotografías y preparar los textos.", "Operations y Administración", "Continua"],
    ["Aprobar", "Verificar consentimiento, calidad y coherencia de marca.", "Owner", "Antes de programar"],
    ["Programar", "Cargar las publicaciones con fecha y canal.", "Administración", "Semanal"],
    ["Publicar", "Publicación automática según programación.", "Automatización", "Según calendario"],
    ["Responder", "Atender mensajes y comentarios entrantes.", "Administración", "Diaria"],
    ["Medir", "Revisar alcance, interacción y leads generados.", "Administración", "Mensual"],
], [1.1 * inch, 2.7 * inch, 1.6 * inch, 1.1 * inch], fs=8)

P("82-A.4 Regla de mensajes entrantes", 'h1')
TAG("R")
BOX(None, [
    "<b>Un mensaje recibido por redes sociales es un lead y se trata como tal:</b> se responde, se registra con "
    "origen «Redes sociales», se califica y termina con un estado definido. No es un canal informal exento del "
    "proceso comercial."])
P("Cuando la plataforma lo permita, las conversaciones de redes sociales deben centralizarse en el mismo lugar "
  "que el resto de los canales, para que la relación con el contacto sea una sola y no dependa de quién tenga la "
  "aplicación instalada en su teléfono.")

P("82-A.5 Tipos de contenido", 'h1')
TAG("P")
TBL([
    ["Tipo", "Contenido", "Requisito previo"],
    ["Antes y después", "Resultado real de un servicio ejecutado.", "Autorización expresa del cliente."],
    ["Educativo", "Cuidado de superficies, frecuencia recomendada, preparación previa a un servicio.", "Coherencia con el manual técnico."],
    ["Identidad", "Enfoque eco-friendly y criterios de selección de producto.", "Exactitud: no afirmar lo que no se cumple."],
    ["Equipo", "Presentación del equipo y de su trabajo.", "Consentimiento de las personas mostradas."],
    ["Reclutamiento", "Difusión de vacantes.", "Condiciones reales del puesto."],
    ["Testimonios", "Opiniones de clientes.", "Autorización y veracidad."],
    ["Servicios", "Explicación de cada tipo de servicio y su alcance.", "Coherencia con lo que se vende."],
], [1.3 * inch, 3.2 * inch, 2.0 * inch], fs=8)

P("82-A.6 Reglas de contenido", 'h1')
TAG("R")
B([
    "No se publica el interior de una propiedad sin autorización expresa del cliente.",
    "No se publican direcciones, referencias de ubicación ni información de acceso.",
    "No se publican datos que permitan identificar a un cliente sin su consentimiento.",
    "No se muestran rostros de personas sin su autorización.",
    "No se prometen resultados, tiempos o alcances distintos de los que la empresa entrega.",
    "No se responde públicamente a una queja con detalles del caso; se traslada a canal privado.",
    "El contenido debe ser coherente con el posicionamiento eco-friendly y con el estándar técnico del manual.",
])

P("82-A.7 Manejo de comentarios y quejas públicas", 'h1')
TAG("P")
TBL([
    ["Situación", "Acción", "Responsable"],
    ["Consulta de servicio o precio", "Responder y trasladar al proceso comercial como lead.", "Administración"],
    ["Comentario positivo", "Agradecer; solicitar reseña cuando corresponda.", "Administración"],
    ["Queja de un cliente identificable", "Reconocer públicamente y trasladar a canal privado para resolver.", "Administración"],
    ["Queja grave o acusación", "No responder de inmediato; escalar antes de publicar cualquier respuesta.", "Owner"],
    ["Comentario ofensivo o falso", "Aplicar el criterio de moderación definido; no discutir públicamente.", "Owner"],
], [1.8 * inch, 3.4 * inch, 1.3 * inch], fs=8)

P("82-A.8 Indicadores", 'h1')
TBL([
    ["Indicador", "Definición"],
    ["Publicaciones realizadas", "Publicaciones efectivas frente a las planificadas."],
    ["Mensajes recibidos", "Contactos entrantes por este canal en el período."],
    ["Tiempo de respuesta", "Tiempo entre el mensaje y la primera respuesta."],
    ["Leads generados", "Contactos con origen «Redes sociales» registrados en el CRM."],
    ["Leads convertidos", "Clientes cerrados provenientes de este canal."],
    ["Interacción", "Reacciones, comentarios y compartidos por publicación."],
], [2.1 * inch, 4.4 * inch], fs=8.5)

# ---------- CIERRE ----------


PARTE("XI", "Recursos humanos: selección de personal",
      "De la necesidad operativa a un colaborador integrado, con criterios objetivos y decisiones defendibles.",
      ["Capítulo 84. Planificación de personal y reclutamiento",
       "Capítulo 85. Screening de precalificación (Fase 1)",
       "Capítulo 86. Clasificación W-2 y 1099",
       "Capítulo 87. Entrevista de valores (Fase 2)",
       "Capítulo 88. Puntuación, decisión y contratación"])

# ---------- CAP 84 ----------
CAP("84", "Planificación de personal y reclutamiento")
P("84.1 Principio", 'h1')
TAG("R")
BOX(None, [
    "<b>La contratación busca la persona adecuada para la operación, no cubrir un espacio vacío en el "
    "calendario.</b>",
    "Una persona puede tener experiencia en limpieza y aun así no ser adecuada si no demuestra responsabilidad, "
    "buena actitud, capacidad de trabajo en equipo o disposición para seguir procedimientos."])

P("84.2 Definición de la necesidad", 'h1')
CHK([
    "Qué tipo de personal se necesita.",
    "Cuántas personas se necesitan.",
    "Para qué tipo de servicios.",
    "Si la necesidad es permanente o temporal.",
    "Qué días y horarios se necesitan cubrir.",
    "Qué experiencia requiere la posición.",
    "Qué requisitos son indispensables.",
    "Qué características serían deseables.",
])

P("84.3 Publicación de la vacante", 'h1')
TAG("R")
P("La publicación explica el puesto, el tipo de trabajo, los requisitos, la experiencia requerida, la "
  "disponibilidad necesaria, la forma de aplicar y la información relevante. <b>La información publicada debe "
  "corresponder a las condiciones reales del puesto.</b> Publicar condiciones que no se cumplirán produce "
  "rotación temprana, que es la forma más cara de reclutar.")

P("84.4 Flujo completo del proceso", 'h1')
FLOW(["Aplicación", "Fase 1: precalificación", "Clasificación", "Pass o fail", "Fase 2: valores"])
FLOW(["Puntuación", "Referencias y verificación", "Decisión final", "Onboarding"])
TBL([
    ["Etapa", "Responsable", "Qué se automatiza", "Qué exige criterio humano"],
    ["Aplicación", "Sistema", "Acuse de recibo y captura estructurada.", "—"],
    ["Fase 1", "Administración", "Filtro por requisitos objetivos.", "Casos límite."],
    ["Clasificación", "Owner", "—", "W-2 o 1099 conforme a la ley aplicable."],
    ["Fase 2", "Owner o Administración", "Recordatorio de la cita.", "Evaluación completa por escenarios."],
    ["Puntuación", "Entrevistador", "—", "Calificación por valor."],
    ["Verificación", "Administración", "—", "Referencias y documentación."],
    ["Decisión", "Owner", "—", "Contratar, mantener o descartar."],
    ["Onboarding", "Operations", "Envío de material inicial.", "Acompañamiento y evaluación."],
], [1.15 * inch, 1.35 * inch, 2.0 * inch, 2.0 * inch], fs=8)

P("84.5 Recepción y preselección de aplicaciones", 'h1')
TAG("C")
P("Cuando existe volumen elevado de aplicaciones pueden utilizarse herramientas digitales para una primera "
  "clasificación por criterios objetivos previamente definidos, de modo que la revisión humana se concentre en los "
  "candidatos que cumplen los requisitos.")
BOX(None, ["<b>La herramienta puede filtrar. La decisión de contratación corresponde siempre a la empresa.</b>"])

# ---------- CAP 85 ----------
CAP("85", "Screening de precalificación (Fase 1)")
P("85.1 Objetivo y límites legales", 'h1')
TAG("R")
P("La Fase 1 confirma que el candidato cumple los requisitos básicos antes de invertir tiempo en una entrevista de "
  "valores. Se ejecuta en vivo durante una llamada, con preguntas ya definidas: no requiere improvisar.")
BOX("Límite absoluto", [
    "<b>No se pregunta por raza, religión, nacionalidad, edad, discapacidad, estado civil, embarazo ni otras "
    "características protegidas.</b> Todas las preguntas deben ser relevantes al puesto y aplicarse de forma "
    "consistente a todos los candidatos."])

P("85.2 Bloque A — Experiencia", 'h1')
TBL([
    ["Pregunta", "Qué evaluamos", "Buena señal", "Red flag"],
    ["¿Cuántos años de experiencia en limpieza tiene?", "Nivel real de experiencia; más años no equivale a mejor candidato.", "Describe roles y responsabilidades concretas, no solo tiempo.", "Respuestas vagas; no puede explicar qué hacía."],
    ["¿Con qué tipos de propiedades y clientes ha trabajado?", "Si la experiencia calza con el trabajo que ofrecemos.", "Experiencia relevante al tipo de cuenta que cubriría.", "Experiencia totalmente distinta al servicio que necesitamos."],
    ["¿Ha trabajado de forma independiente o en equipo?", "Cómo se desempeña según la estructura del equipo.", "Puede describir su rol en ambos contextos con claridad.", "No puede explicar cómo coordinaba con otros."],
], [1.5 * inch, 1.7 * inch, 1.7 * inch, 1.6 * inch], fs=7.5)

P("85.3 Bloque B — Ubicación y transporte", 'h1')
TBL([
    ["Pregunta", "Qué evaluamos", "Buena señal", "Red flag"],
    ["¿Dónde vive y qué tan lejos está de nuestra área de servicio?", "Viabilidad logística real, no solo intención.", "Distancia razonable o transporte confiable ya resuelto.", "Distancia que hace improbable la consistencia."],
    ["¿Tiene transporte confiable para llegar a los trabajos de forma consistente?", "Riesgo operacional de tardanzas o ausencias.", "Vehículo propio o plan de transporte estable y verificable.", "Depende de terceros sin plan de respaldo."],
], [1.6 * inch, 1.6 * inch, 1.7 * inch, 1.6 * inch], fs=7.5)

P("85.4 Bloque C — Disponibilidad", 'h1')
TBL([
    ["Pregunta", "Qué evaluamos", "Buena señal", "Red flag"],
    ["¿Qué días y horarios tiene disponibles?", "Si su disponibilidad calza con la necesidad operativa real.", "Disponibilidad clara y compatible con los horarios que ofrecemos.", "Disponibilidad muy limitada o poco definida."],
    ["¿Qué tan flexible es con cambios de horario y cuánto aviso necesita?", "Capacidad de adaptación operativa.", "Flexibilidad razonable con comunicación anticipada.", "Rigidez total o no puede dar un tiempo de aviso realista."],
], [1.6 * inch, 1.6 * inch, 1.7 * inch, 1.6 * inch], fs=7.5)

P("85.5 Bloque D — Requisitos físicos", 'h1')
TBL([
    ["Pregunta", "Qué evaluamos", "Buena señal", "Red flag"],
    ["¿Se siente cómodo realizando las tareas físicas del puesto: levantar peso, estar de pie, escaleras, agacharse, periodos prolongados de actividad?", "Capacidad de realizar las funciones esenciales del puesto.", "Responde con confianza y sin dudas sobre las tareas descritas.", "Duda marcada; siempre aclarar si aplica una adaptación razonable antes de descalificar."],
], [2.1 * inch, 1.5 * inch, 1.4 * inch, 1.5 * inch], fs=7.5)
BOX("Regla", [
    "<b>Nunca se pregunta por diagnósticos médicos.</b> Se pregunta por la capacidad de ejecutar las funciones "
    "esenciales descritas, y antes de descalificar se evalúa si existe una adaptación razonable."])

P("85.6 Bloque E — Habilidades y entrenamiento", 'h1')
TBL([
    ["Pregunta", "Qué evaluamos", "Buena señal", "Red flag"],
    ["¿En qué tipos de limpieza tiene entrenamiento o experiencia: residencial, profunda, move-in/out, post-construcción, comercial, pisos?", "Match entre habilidades y el tipo de trabajo a asignar.", "Identifica con precisión en qué es fuerte y en qué necesitaría entrenamiento.", "Dice que domina todo sin poder dar detalle de ningún servicio."],
], [2.1 * inch, 1.5 * inch, 1.5 * inch, 1.4 * inch], fs=7.5)

P("85.7 Bloque F — Documentación básica", 'h1')
TAG("R")
TBL([
    ["Modelo", "Qué se confirma en el screening inicial"],
    ["W-2", "Únicamente que el candidato podrá completar la verificación de elegibilidad de empleo y la documentación de onboarding. <b>No se solicitan documentos sensibles en esta etapa.</b>"],
    ["1099 individual", "Que puede proveer documentación fiscal, información de negocio si aplica, seguro y licencias cuando corresponda."],
], [1.3 * inch, 5.2 * inch], fs=8.5)

P("85.8 Calificación de empresa subcontratista", 'h1')
P("Sección específica para evaluar empresas que operarían como subcontratista. Estas preguntas no son "
  "burocráticas: determinan si la empresa puede realmente cumplir el volumen y si la relación resiste una revisión "
  "de clasificación.")
TBL([
    ["Pregunta", "Qué evaluamos", "Buena señal", "Red flag"],
    ["¿La empresa tiene una entidad de negocio registrada?", "Formalidad legal del negocio.", "Puede confirmar registro y proveer documentación si se solicita.", "No tiene entidad registrada o evade la pregunta."],
    ["¿Tiene seguro de responsabilidad civil general, y compensación laboral o de auto cuando aplique?", "Cobertura de riesgo para ambas partes.", "Pólizas activas y puede emitir certificado de seguro.", "No tiene seguro o no puede proveer comprobante."],
    ["¿Tiene empleados o subcontratistas propios y puede dar referencias?", "Capacidad real de cumplir el volumen ofrecido.", "Equipo propio, referencias verificables, historial comercial.", "Opera solo, sin respaldo ni referencias comprobables."],
    ["¿Puede proveer su propio equipo e insumos y cumplir el alcance y la estructura de precios acordados?", "Autosuficiencia operativa y alineación comercial.", "Confirma capacidad y acepta la estructura de trabajo propuesta.", "Requiere que la empresa contratante le provea todo, lo cual puede afectar la clasificación."],
], [1.6 * inch, 1.5 * inch, 1.7 * inch, 1.7 * inch], fs=7.5)

# ---------- CAP 86 ----------
CAP("86", "Clasificación W-2 y 1099")
P("86.1 Principio rector", 'h1')
TAG("R")
BOX(None, [
    "<b>La clasificación no depende de la preferencia del trabajador ni de cómo la empresa llame la relación.</b> "
    "Depende de la ley federal, estatal y local aplicable, y de la relación de trabajo real."])
P("Esta es una de las decisiones con mayor consecuencia económica y legal del sistema, y una de las más fáciles de "
  "tomar mal por conveniencia operativa. Por eso se documenta como decisión formal con responsable único.")

P("86.2 Señales que apuntan a cada modelo", 'h1')
TAG("P", "señales de referencia levantadas del proceso de screening; no sustituyen una determinación legal")
TBL([
    ["Señal observada", "Apunta hacia", "Por qué"],
    ["La empresa provee equipo, insumos y productos.", "W-2", "Indica dependencia operativa."],
    ["El subcontratista provee su propio equipo e insumos.", "1099 empresa", "Indica autosuficiencia."],
    ["La empresa fija horario y método de trabajo detallado.", "W-2", "Indica control sobre cómo se ejecuta."],
    ["El proveedor tiene entidad registrada, seguro propio y otros clientes.", "1099 empresa", "Indica negocio independiente."],
    ["El proveedor requiere que la contratante le provea todo.", "Riesgo de clasificación", "Puede invalidar el tratamiento 1099."],
], [2.5 * inch, 1.4 * inch, 2.6 * inch], fs=8)

P("86.3 Consecuencias operativas de cada modelo", 'h1')
TBL([
    ["Ámbito", "W-2", "1099"],
    ["Documentación de ingreso", "Verificación de elegibilidad y onboarding.", "Documentación fiscal, seguro y licencias."],
    ["Impuestos de nómina", "Retención y aportes a cargo de la empresa.", "A cargo del contratista."],
    ["Compensación laboral y desempleo", "Aplican los requisitos estatales de empleador.", "Responsabilidad del contratista, verificable por certificado."],
    ["Equipo e insumos", "Provistos por la empresa.", "Provistos por el contratista."],
    ["Capacitación", "Obligatoria conforme al estándar de Ecobay.", "Alineación de estándar, no supervisión de método."],
    ["Registro de horas", "Registro de horas trabajadas.", "Facturación por servicio o alcance acordado."],
], [1.6 * inch, 2.4 * inch, 2.5 * inch], fs=8)

P("86.4 Regla de decisión", 'h1')
TAG("R")
TBL([
    ["Elemento", "Definición"],
    ["Quién decide", "Owner, con asesoría profesional cuando exista cualquier duda."],
    ["Cuándo se decide", "Después de la Fase 1 y antes de avanzar a la Fase 2."],
    ["Qué se registra", "Modelo determinado y fundamento de la determinación."],
    ["Cuándo se revisa", "Si cambia la relación real de trabajo."],
    ["Escalamiento", "Cualquier caso ambiguo se consulta con un profesional de recursos humanos o legal licenciado."],
], [1.6 * inch, 4.9 * inch], fs=8.5)
BOX("Aviso", [
    "Este capítulo no constituye asesoría legal. Los requisitos de seguro, licencias e impuestos varían por "
    "jurisdicción y tipo de servicio. Ante cualquier duda de clasificación o cumplimiento, Ecobay debe consultar "
    "con un profesional licenciado."])

# ---------- CAP 87 ----------
CAP("87", "Entrevista de valores (Fase 2)")
P("87.1 Método", 'h1')
TAG("R")
BOX(None, [
    "<b>No se pregunta «¿eres confiable?» o «¿eres detallista?».</b> Cualquiera responde que sí. En su lugar se "
    "presenta una situación real y se observa cómo respondería el candidato."])
P("Cada valor incluye dos escenarios. Se elige uno o más según la duración de la entrevista: no es necesario usar "
  "todos. Lo que se evalúa no es la respuesta perfecta, sino el razonamiento y la reacción ante la situación.")

P("87.2 Integridad", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Encuentra dinero en efectivo o un objeto de valor mientras limpia la casa de un cliente. ¿Qué hace?", "Reporta de inmediato, no toca ni mueve el objeto más de lo necesario, es transparente con el cliente y el supervisor.", "Duda, minimiza el hallazgo o no menciona que lo vio."],
    ["Se da cuenta de que le pagaron por horas que en realidad no trabajó. ¿Qué haría?", "Reporta el error proactivamente sin que se lo pidan.", "Justifica quedarse con el pago o dice que no es su problema."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.3 Confiabilidad", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Va manejando hacia la casa de un cliente y se le poncha una llanta; puede llegar muy tarde. ¿Qué haría?", "Avisa de inmediato, busca solución, mantiene informado al cliente y a la empresa hasta resolver.", "Espera hasta la hora de llegada para avisar, o no comunica."],
    ["Se despierta muy cansado la mañana de un trabajo programado. ¿Qué hace?", "Evalúa honestamente su capacidad y comunica con tiempo si no puede asistir.", "Falta sin avisar o avisa a último minuto sin alternativa."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.4 Comunicación", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Un cliente cambia las instrucciones de limpieza de forma inesperada, justo cuando usted llega. ¿Qué haría?", "Confirma el cambio, pregunta lo necesario, comunica el impacto en tiempo y alcance.", "Actúa sin confirmar, o no menciona el cambio a la empresa después."],
    ["Se da cuenta de que no podrá asistir a una cita recurrente esta semana. ¿Qué haría?", "Avisa con la mayor anticipación posible y propone una solución.", "Avisa tarde o deja que el cliente lo descubra al no llegar nadie."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.5 Responsabilidad", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Daña accidentalmente un objeto mientras limpia. ¿Qué haría?", "Lo reporta de inmediato, asume responsabilidad, colabora en la solución.", "Lo esconde, espera a que lo descubran, o culpa a otro factor."],
    ["Un cliente dice que algo no se limpió bien, pero usted cree que lo hizo correctamente. ¿Cómo responde?", "Escucha sin ponerse a la defensiva, verifica, corrige si aplica sin dramatizar.", "Se pone defensivo, discute con el cliente, o ignora el feedback."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.6 Atención al detalle", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Termina un trabajo con tiempo extra disponible. ¿Qué hace?", "Revisa detalles adicionales, reexamina áreas de alto contacto, no mata el tiempo.", "Se va antes de tiempo o no aprovecha el tiempo extra."],
    ["Nota un área que no estaba en las instrucciones pero que claramente necesita atención. ¿Qué haría?", "Lo menciona al cliente o supervisor antes de decidir por su cuenta.", "Lo ignora o decide unilateralmente sin comunicarlo."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.7 Servicio al cliente", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Un cliente está insatisfecho aunque usted cree que el trabajo se hizo bien. ¿Cómo lo maneja?", "Escucha con calma, valida la preocupación, busca resolución sin ponerse a la defensiva.", "Discute con el cliente o minimiza su queja."],
    ["Un cliente pide algo fuera del alcance original del trabajo. ¿Qué haría?", "Comunica amablemente los límites del alcance y escala la solicitud a la empresa.", "Acepta sin consultar, lo que afecta precio y alcance, o rechaza de forma brusca."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.8 Trabajo en equipo", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Un compañero se está atrasando en un trabajo compartido. ¿Qué haría?", "Ofrece ayuda de forma proactiva y comunica si el retraso afecta el cronograma.", "Ignora la situación o se queja del compañero en vez de resolver."],
    ["No está de acuerdo con un compañero sobre cómo abordar una tarea. ¿Cómo lo maneja?", "Discute la diferencia con respeto, busca acuerdo o escala si es necesario.", "Impone su opinión, genera conflicto, o cede sin comunicar su preocupación real."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.9 Flexibilidad y adaptabilidad", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Su horario cambia inesperadamente, o lo asignan a un tipo de propiedad distinto al habitual. ¿Cómo responde?", "Se adapta con buena actitud, pide aclaración si necesita más contexto.", "Se resiste al cambio o expresa frustración de forma poco profesional."],
    ["El equipo que normalmente usa deja de funcionar a mitad del trabajo. ¿Qué haría?", "Busca una alternativa razonable y comunica el problema.", "Se detiene sin buscar solución ni avisar."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.10 Resolución de problemas", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Llega a un trabajo y falta el equipo o producto que necesita. ¿Qué haría?", "Evalúa alternativas viables, comunica la situación, no se detiene sin intentarlo.", "Se paraliza o abandona la tarea sin buscar solución ni avisar."],
    ["Encuentra una condición en la propiedad que no se cubrió durante el entrenamiento. ¿Cómo lo maneja?", "Usa criterio razonable y consulta cuando la situación lo amerita.", "Actúa sin criterio o evita la tarea por completo sin comunicarlo."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.11 Profesionalismo", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Un cliente se comporta de forma poco profesional con usted. ¿Cómo respondería?", "Mantiene la calma y la conducta profesional, y reporta la situación a la empresa.", "Responde de forma agresiva o poco profesional."],
    ["Le piden seguir un procedimiento con el que personalmente no está de acuerdo. ¿Qué haría?", "Sigue el procedimiento y expresa su opinión por el canal adecuado.", "Ignora el procedimiento o lo cuestiona frente al cliente."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.12 Seguridad", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Nota que un compañero está usando productos químicos incorrectamente. ¿Qué haría?", "Interviene o reporta de inmediato, sin ignorar el riesgo.", "No dice nada por evitar el conflicto."],
    ["Le piden realizar una tarea que usted cree que no se puede hacer de forma segura. ¿Cómo responde?", "Comunica la preocupación con claridad antes de proceder.", "Lo hace de todas formas sin cuestionar, o se niega sin explicar por qué."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.13 Confidencialidad y confianza", 'h1')
TBL([
    ["Escenario", "Qué buscamos", "Red flags"],
    ["Se encuentra con documentos personales o información privada mientras limpia. ¿Qué haría?", "No los revisa ni los comenta con nadie fuera del trabajo.", "Los menciona a otros o muestra curiosidad indebida."],
    ["Alguien no autorizado —un familiar del cliente, un vecino— le hace preguntas sobre el cliente. ¿Cómo responde?", "Mantiene límites profesionales sin compartir información.", "Comparte detalles sin evaluar si es apropiado."],
], [2.4 * inch, 2.3 * inch, 1.8 * inch], fs=8)

P("87.14 Guía rápida para el entrevistador", 'h1')
TAG("R")
B([
    "Abrir explicando el proceso: dos fases, preguntas de situación real, sin respuestas perfectas memorizadas.",
    "Hacer preguntas abiertas y dejar que el candidato piense; no completar la respuesta por él.",
    "No sugerir la respuesta correcta con el tono ni con el lenguaje corporal.",
    "Tomar notas concretas de lo que dice el candidato, no solo la impresión general.",
    "Distinguir entre falta de experiencia, que se puede entrenar, y mala compatibilidad de valores, que es mucho más difícil de cambiar.",
    "Identificar red flags con base en lo que el candidato dice, no en suposiciones.",
    "Usar preguntas de seguimiento cuando la respuesta sea vaga o incompleta.",
    "Escalar a revisión adicional si hay señales mixtas, antes de decidir.",
])
P("<b>Preguntas de seguimiento útiles:</b> «Can you tell me more about that?» · «What happened next?» · «What "
  "would you do first?» · «How would you communicate that to the client?» · «How would you communicate that to "
  "your supervisor?» · «What would you do differently next time?» · «Why did you choose that approach?»")

# ---------- CAP 88 ----------
CAP("88", "Puntuación, decisión y contratación")
P("88.1 Escala de puntuación", 'h1')
TAG("R")
TBL([
    ["Puntaje", "Nivel", "Descripción"],
    ["5", "Excelente", "Respuesta clara, específica; demuestra el valor de forma natural."],
    ["4", "Fuerte", "Buena respuesta alineada con el valor, con algún detalle menor faltante."],
    ["3", "Aceptable", "Respuesta razonable pero genérica o incompleta."],
    ["2", "Débil", "Respuesta que genera dudas sobre el valor evaluado."],
    ["1", "Preocupación mayor", "Respuesta que contradice directamente el valor evaluado."],
], [0.8 * inch, 1.5 * inch, 4.2 * inch], fs=8.5)

P("88.2 Resultado final", 'h1')
TBL([
    ["Componente", "Resultado posible"],
    ["Fase 1", "PASS · CONDITIONAL · FAIL"],
    ["Fase 2", "Promedio general de los valores evaluados"],
    ["Decisión final", "Strong Hire · Hire · Conditional o revisión adicional · Do Not Move Forward"],
], [1.6 * inch, 4.9 * inch], fs=8.5)
BOX(None, [
    "<b>Pasar la Fase 1 no garantiza la contratación.</b> Es solo el filtro básico antes de evaluar compatibilidad "
    "de valores."])

P("88.3 Decisión de contratación", 'h1')
TBL([
    ["Resultado", "Significado", "Acción"],
    ["Se contrata", "Cumple requisitos y es seleccionado.", "Comunicación y onboarding."],
    ["Se mantiene como candidato", "Tiene potencial, pero no hay necesidad inmediata o falta información.", "Se registra en el pipeline para futura vacante."],
    ["No se selecciona", "No cumple requisitos o no resulta adecuado.", "Se cierra con motivo registrado."],
], [1.7 * inch, 2.8 * inch, 2.0 * inch], fs=8.5)
P("La decisión se basa en los criterios establecidos, no en la urgencia de cubrir una vacante. Antes de decidir se "
  "confirma que el candidato cumple los requisitos y que la empresa completó las verificaciones y la documentación "
  "que correspondan según sus requisitos internos y las obligaciones legales aplicables.")
BOX(None, [
    "<b>No se considera contratada a una persona únicamente porque tuvo una buena entrevista.</b>"])

P("88.4 Comunicación e incorporación", 'h1')
CHK([
    "Comunicar que ha sido seleccionado.",
    "Explicar los próximos pasos.",
    "Confirmar la fecha prevista de inicio.",
    "Indicar la información necesaria antes de comenzar.",
    "Indicar la documentación requerida.",
    "Explicar la información relacionada con su incorporación.",
])
P("Las condiciones finales deben quedar claras <b>antes</b> de que la persona comience a trabajar. Una vez "
  "contratada se crea o actualiza su información en los sistemas internos, con la documentación que la empresa "
  "determine necesaria, mantenida de forma organizada y protegida.")

P("88.5 La contratación no es el final del proceso", 'h1')
TAG("R")
P("La contratación representa el inicio de la relación laboral. Antes de considerarse plenamente integrada, la "
  "persona debe conocer cómo funciona Ecobay y qué espera la empresa, cómo presentarse ante el cliente, cómo "
  "utilizar productos y herramientas, cómo se realizan los distintos tipos de limpieza, cómo trabajar dentro de un "
  "equipo, qué procedimientos de seguridad seguir y qué estándares de calidad cumplir.")
BOX(None, [
    "<b>Ecobay no busca únicamente personas que sepan limpiar. Busca personas que puedan aprender, seguir un "
    "sistema, trabajar en equipo y representar correctamente a la empresa frente al cliente.</b>"])

P("88.6 Indicadores del proceso de selección", 'h1')
TBL([
    ["Indicador", "Definición", "Qué revela"],
    ["Aplicaciones recibidas", "Total por vacante y por fuente.", "Efectividad de la publicación."],
    ["Candidatos calificados", "Aplicaciones que pasan la Fase 1.", "Precisión de los requisitos publicados."],
    ["Tasa de entrevista", "Entrevistas realizadas sobre candidatos calificados.", "Agilidad del proceso."],
    ["Tasa de contratación", "Contrataciones sobre entrevistas.", "Calidad del filtro previo."],
    ["Tiempo hasta la contratación", "Días entre la vacante y la incorporación.", "Capacidad de responder a la demanda."],
    ["Retención tras el onboarding", "Permanencia a los períodos definidos.", "Si el proceso realmente predice el desempeño."],
], [1.7 * inch, 2.5 * inch, 2.3 * inch], fs=8)

# ==================================================================


PARTE("XII-B", "Obligaciones y protección financiera",
      "El calendario de cumplimiento de la entidad y la defensa del dinero de la empresa.",
      ["Capítulo 107. Calendario de obligaciones de la LLC",
       "Capítulo 107-A. Prevención de fraude y protección de pagos"])

# ---------- CAP 107 ----------
CAP("107", "Calendario de obligaciones de la LLC")
P("107.1 Propósito y límite de este capítulo", 'h1')
P("Una LLC tiene obligaciones fiscales y administrativas con frecuencias distintas a lo largo del año. No todas se "
  "presentan ni se pagan al mismo ritmo, y depender de la memoria para recordarlas es exactamente el patrón que "
  "este manual busca eliminar. Este capítulo convierte esas obligaciones en un calendario con responsable.")
BOX("Aviso", [
    "Esta es una guía general de referencia. <b>No constituye asesoría fiscal ni legal.</b> Las obligaciones "
    "exactas dependen del estado, la clasificación fiscal de la LLC, el tipo de negocio, los empleados, los "
    "ingresos y las cuentas tributarias registradas. Antes de presentar o pagar deben verificarse los requisitos "
    "específicos aplicables a Ecobay con un profesional calificado."])

P("107.2 Impuesto federal sobre los ingresos", 'h1')
P("<b>Frecuencia: anual.</b> La LLC debe reportar sus ingresos, gastos, ganancias o pérdidas. La forma de "
  "presentar depende de cómo esté clasificada la entidad: LLC de un solo propietario, LLC de varios propietarios, "
  "LLC que tributa como S-Corporation o LLC que tributa como Corporation. Aunque la declaración principal sea "
  "anual, pueden existir pagos estimados durante el año.")

P("107.3 Pagos de impuestos estimados", 'h1')
P("<b>Frecuencia: generalmente trimestral, cuando corresponda.</b> Si se espera que el negocio o sus propietarios "
  "tengan una cantidad significativa de impuestos por pagar, pueden requerirse pagos anticipados durante el año.")
TBL([
    ["Trimestre", "Mes de pago de referencia"],
    ["Primer trimestre", "Abril"],
    ["Segundo trimestre", "Junio"],
    ["Tercer trimestre", "Septiembre"],
    ["Cuarto trimestre", "Enero del año siguiente"],
], [2.5 * inch, 4.0 * inch], fs=8.5)
P("La cantidad y la necesidad de estos pagos dependen de la situación fiscal de la empresa y de sus propietarios.")

P("107.4 Impuestos estatales", 'h1')
P("<b>Frecuencia: depende del estado.</b> Cada estado tiene sus propias reglas. Una LLC puede estar sujeta a "
  "impuestos estatales sobre ingresos, impuestos específicos para entidades comerciales u otras obligaciones. Al "
  "revisar la situación de la empresa debe confirmarse qué cuentas fiscales estatales tiene registradas y qué "
  "declaraciones debe presentar.")

P("107.5 Sales Tax", 'h1')
P("<b>Frecuencia: depende del estado y de la frecuencia asignada.</b> No todos los productos o servicios están "
  "sujetos a este impuesto. Antes de cualquier decisión debe verificarse:")
CHK([
    "Si el producto o servicio es gravable.",
    "En qué estado se realiza la venta o se presta el servicio.",
    "Si la empresa está registrada para cobrar el impuesto.",
    "Qué frecuencia de presentación le asignó el estado.",
    "Si debe presentar una declaración aunque no haya ventas sujetas a impuesto.",
])
BOX("Punto crítico", [
    "<b>Estar registrado para Sales Tax no significa necesariamente que todos los servicios de la empresa estén "
    "sujetos a este impuesto.</b>"])

P("107.6 Impuestos de nómina", 'h1')
P("<b>Frecuencia: durante todo el año, más reportes periódicos.</b> Si la LLC tiene empleados debe manejar los "
  "impuestos relacionados con nómina, que según corresponda pueden incluir retención federal sobre ingresos, "
  "Social Security, Medicare, impuesto federal de desempleo, retención estatal sobre ingresos e impuesto estatal "
  "de desempleo.")
BOX("Distinción que causa incumplimientos", [
    "<b>La frecuencia de depósito puede ser distinta de la frecuencia de presentación de reportes.</b> Un reporte "
    "puede ser trimestral mientras ciertos depósitos de nómina son mensuales o más frecuentes. Confundir ambas "
    "frecuencias es una de las causas más comunes de multas evitables."])

P("107.7 Compensación laboral y desempleo", 'h1')
P("<b>Frecuencia: durante el año.</b> Si la empresa tiene empleados debe verificar los requisitos de compensación "
  "laboral, seguro de desempleo, registro de empleados y reportes estatales de nómina. Los requisitos varían según "
  "el estado y las características de la empresa.")

P("107.8 Annual Report de la LLC", 'h1')
P("<b>Frecuencia: anual.</b> El Annual Report no es una declaración de impuestos: es un reporte administrativo que "
  "se presenta ante el estado para mantener la LLC activa y en buen estado. Cada estado establece su propia fecha "
  "límite, tarifa, método de presentación e información requerida.")
BOX("Consecuencia de omitirlo", [
    "Es la obligación más fácil de olvidar y una de las más costosas: una entidad que pierde su buen estado puede "
    "quedar impedida de operar, de contratar o de calificar como proveedor ante clientes comerciales que verifican "
    "el registro."])

P("107.9 Resumen por frecuencia", 'h1')
TBL([
    ["Anual", "Trimestral", "Durante todo el año"],
    ["Declaración principal de impuestos", "Pagos de impuestos estimados, cuando correspondan", "Depósitos de impuestos de nómina"],
    ["Annual Report de la LLC", "Algunos reportes de Sales Tax", "Registro y manejo de empleados"],
    ["Otros reportes anuales que apliquen", "Algunos reportes de nómina", "Compensación laboral"],
    ["", "Otros impuestos estatales, según el estado", "Desempleo"],
    ["", "", "Sales Tax, cuando corresponda"],
], [2.1 * inch, 2.2 * inch, 2.2 * inch], fs=8)

P("107.10 Conversión en rutina de la empresa", 'h1')
TAG("P")
TBL([
    ["Elemento del calendario", "Responsable", "Frecuencia", "Evidencia"],
    ["Declaración principal", "Owner con asesor fiscal", "Anual", "Acuse de presentación"],
    ["Pagos estimados", "Owner con asesor fiscal", "Trimestral", "Comprobante de pago"],
    ["Obligaciones estatales", "Owner con asesor fiscal", "Según estado", "Acuse por cuenta registrada"],
    ["Sales Tax", "Administración con asesor fiscal", "Según frecuencia asignada", "Declaración presentada"],
    ["Depósitos de nómina", "Administración", "Según calendario asignado", "Comprobante de depósito"],
    ["Reportes de nómina", "Administración", "Periódica", "Acuse de reporte"],
    ["Compensación laboral y desempleo", "Owner", "Según estado", "Póliza y reportes vigentes"],
    ["Annual Report", "Owner", "Anual", "Confirmación estatal"],
], [1.9 * inch, 1.7 * inch, 1.5 * inch, 1.4 * inch], fs=8)

P("107.11 Nota de escalabilidad", 'h1')
P("Cuando exista una segunda ubicación, este calendario deja de ser único: cada entidad y cada estado tendrá su "
  "propio conjunto de cuentas, frecuencias y fechas límite. La estructura de este capítulo —obligación, "
  "responsable, frecuencia, evidencia— es la que permite replicarlo por unidad sin rehacerlo desde cero.")

# ---------- CAP 107-A ----------
CAP("107-A", "Prevención de fraude y protección de pagos")
P("107-A.1 Por qué este capítulo pertenece al manual", 'h1')
P("Una empresa de servicios que cobra por aplicaciones de pago digital, que responde rápido a clientes nuevos y "
  "que quiere ganar contratos es exactamente el perfil que los defraudadores buscan. El riesgo no es teórico: es "
  "una pérdida directa de efectivo que ninguna cláusula contractual recupera.")
TBL([
    ["Factor de exposición", "Por qué aumenta el riesgo"],
    ["Se quiere el contrato", "Cuando alguien ofrece trabajo, se baja la guardia."],
    ["Pagos digitales irrecuperables", "Los cobros por aplicaciones de pago funcionan como efectivo: no se pueden revertir."],
    ["Operación en un segundo idioma", "Los errores de redacción de un correo fraudulento pasan desapercibidos."],
    ["Ritmo de trabajo alto", "Se responde rápido, sin verificar."],
], [2.2 * inch, 4.3 * inch], fs=8.5)
BOX("Contexto", [
    "Los esquemas actuales usan documentos profesionales, plataformas de firma electrónica y contenido generado "
    "con inteligencia artificial. <b>Ya no son correos con faltas de ortografía obvias.</b> Un documento que se ve "
    "impecable no prueba absolutamente nada."])

P("107-A.2 Esquema 1 — Pago falso por aplicación de pago", 'h1')
FLOW(["Cliente nuevo quiere pagar por adelantado", "Insiste en app de pago", "Correo de «pago en espera»", "Piden depósito o llamada", "Robo"])
P("El supuesto cliente insiste en pagar por una aplicación de pago. Llega un correo que parece de la plataforma "
  "indicando que el pago está retenido por restricciones del tipo de cuenta, y ofrece dos salidas: llamar a un "
  "número de soporte o pedirle al cliente un depósito adicional para «activar la cuenta de negocio», con promesa "
  "de recibir todo junto después. Si se llama, un supuesto agente dice que la única forma de liberar el dinero es "
  "conectar manualmente la cuenta bancaria, y pide el número de cuenta.")
TBL([
    ["Señal de alerta", "Por qué delata el fraude"],
    ["Remitente que no es el dominio oficial", "Las plataformas reales solo envían desde su propio dominio, nunca desde un correo gratuito."],
    ["«Pago en espera» que requiere una acción de cobro", "Las plataformas no retienen pagos así ni piden depósitos para liberarlos."],
    ["Número de teléfono dentro del correo", "Las empresas reales dirigen a su aplicación o sitio oficial, no a un celular."],
    ["Urgencia y presión para «completar el proceso»", "La prisa impide verificar."],
], [2.5 * inch, 4.0 * inch], fs=8.5)
BOX("Regla", [
    "<b>Si un pago necesita que usted pague, llame o entregue datos bancarios para liberarse, es fraude.</b> "
    "El saldo se verifica abriendo la aplicación oficial directamente, nunca desde un enlace del correo."])

P("107-A.3 Esquema 2 — Contrato de proveedor falso", 'h1')
FLOW(["Contacto de «empresa grande»", "Contrato profesional", "Promesa de trabajo garantizado", "Cuotas de activación", "Ciclo sin fin"])
P("Un supuesto agente de una empresa conocida ofrece contratar a la empresa como proveedor de limpieza. Envía un "
  "contrato de aspecto profesional, con logo, sello y firma electrónica. El contrato promete trabajo garantizado, "
  "propiedades diarias y precios fijos. Para «activar» el contrato piden una cuota de inicio, un pago para "
  "«activar códigos» y un «bono de cumplimiento». Después siguen pidiendo más —seguros, uniformes, «verificación "
  "de proveedor»— hasta que se deja de pagar y desaparecen.")
TBL([
    ["Señal de alerta", "Por qué delata el fraude"],
    ["Cobran por darte trabajo", "<b>Un cliente real nunca cobra por otorgar trabajo.</b>"],
    ["Piden pago por aplicación de pago personal", "Las corporaciones pagan por transferencia formal, con documentación fiscal y certificado de seguro de por medio."],
    ["Cláusulas financieras extrañas y penalidades extremas", "Intereses altos sobre «bonos» y sanciones desproporcionadas por pago tardío."],
    ["Dominio de correo falso o parecido al oficial", "Correo gratuito o dominio que imita al de la empresa real."],
], [2.5 * inch, 4.0 * inch], fs=8.5)
P("<b>Cómo verificar:</b> buscar el número oficial de la empresa por cuenta propia, no el del correo; llamar y "
  "preguntar si ese agente existe; solicitar la documentación fiscal de <i>ellos</i>; y buscar el nombre de la "
  "empresa junto con la palabra «vendor scam».")
BOX("Conexión con el Capítulo 23-B", [
    "Este esquema imita el proceso legítimo de registro de proveedores descrito en el desarrollo comercial "
    "outbound. La diferencia es inequívoca: en un proceso real <b>la empresa contratante nunca cobra por "
    "incorporarte</b>. Registrarse en un portal de proveedores es gratuito; pagar por un código de activación no "
    "existe."])

P("107-A.4 Esquema 3 — Cuenta conocida comprometida", 'h1')
P("Un mensaje llega desde el perfil de una persona conocida ofreciendo una venta urgente y solicitando pago "
  "inmediato por aplicación de pago, frecuentemente a un número de otro estado. La cuenta fue robada o "
  "comprometida y quien escribe no es la persona del perfil.")
TBL([
    ["Lección", "Aplicación"],
    ["Que el mensaje venga de un perfil conocido no significa que sea esa persona.", "Las cuentas se comprometen y los teléfonos se roban."],
    ["Un número desconocido de otro estado es una alerta grave.", "No se envía dinero mientras esa incongruencia no se resuelva."],
    ["La verificación correcta es una llamada telefónica directa.", "No por el mismo canal del mensaje ni al mismo número."],
    ["La duda es información.", "Si algo se siente raro, se detiene <b>antes</b> de enviar, no después."],
], [3.0 * inch, 3.5 * inch], fs=8.5)

P("107-A.5 Esquema 4 — Cheque por adelantado", 'h1')
FLOW(["Cheque enviado", "Banco muestra fondos", "Se envía la diferencia", "El cheque rebota"])
P("Un supuesto cliente contacta por correo, casi siempre para un trabajo grande, y sin negociar mucho envía un "
  "cheque por más del monto acordado con una excusa. Pide depositar el cheque y devolver la diferencia por "
  "aplicación de pago. El banco muestra los fondos como disponibles en uno o dos días, pero el cheque puede tardar "
  "una o dos semanas en rebotar. Cuando rebota, el banco descuenta el monto completo y el dinero enviado ya se "
  "fue.")
BOX("Regla", [
    "<b>Nunca se acepta un cheque por más del monto acordado y nunca se devuelven diferencias.</b> Fondos "
    "disponibles no significa cheque cobrado. Si un cliente nuevo envía dinero de más, es fraude."])

P("107-A.6 Esquema 5 — Cobros falsos por mensaje", 'h1')
P("Llega un mensaje de texto sobre una supuesta deuda pendiente —peajes, multas, servicios— con un enlace o un "
  "número de teléfono. El enlace lleva a una página falsa de pago que roba los datos de la tarjeta, o el supuesto "
  "agente los obtiene por teléfono.")
TBL([
    ["Señal de alerta", "Detalle"],
    ["Las agencias de cobro de peajes no cobran por mensaje de texto", "Las notificaciones reales llegan por correo postal a la dirección del registro vehicular."],
    ["Usan nombres de agencias de cobranza reales", "Verificar la deuda, no el nombre: un cobrador real está obligado a enviar una carta de validación por correo."],
    ["Responder «STOP» no es seguro", "Confirma que el número está activo y aumenta los intentos."],
], [2.6 * inch, 3.9 * inch], fs=8.5)
P("<b>Qué hacer:</b> no dar clic, no llamar, no responder. Borrar y bloquear. Ante la duda, ingresar directamente "
  "al sitio oficial de la cuenta.")

P("107-A.7 Otros vectores frecuentes", 'h1')
TBL([
    ["Vector", "Realidad"],
    ["Llamadas de supuesto soporte del perfil de negocio en buscadores", "La plataforma no llama ni cobra por mantener el perfil activo."],
    ["Correos de «tu página será eliminada, verifica aquí»", "Buscan robar la página del negocio y sus anuncios. No se da clic en ningún enlace."],
    ["Facturas falsas por productos o renovaciones nunca ordenadas", "No se abren archivos adjuntos de remitentes desconocidos."],
], [2.6 * inch, 3.9 * inch], fs=8.5)

P("107-A.8 Las nueve reglas anti-fraude de Ecobay", 'h1')
TAG("R")
NUM([
    "Ningún cliente comercial legítimo cobra por darte trabajo, activaciones ni códigos.",
    "Se verifica el remitente real del correo: dominio oficial, no correo gratuito ni dominio parecido.",
    "Las aplicaciones de pago funcionan como efectivo: solo con personas o empresas verificadas.",
    "Un cheque por adelantado por más del monto acordado es fraude automático.",
    "Nunca se entrega número de cuenta, contraseñas ni códigos de verificación.",
    "Se verifica siempre por otro canal: llamando al número oficial que uno mismo buscó.",
    "La urgencia es el arma del defraudador: «hoy», «ahorita», «se pierde la oportunidad» obliga a detenerse.",
    "Firmas electrónicas, logos y sellos no prueban nada: se verifica la empresa, no el documento.",
    "Si algo se siente mal, se detiene antes de enviar dinero.",
])

P("107-A.9 Protocolo de respuesta ante un fraude consumado", 'h1')
TAG("R")
P("Las primeras veinticuatro horas determinan cuánto puede recuperarse. El protocolo se ejecuta en orden y sin "
  "esperar autorización.")
NUM([
    "Llamar al banco de inmediato y pedir detener o revertir la transferencia; cada hora cuenta.",
    "Reportarlo dentro de la aplicación de pago correspondiente si el pago se realizó por esa vía.",
    "Presentar el reporte ante la autoridad federal de protección al consumidor.",
    "Hacer un reporte policial local, que será requerido por el banco y por el seguro.",
    "Cambiar todas las contraseñas y activar verificación en dos pasos en correo, banca y redes sociales.",
    "Si se entregó el número de cuenta, pedir al banco cerrar o congelar la cuenta y abrir una nueva.",
])
BOX("Regla de cultura", [
    "Quien detecta o sufre un intento de fraude debe poder reportarlo <b>sin temor a consecuencias</b>. Una "
    "empresa donde el error se castiga es una empresa donde el fraude se oculta hasta que es irreversible."])

P("107-A.10 Controles preventivos permanentes", 'h1')
TAG("P")
TBL([
    ["Control", "Responsable", "Frecuencia"],
    ["Verificación de cliente nuevo antes de aceptar pago adelantado inusual", "Administración", "Por caso"],
    ["Doble verificación por canal independiente ante cualquier solicitud de pago o de datos bancarios", "Administración", "Por caso"],
    ["Regla de aprobación del Owner para cualquier pago saliente hacia un cliente o supuesto contratante", "Owner", "Por caso"],
    ["Capacitación anti-fraude en el onboarding administrativo", "Owner", "Al incorporarse"],
    ["Revisión de conciliación bancaria contra servicios ejecutados", "Administración", "Semanal"],
    ["Verificación de que ningún método de pago nuevo se activó sin autorización", "Owner", "Mensual"],
], [3.6 * inch, 1.4 * inch, 1.5 * inch], fs=8.5)

# ---------- CIERRE ----------
