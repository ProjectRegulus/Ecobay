# -*- coding: utf-8 -*-
from build_manual_m import *  # noqa

PARTE("ANEXOS", "Anexos",
      "Estado del sistema, control de versiones y acuse.",
      ["Anexo A. Mapa del sistema y desarrollo futuro",
       "Anexo B. Control de versiones",
       "Anexo C. Acuse de recibo y confidencialidad"])

# ---------- ANEXO A ----------
CAP("A", "Mapa del sistema y desarrollo futuro")
P("Este documento maestro contiene las partes desarrolladas hasta la versión 3.0. La arquitectura completa "
  "proyectada del sistema comprende diecisiete partes; a continuación se indica el estado de cada una.")
TBL([
    ["Parte", "Contenido", "Estado en v3.0"],
    ["I", "Identidad, filosofía y modelo operativo", "Desarrollada"],
    ["II", "Administración y sistema empresarial", "Desarrollada"],
    ["III", "Leads, marketing y ventas", "Desarrollada"],
    ["III-B", "Ampliación comercial: inbound, outbound y contratos", "Desarrollada"],
    ["IV", "Customer experience", "Programada"],
    ["V", "Scheduling y dispatch", "Programada"],
    ["VI", "Operaciones de limpieza", "Base vigente en el Manual de Limpieza por Áreas"],
    ["VII", "SOP por tipo de servicio", "Programada"],
    ["VIII", "SOP por área de la propiedad", "Cubierta por el Manual de Limpieza por Áreas"],
    ["IX", "Equipos, productos y vehículos", "Base desarrollada; ampliación programada"],
    ["X", "Tecnología y sistemas", "Desarrollada"],
    ["XI", "Recursos humanos: selección de personal", "Desarrollada"],
    ["XI (cont.)", "Onboarding, capacitación, evaluación y salida", "Programada"],
    ["XII", "Payroll y control de horas", "Base desarrollada en la v2.0"],
    ["XII-B", "Obligaciones de la entidad y protección financiera", "Desarrollada"],
    ["XIII", "Calidad y auditoría", "Programada"],
    ["XIV", "Seguridad", "Base vigente en el Manual de Limpieza por Áreas"],
    ["XV", "KPIs y management", "Indicadores definidos por capítulo; consolidación programada"],
    ["XVI", "Delegación y escalabilidad", "Matrices desarrolladas en el Capítulo 7; ampliación programada"],
    ["XVII", "Franchise readiness", "Principios incorporados por capítulo; parte propia programada"],
], [0.9 * inch, 3.2 * inch, 2.4 * inch], fs=8)
BOX("Criterio de crecimiento", [
    "El manual no se completa rellenando páginas. Cada sección nueva nace de una respuesta concreta de la "
    "administración sobre un procedimiento que ya existe pero que nadie había escrito. Esa es la materia prima del "
    "documento."])

# ---------- ANEXO C ----------
CAP("B", "Control de versiones")
TBL([
    ["Versión", "Fecha", "Descripción del cambio", "Aprobado por"],
    ["1.0", "____/____/______", "Versión inicial: fundamentos, dependencia operativa, prioridades, leads, finanzas, asignación de personal y preparación de equipo.", "__________"],
    ["2.0", "____/____/______", "Reestructuración por capítulos. Se agregan Jobber, Google LSA, cotización, contratación, gestión del tiempo y payroll.", "__________"],
    ["3.0", "____/____/______", "Reestructuración como sistema operativo en partes. Se agregan Partes I, II, III, III-B, X, XI y XII-B: identidad y modelo de negocio, matrices de delegación y escalamiento, rutinas administrativas, pipeline comercial completo, arquitectura tecnológica y CleanCore, social media, venta inbound y outbound, contratos, selección de personal, obligaciones de la LLC y prevención de fraude.", "__________"],
    ["", "____/____/______", "", "__________"],
    ["", "____/____/______", "", "__________"],
], [0.65 * inch, 1.15 * inch, 3.5 * inch, 1.2 * inch], fs=8)
BOX("Regla de cambio", [
    "<b>Ninguna práctica se convierte en política de Ecobay Cleaning LLC sin quedar documentada en una versión "
    "aprobada y registrada.</b> Si la práctica real difiere del manual, una de las dos está mal: la revisión "
    "mensual decide cuál y corrige la que corresponda."])

# ---------- ANEXO D ----------
story.append(PageBreak())
SP(26)
story.append(Image(LOGO, width=1.7 * inch, height=1.7 * inch * 195 / 482, hAlign='CENTER'))
SP(24)
P("Anexo C. Acuse de recibo y confidencialidad", 'h1')
P("Yo, ______________________________________________________, colaborador o colaboradora de "
  "<b>Ecobay Cleaning LLC</b>, por medio de la presente expreso estar enterado (a) del contenido de este "
  "Manual Corporativo y Operativo, y me comprometo a no difundir este material de ninguna manera a terceras "
  "personas (entiéndase familiares, compañías u otros).")
SP(12)
P("Asimismo, declaro comprender que este documento es propiedad de Ecobay Cleaning LLC, que su contenido puede "
  "actualizarse mediante nuevas versiones controladas, y que los procedimientos aquí descritos deben ejecutarse "
  "conforme a lo documentado.")
SP(44)
story.append(HR(SAGE, 0.8))
SP(6)
P("Nombre completo", 'body_c')
SP(38)
story.append(HR(SAGE, 0.8))
SP(6)
P("Firma del colaborador y fecha de revisión", 'body_c')
SP(38)
story.append(HR(SAGE, 0.8))
SP(6)
P("Por Ecobay Cleaning LLC", 'body_c')
