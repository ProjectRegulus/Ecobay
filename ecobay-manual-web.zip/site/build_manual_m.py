# -*- coding: utf-8 -*-
"""Shim: reimplementa la API de build_manual pero emite HTML en lugar de PDF."""
import html as _h

inch = 1.0
LOGO = "logo.png"
OUT = "index.html"

story = []          # fragmentos HTML
NAV = []            # (kind, id, label) para el índice lateral
_ids = set()


class _Style(str):
    pass


S = {k: _Style(k) for k in [
    'body', 'body_c', 'bullet', 'num', 'part', 'part_sub', 'h1', 'h2', 'h3',
    'quote', 'note', 'flow', 'toc', 'toc_p', 'cover_t', 'cover_s', 'cover_x']}


def _esc(t):
    return t


def _slug(t, prefix=""):
    import re
    base = re.sub(r'[^a-z0-9]+', '-', (prefix + " " + t).lower()).strip('-')
    s, n = base, 2
    while s in _ids:
        s, n = f"{base}-{n}", n + 1
    _ids.add(s)
    return s


# ---- primitivas que el contenido invoca dentro de story.append(...) ----
def Paragraph(text, style=None, bulletText=None):
    cls = str(style) if style else 'body'
    if cls == 'quote':
        return f'<blockquote>{text}</blockquote>'
    if cls in ('toc', 'toc_p'):
        return ''      # los índices internos se sustituyen por la navegación del sitio
    if cls.startswith('cover'):
        return ''
    if cls == 'note':
        return f'<p class="note">{text}</p>'
    if cls == 'body_c':
        return f'<p class="center">{text}</p>'
    if cls in ('h1', 'h2', 'h3'):
        return f'<h4>{text}</h4>'
    return f'<p>{text}</p>'


def PageBreak():
    return ''


def Spacer(*a, **k):
    return ''


def Image(*a, **k):
    return ''


def HR(*a, **k):
    return '<hr>'


def NextPageTemplate(*a, **k):
    return ''


def CondPageBreak(*a, **k):
    return ''


# ---- helpers de alto nivel ----
def P(t, s='body'):
    if s == 'h1':
        i = _slug(t, "s")
        NAV.append(('sec', i, t))
        story.append(f'<h3 id="{i}">{t}</h3>')
    elif s == 'h2':
        story.append(f'<h4>{t}</h4>')
    elif s == 'h3':
        story.append(f'<h5>{t}</h5>')
    elif s == 'note':
        story.append(f'<p class="note">{t}</p>')
    elif s == 'body_c':
        story.append(f'<p class="center">{t}</p>')
    else:
        story.append(f'<p>{t}</p>')


def B(items, style='bullet', bullet='•'):
    story.append('<ul>' + ''.join(f'<li>{i}</li>' for i in items) + '</ul>')


def NUM(items):
    story.append('<ol>' + ''.join(f'<li>{i}</li>' for i in items) + '</ol>')


def CHK(items, title=None):
    if title:
        story.append(f'<h5>{title}</h5>')
    li = ''.join(
        f'<li><label><input type="checkbox" class="ck"> <span>{i}</span></label></li>'
        for i in items)
    story.append(f'<ul class="checklist">{li}</ul>')


def SP(h=8):
    pass


def CPB(h=2.2):
    pass


def TBL(data, widths=None, header=True, align_left_first=True, fs=9):
    rows = list(data)
    out = ['<div class="tw"><table>']
    if header and rows:
        out.append('<thead><tr>' + ''.join(f'<th>{c}</th>' for c in rows[0]) + '</tr></thead>')
        rows = rows[1:]
    out.append('<tbody>')
    for r in rows:
        out.append('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>')
    out.append('</tbody></table></div>')
    story.append(''.join(out))


def BOX(title, lines, color=None, border=None):
    t = f'<div class="box-t">{title}</div>' if title else ''
    body = ''.join(f'<p>{l}</p>' for l in lines)
    story.append(f'<div class="box">{t}{body}</div>')


def FLOW(steps):
    chips = '<span class="arw">→</span>'.join(f'<span class="step">{s}</span>' for s in steps)
    story.append(f'<div class="flow">{chips}</div>')


TAGS = {
    "C": ("PROCEDIMIENTO CONFIRMADO", "c"),
    "R": ("REGLA OPERATIVA CONFIRMADA", "r"),
    "P": ("ESTÁNDAR PROPUESTO", "p"),
    "V": ("NOTA", "v"),
}


def TAG(kind, extra=""):
    label, cls = TAGS[kind]
    txt = label + (" — " + extra if extra else "")
    story.append(f'<div class="tag tag-{cls}" data-tag="{cls}">{txt}</div>')


def SOP(name, rows):
    story.append(f'<h4>Ficha SOP — {name}</h4>')
    TBL([["Campo", "Contenido"]] + rows)


def PARTE(num, title, subtitle, chapters=None):
    i = _slug(title, "parte")
    NAV.append(('part', i, f"Parte {num} — {title}"))
    story.append(
        f'<section class="part" id="{i}"><div class="part-k">PARTE {num}</div>'
        f'<h1>{title}</h1><p class="part-s">{subtitle}</p></section>')


def CAP(num, title):
    i = _slug(title, f"cap-{num}")
    NAV.append(('cap', i, f"{num}. {title}"))
    story.append(
        f'<section class="chap" id="{i}"><div class="chap-k">CAPÍTULO {num}</div>'
        f'<h2>{title}</h2></section>')


# ---- constantes de color usadas por el contenido (ignoradas en HTML) ----
GREEN = GREEN_D = SAGE = TAUPE = LIGHT = GREY = "#000"
FONT = FONT_B = FONT_I = FONT_M = FONT_SYM = ""


class _C:
    def HexColor(self, v): return v
    white = "#fff"


colors = _C()


class ParagraphStyle(str):
    def __init__(self, *a, **k): pass


def Table(*a, **k): return ''
def TableStyle(*a, **k): return ''
def Frame(*a, **k): return ''
def PageTemplate(*a, **k): return ''
def BaseDocTemplate(*a, **k): return ''
def KeepTogether(*a, **k): return ''
LETTER = (1, 1)
