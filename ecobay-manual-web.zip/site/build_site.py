# -*- coding: utf-8 -*-
import master_front, master_body, master_annex  # noqa  (llenan story/NAV)
from build_manual_m import story, NAV
import json, base64, os

body = "\n".join(x for x in story if isinstance(x, str) and x.strip())

# ---- navegación jerárquica ----
nav_html, cur = [], None
for kind, i, label in NAV:
    if kind == 'part':
        if cur: nav_html.append('</div></div>')
        nav_html.append(
            f'<div class="nv-part"><a class="nv-p" href="#{i}">{label}</a><div class="nv-kids">')
        cur = i
    elif kind == 'cap':
        nav_html.append(f'<a class="nv-c" href="#{i}">{label}</a>')
if cur: nav_html.append('</div></div>')
nav_html = "".join(nav_html)

logo_b64 = base64.b64encode(open('logo.png', 'rb').read()).decode()

HTML = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manual Corporativo y Operativo — Ecobay Cleaning LLC</title>
<meta name="description" content="The Ecobay Operating System: procesos, estandares y controles de Ecobay Cleaning LLC.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{{
  --green:#4A5B39; --green-d:#2F3B24; --sage:#8FA36A; --taupe:#A08D74;
  --bg:#ffffff; --panel:#F5F7F1; --line:#E2E6DC; --ink:#333; --muted:#6b6b6b;
  --w:880px;
}}
[data-theme="dark"]{{
  --bg:#14170F; --panel:#1D2117; --line:#2E3426; --ink:#E6E9E0; --muted:#9aa393;
  --green:#9CB57A; --green-d:#C3D3A8; --taupe:#B9A88F;
}}
*{{box-sizing:border-box}}
html{{scroll-behavior:smooth; scroll-padding-top:78px}}
body{{margin:0;font-family:Poppins,system-ui,sans-serif;background:var(--bg);color:var(--ink);
  font-size:15px;line-height:1.62;-webkit-text-size-adjust:100%}}

/* ---------- barra superior ---------- */
header{{position:fixed;inset:0 0 auto 0;height:60px;background:var(--bg);
  border-bottom:1px solid var(--line);display:flex;align-items:center;gap:12px;
  padding:0 16px;z-index:50}}
header img{{height:26px}}
.htitle{{font-weight:600;color:var(--green);font-size:14px;white-space:nowrap;
  overflow:hidden;text-overflow:ellipsis}}
.hver{{font-size:11px;color:var(--taupe);border:1px solid var(--line);
  border-radius:20px;padding:2px 9px;white-space:nowrap}}
.spacer{{flex:1}}
.btn{{border:1px solid var(--line);background:transparent;color:var(--ink);
  border-radius:8px;padding:6px 11px;font:inherit;font-size:13px;cursor:pointer}}
.btn:hover{{border-color:var(--sage);color:var(--green)}}
a.btn{{text-decoration:none;line-height:1.7}}
#burger{{display:none}}

/* ---------- buscador ---------- */
#q{{flex:1;max-width:340px;padding:7px 12px;border:1px solid var(--line);
  border-radius:8px;background:var(--panel);color:var(--ink);font:inherit;font-size:13px}}
#q:focus{{outline:none;border-color:var(--sage)}}

/* ---------- layout ---------- */
.wrap{{display:flex;padding-top:60px}}
nav{{width:310px;flex:none;height:calc(100vh - 60px);position:sticky;top:60px;
  overflow-y:auto;border-right:1px solid var(--line);padding:16px 10px 60px;background:var(--bg)}}
main{{flex:1;min-width:0;padding:26px 34px 120px;max-width:var(--w);margin:0 auto}}

.nv-part{{margin-bottom:6px}}
.nv-p{{display:block;font-weight:600;color:var(--green);text-decoration:none;
  font-size:13px;padding:8px 10px;border-radius:8px;cursor:pointer}}
.nv-p:hover{{background:var(--panel)}}
.nv-kids{{padding-left:8px;border-left:2px solid var(--line);margin-left:10px}}
.nv-c{{display:block;color:var(--muted);text-decoration:none;font-size:12.5px;
  padding:5px 10px;border-radius:6px}}
.nv-c:hover{{background:var(--panel);color:var(--green)}}
.nv-c.on{{background:var(--panel);color:var(--green);font-weight:500}}
.nv-part.hide,.nv-c.hide{{display:none}}

/* ---------- tipografía de contenido ---------- */
.part{{margin:70px 0 26px;padding:26px 0 18px;border-top:3px solid var(--sage)}}
.part:first-of-type{{margin-top:0}}
.part-k{{font-size:11px;letter-spacing:.14em;color:var(--taupe);font-weight:600}}
.part h1{{font-size:28px;line-height:1.2;color:var(--green);margin:6px 0 8px}}
.part-s{{color:var(--taupe);margin:0;font-size:14px}}
.chap{{margin:48px 0 14px;padding-bottom:10px;border-bottom:1px solid var(--line)}}
.chap-k{{font-size:10.5px;letter-spacing:.14em;color:var(--taupe);font-weight:600}}
.chap h2{{font-size:22px;color:var(--green);margin:4px 0 0;line-height:1.25}}
h3{{font-size:17px;color:var(--green);margin:30px 0 8px;scroll-margin-top:80px}}
h4{{font-size:14.5px;color:var(--green-d);margin:20px 0 6px}}
h5{{font-size:13px;color:var(--taupe);margin:16px 0 4px}}
p{{margin:0 0 10px}}
.note{{font-size:13.5px;color:var(--muted)}}
.center{{text-align:center;color:var(--muted)}}
ul,ol{{margin:0 0 12px;padding-left:22px}}
li{{margin-bottom:4px}}
hr{{border:none;border-top:1px solid var(--line);margin:18px 0}}
blockquote{{margin:12px 0;padding:11px 16px;border-left:3px solid var(--sage);
  background:var(--panel);border-radius:0 8px 8px 0;font-style:italic;color:var(--green-d)}}

/* ---------- componentes ---------- */
.box{{background:var(--panel);border-left:4px solid var(--sage);border-radius:0 10px 10px 0;
  padding:14px 18px;margin:16px 0}}
.box-t{{font-weight:600;color:var(--green);font-size:13.5px;margin-bottom:5px}}
.box p{{margin:0 0 6px;font-size:14px}}
.box p:last-child{{margin:0}}

.flow{{background:#EDF1E6;border-radius:10px;padding:12px 14px;margin:14px 0;
  display:flex;flex-wrap:wrap;align-items:center;gap:6px;justify-content:center}}
[data-theme="dark"] .flow{{background:var(--panel)}}
.step{{font-weight:600;color:var(--green);font-size:12.5px}}
.arw{{color:var(--sage);font-weight:700}}

.tag{{display:inline-block;font-size:10.5px;font-weight:600;color:#fff;
  padding:4px 10px;border-radius:5px;margin:12px 0 8px;letter-spacing:.02em}}
.tag-c{{background:#23513F}} .tag-r{{background:#00331E}}
.tag-p{{background:#6A9D29}} .tag-v{{background:#DB9D25}}

.tw{{overflow-x:auto;margin:14px 0;-webkit-overflow-scrolling:touch}}
table{{border-collapse:collapse;width:100%;font-size:13px;min-width:460px}}
th{{background:var(--green);color:#fff;text-align:left;font-weight:600;padding:8px 10px;
  font-size:12.5px}}
td{{border:1px solid var(--line);padding:8px 10px;vertical-align:top}}
tbody tr:nth-child(even){{background:var(--panel)}}

.checklist{{list-style:none;padding-left:0}}
.checklist li{{margin-bottom:6px}}
.checklist label{{display:flex;gap:9px;align-items:flex-start;cursor:pointer}}
.checklist input{{margin-top:5px;accent-color:var(--green);flex:none;width:15px;height:15px}}
.checklist input:checked + span{{color:var(--muted);text-decoration:line-through}}

mark{{background:#FFE9A8;color:inherit;padding:0 2px;border-radius:2px}}
[data-theme="dark"] mark{{background:#5d4c17;color:#fff}}

/* ---------- utilidades ---------- */
#top{{position:fixed;right:18px;bottom:18px;z-index:40;display:none;
  background:var(--green);color:#fff;border:none;border-radius:50%;
  width:42px;height:42px;font-size:17px;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.18)}}
#bar{{position:fixed;top:60px;left:0;height:3px;background:var(--sage);z-index:60;width:0}}
#hits{{font-size:12px;color:var(--taupe);padding:6px 10px}}
.tools{{display:flex;gap:8px;flex-wrap:wrap;margin:18px 0 4px}}

@media (max-width:900px){{
  #burger{{display:inline-block}}
  nav{{position:fixed;top:60px;left:0;bottom:0;width:84%;max-width:330px;
    transform:translateX(-102%);transition:transform .22s ease;z-index:45;
    box-shadow:4px 0 22px rgba(0,0,0,.13)}}
  nav.open{{transform:none}}
  main{{padding:20px 16px 100px}}
  .htitle{{font-size:12.5px}} .hver{{display:none}}
  #q{{max-width:none}}
  .part h1{{font-size:23px}} .chap h2{{font-size:19px}}
}}
@media print{{
  header,nav,#top,#bar,.tools{{display:none!important}}
  main{{max-width:none;padding:0}} .wrap{{padding-top:0}}
  .chap{{page-break-before:always}} .tw,table,.box{{page-break-inside:avoid}}
  body{{font-size:10.5pt}}
}}
</style>
</head>
<body>
<div id="bar"></div>
<header>
  <button class="btn" id="burger" title="Menú">☰</button>
  <img src="data:image/png;base64,{logo_b64}" alt="Ecobay Cleaning">
  <span class="htitle">Manual Corporativo y Operativo</span>
  <span class="hver">v3.0</span>
  <div class="spacer"></div>
  <input id="q" type="search" placeholder="Buscar en el manual…  (tecla /)" autocomplete="off">
  <button class="btn" id="theme" title="Modo oscuro">◐</button>
  <button class="btn" id="print" title="Imprimir o guardar como PDF">⎙</button>
  <a class="btn" href="manual-ecobay-v3.pdf" download title="Descargar PDF">⤓</a>
</header>

<div class="wrap">
  <nav id="nav">
    <div id="hits"></div>
    {nav_html}
  </nav>
  <main id="main">
    {body}
  </main>
</div>
<button id="top" title="Volver arriba">↑</button>

<script>
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];

/* --- tema --- */
const th=localStorage.getItem('ecobay-theme');
if(th) document.documentElement.dataset.theme=th;
$('#theme').onclick=()=>{{
  const d=document.documentElement.dataset.theme==='dark';
  document.documentElement.dataset.theme=d?'':'dark';
  localStorage.setItem('ecobay-theme',d?'':'dark');
}};
$('#print').onclick=()=>window.print();

/* --- menú móvil --- */
$('#burger').onclick=()=>$('#nav').classList.toggle('open');
$$('.nv-c,.nv-p').forEach(a=>a.onclick=()=>{{
  if(innerWidth<900) $('#nav').classList.remove('open');
}});

/* --- barra de progreso + botón arriba --- */
addEventListener('scroll',()=>{{
  const h=document.body.scrollHeight-innerHeight;
  $('#bar').style.width=(h>0?scrollY/h*100:0)+'%';
  $('#top').style.display=scrollY>500?'block':'none';
}});
$('#top').onclick=()=>scrollTo({{top:0,behavior:'smooth'}});

/* --- capítulo activo en la navegación --- */
const caps=$$('.chap'), links=$$('.nv-c');
const io=new IntersectionObserver(es=>{{
  es.forEach(e=>{{
    if(!e.isIntersecting) return;
    links.forEach(l=>l.classList.toggle('on',l.getAttribute('href')==='#'+e.target.id));
  }});
}},{{rootMargin:'-70px 0px -75% 0px'}});
caps.forEach(c=>io.observe(c));

/* --- checklists persistentes --- */
$$('.checklist').forEach((ul,ui)=>{{
  const chap=(ul.closest('main')&&[...$$('.chap')].filter(c=>c.compareDocumentPosition(ul)&4).pop());
  [...ul.querySelectorAll('.ck')].forEach((c,ci)=>{{
    const key='ecobay-ck-'+(chap?chap.id:'x')+'-'+ui+'-'+ci;
    c.checked=localStorage.getItem(key)==='1';
    c.onchange=()=>localStorage.setItem(key,c.checked?'1':'0');
  }});
}});
/* botón para limpiar las casillas de una checklist */
$$('.checklist').forEach(ul=>{{
  const b=document.createElement('button');
  b.className='btn'; b.textContent='Reiniciar casillas';
  b.style.cssText='font-size:11.5px;padding:3px 9px;margin:2px 0 14px';
  b.onclick=()=>[...ul.querySelectorAll('.ck')].forEach(c=>{{c.checked=false;c.dispatchEvent(new Event('change'));}});
  ul.after(b);
}});

/* --- buscador --- */
const q=$('#q'), hits=$('#hits'), parts=$$('.nv-part');
function clearMarks(){{
  $$('main mark').forEach(m=>{{const p=m.parentNode;p.replaceChild(document.createTextNode(m.textContent),m);p.normalize();}});
}}
function search(){{
  const t=q.value.trim().toLowerCase();
  clearMarks();
  if(t.length<2){{
    links.forEach(l=>l.classList.remove('hide'));
    parts.forEach(p=>p.classList.remove('hide'));
    hits.textContent=''; return;
  }}
  /* filtra la navegación por capítulo que contenga el término */
  let n=0;
  caps.forEach(c=>{{
    let txt=c.textContent, el=c.nextElementSibling;
    while(el && !el.classList.contains('chap') && !el.classList.contains('part')){{
      txt+=' '+el.textContent; el=el.nextElementSibling;
    }}
    const ok=txt.toLowerCase().includes(t);
    const link=links.find(l=>l.getAttribute('href')==='#'+c.id);
    if(link) link.classList.toggle('hide',!ok);
    if(ok) n++;
  }});
  parts.forEach(p=>{{
    const vis=[...p.querySelectorAll('.nv-c')].some(l=>!l.classList.contains('hide'));
    p.classList.toggle('hide',!vis);
  }});
  hits.textContent=n?(n+' capítulo'+(n>1?'s':'')+' con resultados'):'Sin resultados';
  /* resalta coincidencias visibles */
  const rx=new RegExp('('+t.replace(/[.*+?^${{}}()|[\\]\\\\]/g,'\\\\$&')+')','gi');
  const walk=document.createTreeWalker($('#main'),NodeFilter.SHOW_TEXT);
  const nodes=[]; while(walk.nextNode()) nodes.push(walk.currentNode);
  nodes.slice(0,6000).forEach(nd=>{{
    if(!nd.nodeValue.toLowerCase().includes(t)) return;
    if(['SCRIPT','STYLE','MARK'].includes(nd.parentNode.nodeName)) return;
    const span=document.createElement('span');
    span.innerHTML=nd.nodeValue.replace(rx,'<mark>$1</mark>');
    nd.parentNode.replaceChild(span,nd);
  }});
}}
let tmr; q.oninput=()=>{{clearTimeout(tmr);tmr=setTimeout(search,200);}};
addEventListener('keydown',e=>{{
  if(e.key==='/'&&document.activeElement!==q){{e.preventDefault();q.focus();}}
  if(e.key==='Escape'){{q.value='';search();q.blur();}}
}});
</script>
</body>
</html>"""

open('index.html', 'w', encoding='utf-8').write(HTML)
print("index.html", round(os.path.getsize('index.html') / 1024), "KB")
