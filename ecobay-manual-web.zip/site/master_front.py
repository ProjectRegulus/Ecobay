# -*- coding: utf-8 -*-
from build_manual_m import *  # noqa

# ============================== PORTADA ==============================
story.append(Spacer(1, 52))
story.append(Paragraph("THE ECOBAY OPERATING SYSTEM", S['cover_s']))
story.append(Spacer(1, 12))
story.append(Paragraph("Manual Corporativo<br/>y Operativo", S['cover_t']))
story.append(Spacer(1, 16))
story.append(HR(SAGE, 1.5))
story.append(Spacer(1, 16))
story.append(Paragraph("ECOBAY CLEANING LLC", S['cover_s']))
story.append(Spacer(1, 32))
story.append(Paragraph(
    "Documento maestro<br/><br/>"
    "Sistema de procesos, estándares, controles y responsabilidades<br/>"
    "para operar, delegar, medir, auditar y replicar<br/>"
    "la operación de Ecobay Cleaning LLC.", S['cover_x']))
story.append(Spacer(1, 62))
story.append(Image(LOGO, width=2.0 * inch, height=2.0 * inch * 195 / 482, hAlign='CENTER'))
story.append(Spacer(1, 24))
story.append(Paragraph("Versión 3.0 &nbsp;|&nbsp; Documento interno de uso confidencial", S['cover_x']))

# ============================== FICHA TÉCNICA ==============================
story.append(PageBreak())
P("Ficha técnica del documento", 'h1')
TBL([
    ["Campo", "Detalle"],
    ["Documento", "Manual Corporativo y Operativo — documento maestro"],
    ["Empresa", "Ecobay Cleaning LLC"],
    ["Versión", "3.0"],
    ["Estado", "Documento vivo. Se amplía conforme avanza el levantamiento de procesos."],
    ["Partes incluidas",
     "I. Identidad y modelo operativo · II. Administración y sistema empresarial · III. Leads, marketing y ventas · "
     "III-B. Ampliación comercial · X. Tecnología y sistemas · XI. Selección de personal · XII-B. Obligaciones y "
     "protección financiera."],
    ["Documento complementario",
     "«La Casa Verde de Ecobay» — Manual de Limpieza por Áreas (vigente; no sustituido por este manual)."],
    ["Fuentes",
     "Entrevistas de levantamiento con la administración de Ecobay; playbooks comerciales inbound y outbound; "
     "guía de screening y contratación; términos y condiciones de servicio comercial; guía de obligaciones de la "
     "LLC; guía de prevención de fraude."],
    ["Confidencialidad", "Prohibida su difusión total o parcial a terceros."],
], [1.6 * inch, 4.9 * inch], fs=8.5)

SP(4)
P("Prueba de validación de todo el manual", 'h2')
BOX(None, [
    "<b>¿Podría una persona competente, que no conoce previamente Ecobay, ejecutar este proceso correctamente "
    "utilizando únicamente este manual, las herramientas de la empresa y los sistemas correspondientes?</b>",
    "Si la respuesta es no, el procedimiento necesita más detalle. Esta pregunta es el criterio de aceptación para "
    "aprobar cada nueva versión."])

# ============================== ETIQUETAS ==============================
story.append(PageBreak())
P("Cómo leer este manual", 'h1')
P("Este manual documenta <b>cómo funciona Ecobay hoy</b> y propone la estructura que le falta, sin confundir "
  "ambas cosas. Cada procedimiento, regla, tabla o checklist está clasificado en uno de tres niveles, y esos "
  "niveles nunca se mezclan dentro de una misma afirmación.")
TAG("C", "así se hace hoy en Ecobay; levantado y verificado")
TAG("R", "criterio ya definido por la empresa, de aplicación obligatoria")
TAG("P", "diseño del consultor; requiere aprobación antes de ser obligatorio")
SP(4)
TBL([
    ["Etiqueta", "¿Es obligatorio hoy?", "Qué hacer con ella"],
    ["Procedimiento confirmado", "Sí, es la práctica vigente.", "Ejecutar. Mejorar solo mediante versión aprobada."],
    ["Regla operativa confirmada", "Sí.", "Aplicar de forma consistente y auditar su cumplimiento."],
    ["Estándar propuesto", "No hasta ser aprobado.", "Revisar, ajustar, aprobar o rechazar."],
], [1.7 * inch, 1.8 * inch, 3.0 * inch], fs=8.5)
BOX("Advertencia metodológica", [
    "Una costumbre no es todavía una política. Ninguna práctica informal descrita aquí se convierte en regla "
    "obligatoria hasta que la administración la confirme de manera expresa. Los estándares propuestos se identifican como tales "
    "hasta que la dirección los apruebe."])

SP(4)
P("El lente de escalabilidad", 'h2')
P("Los procesos diseñados para replicarse clasifican además sus elementos en cinco niveles. Esta clasificación es "
  "la que permitirá que una segunda ubicación opere igual sin supervisión diaria.")
TBL([
    ["Nivel", "Qué significa", "Quién decide"],
    ["No negociable", "Nunca cambia. Protege la marca, la legalidad o la seguridad.", "Corporate"],
    ["Estándar", "Debe seguirse normalmente; su desviación se documenta.", "Corporate"],
    ["Adaptación local", "Puede variar por mercado, estado o tipo de cliente.", "Operador local"],
    ["Criterio administrativo", "Depende del juicio de la posición responsable.", "Administración"],
    ["Escalamiento", "Requiere aprobación superior antes de ejecutarse.", "Owner"],
], [1.5 * inch, 3.5 * inch, 1.5 * inch], fs=8.5)

CPB(2.4)
BOX("Aviso legal y fiscal", [
    "Los capítulos 23-C, 86, 107 y 107-A contienen información general de referencia operativa. <b>No constituyen "
    "asesoría legal, fiscal ni de recursos humanos.</b> Las obligaciones, la clasificación laboral y las cláusulas "
    "contractuales dependen del estado, la ciudad, la clasificación fiscal de la entidad y la relación real de "
    "trabajo. Antes de aplicarlos, Ecobay debe validarlos con un profesional licenciado en la jurisdicción "
    "correspondiente."])

# ============================== ARQUITECTURA DOCUMENTAL ==============================
story.append(PageBreak())
P("Arquitectura documental de Ecobay", 'h1')
P("Este manual es el documento de nivel 1 de un sistema de seis niveles. La separación es deliberada: permite "
  "cambiar de software, de proveedor o de herramienta sin reescribir el manual corporativo, porque el proceso "
  "empresarial y la instrucción técnica viven en documentos distintos.")
TBL([
    ["Nivel", "Documento", "Responde a", "Cambia cuando"],
    ["1", "Manual Corporativo y Operativo (este documento)", "Cómo funciona la empresa.", "Cambia el modelo de negocio o una política."],
    ["2", "SOPs", "Cómo se ejecuta un proceso específico.", "Cambia el proceso."],
    ["3", "Work Instructions", "Cómo se realiza una tarea concreta.", "Cambia la técnica de ejecución."],
    ["4", "Checklists y formularios", "Cómo se verifica y se registra.", "Cambia el control o la evidencia."],
    ["5", "Guías de software", "Cómo se usa una herramienta.", "Cambia la plataforma o su interfaz."],
    ["6", "Material de capacitación", "Cómo se enseña el proceso.", "Cambia cualquiera de los anteriores."],
], [0.5 * inch, 1.9 * inch, 2.1 * inch, 2.0 * inch], fs=8.5)
FLOW(["Manual: todo lead debe registrarse y cerrarse", "SOP de Lead Management",
      "Guía de la plataforma", "Checklist de verificación"])
BOX("Regla de independencia tecnológica", [
    "Si Ecobay reemplaza cualquiera de sus plataformas, los niveles 1 a 4 siguen siendo válidos. Solo se "
    "reescriben los niveles 5 y 6. Por eso este manual describe <b>qué información debe existir y quién responde "
    "por ella</b>, no qué botón se presiona."])

SP(4)
CPB(2.6)
P("Relación con el Manual de Limpieza por Áreas", 'h2')
TBL([
    ["Manual Corporativo y Operativo", "Manual de Limpieza por Áreas"],
    ["Qué sistema debe seguirse.", "Cómo se ejecuta técnicamente la limpieza de cada área."],
    ["Quién es responsable de cada proceso.", "Qué producto y herramienta se usa en cada superficie."],
    ["Cómo se mide, controla y audita.", "Qué estándar visual debe alcanzar cada área."],
    ["Cómo se delega, escala y replica.", "Cómo se presenta y se comporta el colaborador en la propiedad."],
], [3.25 * inch, 3.25 * inch], fs=8.5)

# ============================== ÍNDICE ==============================
story.append(PageBreak())
P("Índice general", 'h1')
SP(3)
idx = [
    ("P", "PARTE I — IDENTIDAD, FILOSOFÍA Y MODELO OPERATIVO"),
    ("s", "1. Propósito del manual"),
    ("s", "2. Historia, identidad y filosofía de Ecobay"),
    ("s", "3. Misión, visión, valores y principios operativos"),
    ("s", "4. Modelo de negocio de Ecobay"),
    ("s", "5. Estructura organizacional"),
    ("s", "6. Roles, responsabilidades y autoridad"),
    ("s", "7. Matriz de responsabilidades y delegación"),
    ("P", "PARTE II — ADMINISTRACIÓN Y SISTEMA EMPRESARIAL"),
    ("s", "8. Sistema de administración"),
    ("s", "9. Gestión del tiempo y prioridades"),
    ("s", "10. Rutinas administrativas diarias"),
    ("s", "11. Rutinas administrativas semanales"),
    ("s", "12. Rutinas administrativas mensuales"),
    ("s", "13. Gestión de información empresarial"),
    ("s", "14. Documentación y control de procesos"),
    ("P", "PARTE III — LEADS, MARKETING Y VENTAS"),
    ("s", "15. Origen de leads"),
    ("s", "16. Lead Intake"),
    ("s", "17. Lead Qualification"),
    ("s", "18. Google Local Services Ads"),
    ("s", "19. Website Leads"),
    ("s", "20. Phone Leads"),
    ("s", "21. SMS y Message Leads"),
    ("s", "22. Seguimiento de leads"),
    ("s", "23. Cotización"),
    ("s", "24. Conversión de prospectos a clientes"),
    ("s", "25. Reactivación de clientes"),
    ("s", "26. Reviews, referrals y reputación"),
    ("P", "PARTE III-B — AMPLIACIÓN COMERCIAL"),
    ("s", "23-A. Venta consultiva inbound"),
    ("s", "23-B. Desarrollo comercial outbound"),
    ("s", "23-C. Contratos y términos de servicio"),
    ("P", "PARTE X — TECNOLOGÍA Y SISTEMAS"),
    ("s", "73. Arquitectura tecnológica de Ecobay"),
    ("s", "74. CRM y gestión de la relación con el cliente"),
    ("s", "75. Jobber — sistema de gestión de servicios"),
    ("s", "76. CleanCore — sistema nervioso digital de Ecobay"),
    ("s", "77. Google Local Services Ads"),
    ("s", "78. Sistema de payroll"),
    ("s", "79. Correo, documentos y espacio de trabajo"),
    ("s", "80. Hojas de cálculo y registros auxiliares"),
    ("s", "81. Integridad de datos"),
    ("s", "82. Accesos, permisos y seguridad de información"),
    ("s", "82-A. Social media y presencia digital"),
    ("P", "PARTE XI — RECURSOS HUMANOS: SELECCIÓN DE PERSONAL"),
    ("s", "84. Planificación de personal y reclutamiento"),
    ("s", "85. Screening de precalificación (Fase 1)"),
    ("s", "86. Clasificación W-2 y 1099"),
    ("s", "87. Entrevista de valores (Fase 2)"),
    ("s", "88. Puntuación, decisión y contratación"),
    ("P", "PARTE XII-B — OBLIGACIONES Y PROTECCIÓN FINANCIERA"),
    ("s", "107. Calendario de obligaciones de la LLC"),
    ("s", "107-A. Prevención de fraude y protección de pagos"),
    ("P", "ANEXOS"),
    ("s", "A. Mapa del sistema y desarrollo futuro"),
    ("s", "B. Control de versiones"),
    ("s", "C. Acuse de recibo y confidencialidad"),
]
for k, t in idx:
    story.append(Paragraph(t, S['toc_p'] if k == "P" else S['toc']))
